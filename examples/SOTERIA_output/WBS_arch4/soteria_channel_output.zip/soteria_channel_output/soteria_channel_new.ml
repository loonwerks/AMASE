#use "top.ml";;
(* ----- COMPONENT LIBRARY ----- *)

let comp_library = 
  [
{name = "w1_w5_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "w2_w6_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "w3_w7_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "w4_w8_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "command_sys";
faults = ["contract violation"];
input_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
basic_events = [];
event_info = [];
output_flows = ["CommandSystem_Wheel_2_brake_com"; "CommandSystem_Wheel_6_brake_com"; "CommandSystem_Wheel_7_brake_com"; "CommandSystem_Wheel_3_brake_com"; "CommandSystem_Pair_1_5_Create_a"; "CommandSystem_Pair_4_8_Create_a"; "CommandSystem_Wheel_1_brake_com"; "CommandSystem_Pair_3_7_Create_a"; "CommandSystem_Wheel_4_brake_com"; "CommandSystem_Wheel_8_brake_com"; "CommandSystem_Pair_2_6_Create_a"; "CommandSystem_Wheel_5_brake_com"];
formulas = [
(["CommandSystem_Wheel_2_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_6_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_7_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_3_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Pair_1_5_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Pair_4_8_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_1_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Pair_3_7_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_4_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_8_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"]); 
(["CommandSystem_Pair_2_6_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_5_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"])]
}; 

{name = "Channel.inst";
faults = ["contract violation"];
input_flows = ["CommandSystem_Wheel_2_brake_com"; "CommandSystem_Wheel_6_brake_com"; "CommandSystem_Wheel_7_brake_com"; "CommandSystem_Wheel_3_brake_com"; "CommandSystem_Pair_1_5_Create_a"; "CommandSystem_Pair_4_8_Create_a"; "CommandSystem_Wheel_1_brake_com"; "CommandSystem_Pair_3_7_Create_a"; "CommandSystem_Wheel_4_brake_com"; "CommandSystem_Wheel_8_brake_com"; "CommandSystem_Pair_2_6_Create_a"; "CommandSystem_Wheel_5_brake_com"];
basic_events = ["MonitorSystem_Inverted_boolean_"];
event_info = [(8.0E-7, 1.0)];
output_flows = ["Channel_Brake_antiskid_command__5"; "Channel_Brake_antiskid_command__6"; "Channel_Brake_antiskid_command__7"; "Channel_Brake_antiskid_command__1"; "Channel_Brake_antiskid_command__2"; "Channel_Brake_antiskid_command__3"; "Channel_Brake_antiskid_command__4"; "Channel_If_there_is_no_power_so"; "Channel_Antiskid_command_to_pai"; "Channel_Brake_antiskid_command_"; "Channel_Antiskid_command_to_pai_3"; "Channel_Antiskid_command_to_pai_1"; "Channel_Antiskid_command_to_pai_2"];
formulas = [
(["Channel_Brake_antiskid_command__5"; "contract violation"],
F["CommandSystem_Wheel_6_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__6"; "contract violation"],
F["CommandSystem_Wheel_7_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__7"; "contract violation"],
F["CommandSystem_Wheel_8_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__1"; "contract violation"],
F["CommandSystem_Wheel_2_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__2"; "contract violation"],
F["CommandSystem_Wheel_3_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__3"; "contract violation"],
F["CommandSystem_Wheel_4_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__4"; "contract violation"],
F["CommandSystem_Wheel_5_brake_com"; "contract violation"]); 
(["Channel_If_there_is_no_power_so"; "contract violation"],
F["MonitorSystem_Inverted_boolean_"]); 
(["Channel_Antiskid_command_to_pai"; "contract violation"],
F["CommandSystem_Pair_1_5_Create_a"; "contract violation"]); 
(["Channel_Brake_antiskid_command_"; "contract violation"],
F["CommandSystem_Wheel_1_brake_com"; "contract violation"]); 
(["Channel_Antiskid_command_to_pai_3"; "contract violation"],
F["CommandSystem_Pair_4_8_Create_a"; "contract violation"]); 
(["Channel_Antiskid_command_to_pai_1"; "contract violation"],
F["CommandSystem_Pair_2_6_Create_a"; "contract violation"]); 
(["Channel_Antiskid_command_to_pai_2"; "contract violation"],
F["CommandSystem_Pair_3_7_Create_a"; "contract violation"])]
}];;

(* ----- CHECK LIBRARY ----- *)
checkLibrary_componentUnique comp_library;;
checkLibrary_nonEmptyFaults comp_library;;
checkLibrary_disjointInputFlowsandBasicEvents comp_library;;
checkLibrary_listsAreConsistentLengths comp_library;;
checkLibrary_allOutputFaultsHaveFormulas comp_library;;
checkLibrary_formulasMakeSense comp_library;;


(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Antiskid_command_to_pai = 
{instances = 
[makeInstance "w1_w5_cmd_sys" "w1_w5_cmd_sys"();
makeInstance "w2_w6_cmd_sys" "w2_w6_cmd_sys"();
makeInstance "w3_w7_cmd_sys" "w3_w7_cmd_sys"();
makeInstance "w4_w8_cmd_sys" "w4_w8_cmd_sys"();
makeInstance "command_sys" "command_sys"();
makeInstance "Channel.inst" "Channel.inst"();
];
connections = 
[(("command_sys", "WheelPairCommandSystem_3_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("Channel.inst", "CommandSystem_Wheel_2_brake_com"),("command_sys", "CommandSystem_Wheel_2_brake_com")); (("Channel.inst", "CommandSystem_Wheel_6_brake_com"),("command_sys", "CommandSystem_Wheel_6_brake_com")); (("Channel.inst", "CommandSystem_Wheel_7_brake_com"),("command_sys", "CommandSystem_Wheel_7_brake_com")); (("Channel.inst", "CommandSystem_Wheel_3_brake_com"),("command_sys", "CommandSystem_Wheel_3_brake_com")); (("Channel.inst", "CommandSystem_Pair_1_5_Create_a"),("command_sys", "CommandSystem_Pair_1_5_Create_a")); (("Channel.inst", "CommandSystem_Pair_4_8_Create_a"),("command_sys", "CommandSystem_Pair_4_8_Create_a")); (("Channel.inst", "CommandSystem_Wheel_1_brake_com"),("command_sys", "CommandSystem_Wheel_1_brake_com")); (("Channel.inst", "CommandSystem_Pair_3_7_Create_a"),("command_sys", "CommandSystem_Pair_3_7_Create_a")); (("Channel.inst", "CommandSystem_Wheel_4_brake_com"),("command_sys", "CommandSystem_Wheel_4_brake_com")); (("Channel.inst", "CommandSystem_Wheel_8_brake_com"),("command_sys", "CommandSystem_Wheel_8_brake_com")); (("Channel.inst", "CommandSystem_Pair_2_6_Create_a"),("command_sys", "CommandSystem_Pair_2_6_Create_a")); (("Channel.inst", "CommandSystem_Wheel_5_brake_com"),("command_sys", "CommandSystem_Wheel_5_brake_com")); ];
top_fault = ("Channel.inst", F["Channel_Antiskid_command_to_pai"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Antiskid_command_to_pai;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Antiskid_command_to_pai comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Antiskid_command_to_pai comp_library;;
checkModel_validConnections model_Channel_Antiskid_command_to_pai comp_library;;
checkModel_inputFlowUnique model_Channel_Antiskid_command_to_pai;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Antiskid_command_to_pai "model_Channel_Antiskid_command_to_pai_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Antiskid_command_to_pai "model_Channel_Antiskid_command_to_pai_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Antiskid_command_to_pai "model_Channel_Antiskid_command_to_pai_fault_propagation.gv";;

let model_Channel_Antiskid_command_to_pai_ftree = model_to_ftree comp_library model_Channel_Antiskid_command_to_pai;;
probErrorCutImp model_Channel_Antiskid_command_to_pai_ftree;;
probErrorCut model_Channel_Antiskid_command_to_pai_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Antiskid_command_to_pai_direct_ftree.gv" model_Channel_Antiskid_command_to_pai_ftree ;;
dot_gen_show_tree_file "model_Channel_Antiskid_command_to_pai_optimized_ftree.gv" model_Channel_Antiskid_command_to_pai_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Antiskid_command_to_pai_1 = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Antiskid_command_to_pai_1"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Antiskid_command_to_pai_1;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Antiskid_command_to_pai_1 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Antiskid_command_to_pai_1 comp_library;;
checkModel_validConnections model_Channel_Antiskid_command_to_pai_1 comp_library;;
checkModel_inputFlowUnique model_Channel_Antiskid_command_to_pai_1;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Antiskid_command_to_pai_1 "model_Channel_Antiskid_command_to_pai_1_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Antiskid_command_to_pai_1 "model_Channel_Antiskid_command_to_pai_1_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Antiskid_command_to_pai_1 "model_Channel_Antiskid_command_to_pai_1_fault_propagation.gv";;

let model_Channel_Antiskid_command_to_pai_1_ftree = model_to_ftree comp_library model_Channel_Antiskid_command_to_pai_1;;
probErrorCutImp model_Channel_Antiskid_command_to_pai_1_ftree;;
probErrorCut model_Channel_Antiskid_command_to_pai_1_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Antiskid_command_to_pai_1_direct_ftree.gv" model_Channel_Antiskid_command_to_pai_1_ftree ;;
dot_gen_show_tree_file "model_Channel_Antiskid_command_to_pai_1_optimized_ftree.gv" model_Channel_Antiskid_command_to_pai_1_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Antiskid_command_to_pai_2 = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Antiskid_command_to_pai_2"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Antiskid_command_to_pai_2;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Antiskid_command_to_pai_2 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Antiskid_command_to_pai_2 comp_library;;
checkModel_validConnections model_Channel_Antiskid_command_to_pai_2 comp_library;;
checkModel_inputFlowUnique model_Channel_Antiskid_command_to_pai_2;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Antiskid_command_to_pai_2 "model_Channel_Antiskid_command_to_pai_2_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Antiskid_command_to_pai_2 "model_Channel_Antiskid_command_to_pai_2_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Antiskid_command_to_pai_2 "model_Channel_Antiskid_command_to_pai_2_fault_propagation.gv";;

let model_Channel_Antiskid_command_to_pai_2_ftree = model_to_ftree comp_library model_Channel_Antiskid_command_to_pai_2;;
probErrorCutImp model_Channel_Antiskid_command_to_pai_2_ftree;;
probErrorCut model_Channel_Antiskid_command_to_pai_2_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Antiskid_command_to_pai_2_direct_ftree.gv" model_Channel_Antiskid_command_to_pai_2_ftree ;;
dot_gen_show_tree_file "model_Channel_Antiskid_command_to_pai_2_optimized_ftree.gv" model_Channel_Antiskid_command_to_pai_2_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Antiskid_command_to_pai_3 = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Antiskid_command_to_pai_3"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Antiskid_command_to_pai_3;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Antiskid_command_to_pai_3 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Antiskid_command_to_pai_3 comp_library;;
checkModel_validConnections model_Channel_Antiskid_command_to_pai_3 comp_library;;
checkModel_inputFlowUnique model_Channel_Antiskid_command_to_pai_3;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Antiskid_command_to_pai_3 "model_Channel_Antiskid_command_to_pai_3_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Antiskid_command_to_pai_3 "model_Channel_Antiskid_command_to_pai_3_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Antiskid_command_to_pai_3 "model_Channel_Antiskid_command_to_pai_3_fault_propagation.gv";;

let model_Channel_Antiskid_command_to_pai_3_ftree = model_to_ftree comp_library model_Channel_Antiskid_command_to_pai_3;;
probErrorCutImp model_Channel_Antiskid_command_to_pai_3_ftree;;
probErrorCut model_Channel_Antiskid_command_to_pai_3_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Antiskid_command_to_pai_3_direct_ftree.gv" model_Channel_Antiskid_command_to_pai_3_ftree ;;
dot_gen_show_tree_file "model_Channel_Antiskid_command_to_pai_3_optimized_ftree.gv" model_Channel_Antiskid_command_to_pai_3_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Brake_antiskid_command_ = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Brake_antiskid_command_"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Brake_antiskid_command_;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Brake_antiskid_command_ comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Brake_antiskid_command_ comp_library;;
checkModel_validConnections model_Channel_Brake_antiskid_command_ comp_library;;
checkModel_inputFlowUnique model_Channel_Brake_antiskid_command_;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Brake_antiskid_command_ "model_Channel_Brake_antiskid_command__physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command_ "model_Channel_Brake_antiskid_command__functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command_ "model_Channel_Brake_antiskid_command__fault_propagation.gv";;

let model_Channel_Brake_antiskid_command__ftree = model_to_ftree comp_library model_Channel_Brake_antiskid_command_;;
probErrorCutImp model_Channel_Brake_antiskid_command__ftree;;
probErrorCut model_Channel_Brake_antiskid_command__ftree;;
dot_gen_show_direct_tree_file "model_Channel_Brake_antiskid_command__direct_ftree.gv" model_Channel_Brake_antiskid_command__ftree ;;
dot_gen_show_tree_file "model_Channel_Brake_antiskid_command__optimized_ftree.gv" model_Channel_Brake_antiskid_command__ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Brake_antiskid_command__1 = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Brake_antiskid_command__1"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Brake_antiskid_command__1;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Brake_antiskid_command__1 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Brake_antiskid_command__1 comp_library;;
checkModel_validConnections model_Channel_Brake_antiskid_command__1 comp_library;;
checkModel_inputFlowUnique model_Channel_Brake_antiskid_command__1;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Brake_antiskid_command__1 "model_Channel_Brake_antiskid_command__1_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__1 "model_Channel_Brake_antiskid_command__1_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__1 "model_Channel_Brake_antiskid_command__1_fault_propagation.gv";;

let model_Channel_Brake_antiskid_command__1_ftree = model_to_ftree comp_library model_Channel_Brake_antiskid_command__1;;
probErrorCutImp model_Channel_Brake_antiskid_command__1_ftree;;
probErrorCut model_Channel_Brake_antiskid_command__1_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Brake_antiskid_command__1_direct_ftree.gv" model_Channel_Brake_antiskid_command__1_ftree ;;
dot_gen_show_tree_file "model_Channel_Brake_antiskid_command__1_optimized_ftree.gv" model_Channel_Brake_antiskid_command__1_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Brake_antiskid_command__2 = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Brake_antiskid_command__2"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Brake_antiskid_command__2;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Brake_antiskid_command__2 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Brake_antiskid_command__2 comp_library;;
checkModel_validConnections model_Channel_Brake_antiskid_command__2 comp_library;;
checkModel_inputFlowUnique model_Channel_Brake_antiskid_command__2;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Brake_antiskid_command__2 "model_Channel_Brake_antiskid_command__2_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__2 "model_Channel_Brake_antiskid_command__2_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__2 "model_Channel_Brake_antiskid_command__2_fault_propagation.gv";;

let model_Channel_Brake_antiskid_command__2_ftree = model_to_ftree comp_library model_Channel_Brake_antiskid_command__2;;
probErrorCutImp model_Channel_Brake_antiskid_command__2_ftree;;
probErrorCut model_Channel_Brake_antiskid_command__2_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Brake_antiskid_command__2_direct_ftree.gv" model_Channel_Brake_antiskid_command__2_ftree ;;
dot_gen_show_tree_file "model_Channel_Brake_antiskid_command__2_optimized_ftree.gv" model_Channel_Brake_antiskid_command__2_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Brake_antiskid_command__3 = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Brake_antiskid_command__3"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Brake_antiskid_command__3;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Brake_antiskid_command__3 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Brake_antiskid_command__3 comp_library;;
checkModel_validConnections model_Channel_Brake_antiskid_command__3 comp_library;;
checkModel_inputFlowUnique model_Channel_Brake_antiskid_command__3;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Brake_antiskid_command__3 "model_Channel_Brake_antiskid_command__3_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__3 "model_Channel_Brake_antiskid_command__3_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__3 "model_Channel_Brake_antiskid_command__3_fault_propagation.gv";;

let model_Channel_Brake_antiskid_command__3_ftree = model_to_ftree comp_library model_Channel_Brake_antiskid_command__3;;
probErrorCutImp model_Channel_Brake_antiskid_command__3_ftree;;
probErrorCut model_Channel_Brake_antiskid_command__3_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Brake_antiskid_command__3_direct_ftree.gv" model_Channel_Brake_antiskid_command__3_ftree ;;
dot_gen_show_tree_file "model_Channel_Brake_antiskid_command__3_optimized_ftree.gv" model_Channel_Brake_antiskid_command__3_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Brake_antiskid_command__4 = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Brake_antiskid_command__4"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Brake_antiskid_command__4;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Brake_antiskid_command__4 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Brake_antiskid_command__4 comp_library;;
checkModel_validConnections model_Channel_Brake_antiskid_command__4 comp_library;;
checkModel_inputFlowUnique model_Channel_Brake_antiskid_command__4;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Brake_antiskid_command__4 "model_Channel_Brake_antiskid_command__4_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__4 "model_Channel_Brake_antiskid_command__4_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__4 "model_Channel_Brake_antiskid_command__4_fault_propagation.gv";;

let model_Channel_Brake_antiskid_command__4_ftree = model_to_ftree comp_library model_Channel_Brake_antiskid_command__4;;
probErrorCutImp model_Channel_Brake_antiskid_command__4_ftree;;
probErrorCut model_Channel_Brake_antiskid_command__4_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Brake_antiskid_command__4_direct_ftree.gv" model_Channel_Brake_antiskid_command__4_ftree ;;
dot_gen_show_tree_file "model_Channel_Brake_antiskid_command__4_optimized_ftree.gv" model_Channel_Brake_antiskid_command__4_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Brake_antiskid_command__5 = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Brake_antiskid_command__5"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Brake_antiskid_command__5;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Brake_antiskid_command__5 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Brake_antiskid_command__5 comp_library;;
checkModel_validConnections model_Channel_Brake_antiskid_command__5 comp_library;;
checkModel_inputFlowUnique model_Channel_Brake_antiskid_command__5;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Brake_antiskid_command__5 "model_Channel_Brake_antiskid_command__5_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__5 "model_Channel_Brake_antiskid_command__5_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__5 "model_Channel_Brake_antiskid_command__5_fault_propagation.gv";;

let model_Channel_Brake_antiskid_command__5_ftree = model_to_ftree comp_library model_Channel_Brake_antiskid_command__5;;
probErrorCutImp model_Channel_Brake_antiskid_command__5_ftree;;
probErrorCut model_Channel_Brake_antiskid_command__5_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Brake_antiskid_command__5_direct_ftree.gv" model_Channel_Brake_antiskid_command__5_ftree ;;
dot_gen_show_tree_file "model_Channel_Brake_antiskid_command__5_optimized_ftree.gv" model_Channel_Brake_antiskid_command__5_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Brake_antiskid_command__6 = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Brake_antiskid_command__6"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Brake_antiskid_command__6;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Brake_antiskid_command__6 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Brake_antiskid_command__6 comp_library;;
checkModel_validConnections model_Channel_Brake_antiskid_command__6 comp_library;;
checkModel_inputFlowUnique model_Channel_Brake_antiskid_command__6;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Brake_antiskid_command__6 "model_Channel_Brake_antiskid_command__6_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__6 "model_Channel_Brake_antiskid_command__6_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__6 "model_Channel_Brake_antiskid_command__6_fault_propagation.gv";;

let model_Channel_Brake_antiskid_command__6_ftree = model_to_ftree comp_library model_Channel_Brake_antiskid_command__6;;
probErrorCutImp model_Channel_Brake_antiskid_command__6_ftree;;
probErrorCut model_Channel_Brake_antiskid_command__6_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Brake_antiskid_command__6_direct_ftree.gv" model_Channel_Brake_antiskid_command__6_ftree ;;
dot_gen_show_tree_file "model_Channel_Brake_antiskid_command__6_optimized_ftree.gv" model_Channel_Brake_antiskid_command__6_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_Brake_antiskid_command__7 = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_Brake_antiskid_command__7"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_Brake_antiskid_command__7;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_Brake_antiskid_command__7 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_Brake_antiskid_command__7 comp_library;;
checkModel_validConnections model_Channel_Brake_antiskid_command__7 comp_library;;
checkModel_inputFlowUnique model_Channel_Brake_antiskid_command__7;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_Brake_antiskid_command__7 "model_Channel_Brake_antiskid_command__7_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__7 "model_Channel_Brake_antiskid_command__7_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_Brake_antiskid_command__7 "model_Channel_Brake_antiskid_command__7_fault_propagation.gv";;

let model_Channel_Brake_antiskid_command__7_ftree = model_to_ftree comp_library model_Channel_Brake_antiskid_command__7;;
probErrorCutImp model_Channel_Brake_antiskid_command__7_ftree;;
probErrorCut model_Channel_Brake_antiskid_command__7_ftree;;
dot_gen_show_direct_tree_file "model_Channel_Brake_antiskid_command__7_direct_ftree.gv" model_Channel_Brake_antiskid_command__7_ftree ;;
dot_gen_show_tree_file "model_Channel_Brake_antiskid_command__7_optimized_ftree.gv" model_Channel_Brake_antiskid_command__7_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_Channel_If_there_is_no_power_so = 
{instances = model_Channel_Antiskid_command_to_pai.instances;
connections=model_Channel_Antiskid_command_to_pai.connections;
top_fault = ("Channel.inst", F["Channel_If_there_is_no_power_so"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_Channel_If_there_is_no_power_so;;
checkModel_cnameInstanceIsDefinedInLibrary model_Channel_If_there_is_no_power_so comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_Channel_If_there_is_no_power_so comp_library;;
checkModel_validConnections model_Channel_If_there_is_no_power_so comp_library;;
checkModel_inputFlowUnique model_Channel_If_there_is_no_power_so;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_Channel_If_there_is_no_power_so "model_Channel_If_there_is_no_power_so_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_Channel_If_there_is_no_power_so "model_Channel_If_there_is_no_power_so_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_Channel_If_there_is_no_power_so "model_Channel_If_there_is_no_power_so_fault_propagation.gv";;

let model_Channel_If_there_is_no_power_so_ftree = model_to_ftree comp_library model_Channel_If_there_is_no_power_so;;
probErrorCutImp model_Channel_If_there_is_no_power_so_ftree;;
probErrorCut model_Channel_If_there_is_no_power_so_ftree;;
dot_gen_show_direct_tree_file "model_Channel_If_there_is_no_power_so_direct_ftree.gv" model_Channel_If_there_is_no_power_so_ftree ;;
dot_gen_show_tree_file "model_Channel_If_there_is_no_power_so_optimized_ftree.gv" model_Channel_If_there_is_no_power_so_ftree ;;

