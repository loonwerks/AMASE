#use "top.ml";;
(* ----- COMPONENT LIBRARY ----- *)

let comp_library = 
  [
{name = "normal_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["MeterValve_Stuck_at_nondetermin_1"; "MeterValve_Stuck_at_nondetermin"; "MeterValve_Stuck_at_nondetermin_7"; "MeterValve_Stuck_at_nondetermin_4"; "MeterValve_Stuck_at_nondetermin_6"; "MeterValve_Stuck_at_nondetermin_3"; "MeterValve_Stuck_at_nondetermin_5"; "MeterValve_Stuck_at_nondetermin_2"];
event_info = [(3.25E-6, 1.0); (3.25E-6, 1.0); (3.25E-6, 1.0); (3.25E-6, 1.0); (3.25E-6, 1.0); (3.25E-6, 1.0); (3.25E-6, 1.0); (3.25E-6, 1.0)];
output_flows = ["NormalBrakeSys_W4_Hydraulic_pre"; "NormalBrakeSys_W7_Hydraulic_pre"; "NormalBrakeSys_W3_Hydraulic_pre"; "NormalBrakeSys_W5_Hydraulic_pre"; "NormalBrakeSys_W8_Hydraulic_pre"; "NormalBrakeSys_W2_Hydraulic_pre"; "NormalBrakeSys_W6_Hydraulic_pre"; "NormalBrakeSys_W1_Hydraulic_pre"];
formulas = [
(["NormalBrakeSys_W4_Hydraulic_pre"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin_3"]); 
(["NormalBrakeSys_W7_Hydraulic_pre"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin_6"]); 
(["NormalBrakeSys_W3_Hydraulic_pre"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin_2"]); 
(["NormalBrakeSys_W5_Hydraulic_pre"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin_4"]); 
(["NormalBrakeSys_W8_Hydraulic_pre"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin_7"]); 
(["NormalBrakeSys_W2_Hydraulic_pre"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin_1"]); 
(["NormalBrakeSys_W6_Hydraulic_pre"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin_5"]); 
(["NormalBrakeSys_W1_Hydraulic_pre"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin"])]
}; 

{name = "alt_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["MeterValve_Stuck_at_nondetermin_1"; "MeterValve_Stuck_at_nondetermin"; "MeterValve_Stuck_at_nondetermin_3"; "MeterValve_Stuck_at_nondetermin_2"];
event_info = [(3.25E-6, 1.0); (3.25E-6, 1.0); (3.25E-6, 1.0); (3.25E-6, 1.0)];
output_flows = ["AlternateBrakeSystem_Pair_4_8_T"; "AlternateBrakeSystem_Pair_1_5_T"; "AlternateBrakeSystem_Pair_3_7_T"; "AlternateBrakeSystem_Pair_2_6_T"];
formulas = [
(["AlternateBrakeSystem_Pair_4_8_T"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin_3"]); 
(["AlternateBrakeSystem_Pair_1_5_T"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin"]); 
(["AlternateBrakeSystem_Pair_3_7_T"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin_2"]); 
(["AlternateBrakeSystem_Pair_2_6_T"; "contract violation"],
F["MeterValve_Stuck_at_nondetermin_1"])]
}; 

{name = "wheel_brake1";
faults = ["contract violation"];
input_flows = [];
basic_events = ["HydraulicPiston_Stuck_at_last_v_1"; "HydraulicFuse_Stuck_closed_faul_1"; "HydraulicPiston_Stuck_at_last_v"; "HydraulicFuse_Stuck_closed_faul"; "BrakeActuator_Stuck_at_last_val"];
event_info = [(3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-6, 1.0)];
output_flows = ["WheelBrake_braking_force_is_pos"];
formulas = [
(["WheelBrake_braking_force_is_pos"; "contract violation"],
Or[F["HydraulicFuse_Stuck_closed_faul"]; 
F["HydraulicPiston_Stuck_at_last_v"]; 
F["BrakeActuator_Stuck_at_last_val"]; 
F["HydraulicFuse_Stuck_closed_faul_1"]; 
F["HydraulicPiston_Stuck_at_last_v_1"]])]
}; 

{name = "wheel_brake2";
faults = ["contract violation"];
input_flows = [];
basic_events = ["HydraulicPiston_Stuck_at_last_v_1"; "HydraulicFuse_Stuck_closed_faul_1"; "HydraulicPiston_Stuck_at_last_v"; "HydraulicFuse_Stuck_closed_faul"; "BrakeActuator_Stuck_at_last_val"];
event_info = [(3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-6, 1.0)];
output_flows = ["WheelBrake_braking_force_is_pos"];
formulas = [
(["WheelBrake_braking_force_is_pos"; "contract violation"],
Or[F["HydraulicFuse_Stuck_closed_faul"]; 
F["HydraulicPiston_Stuck_at_last_v"]; 
F["BrakeActuator_Stuck_at_last_val"]; 
F["HydraulicFuse_Stuck_closed_faul_1"]; 
F["HydraulicPiston_Stuck_at_last_v_1"]])]
}; 

{name = "wheel_brake3";
faults = ["contract violation"];
input_flows = [];
basic_events = ["HydraulicPiston_Stuck_at_last_v_1"; "HydraulicFuse_Stuck_closed_faul_1"; "HydraulicPiston_Stuck_at_last_v"; "HydraulicFuse_Stuck_closed_faul"; "BrakeActuator_Stuck_at_last_val"];
event_info = [(3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-6, 1.0)];
output_flows = ["WheelBrake_braking_force_is_pos"];
formulas = [
(["WheelBrake_braking_force_is_pos"; "contract violation"],
Or[F["HydraulicFuse_Stuck_closed_faul"]; 
F["HydraulicPiston_Stuck_at_last_v"]; 
F["BrakeActuator_Stuck_at_last_val"]; 
F["HydraulicFuse_Stuck_closed_faul_1"]; 
F["HydraulicPiston_Stuck_at_last_v_1"]])]
}; 

{name = "wheel_brake4";
faults = ["contract violation"];
input_flows = [];
basic_events = ["HydraulicPiston_Stuck_at_last_v_1"; "HydraulicFuse_Stuck_closed_faul_1"; "HydraulicPiston_Stuck_at_last_v"; "HydraulicFuse_Stuck_closed_faul"; "BrakeActuator_Stuck_at_last_val"];
event_info = [(3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-6, 1.0)];
output_flows = ["WheelBrake_braking_force_is_pos"];
formulas = [
(["WheelBrake_braking_force_is_pos"; "contract violation"],
Or[F["HydraulicFuse_Stuck_closed_faul"]; 
F["HydraulicPiston_Stuck_at_last_v"]; 
F["BrakeActuator_Stuck_at_last_val"]; 
F["HydraulicFuse_Stuck_closed_faul_1"]; 
F["HydraulicPiston_Stuck_at_last_v_1"]])]
}; 

{name = "wheel_brake5";
faults = ["contract violation"];
input_flows = [];
basic_events = ["HydraulicPiston_Stuck_at_last_v_1"; "HydraulicFuse_Stuck_closed_faul_1"; "HydraulicPiston_Stuck_at_last_v"; "HydraulicFuse_Stuck_closed_faul"; "BrakeActuator_Stuck_at_last_val"];
event_info = [(3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-6, 1.0)];
output_flows = ["WheelBrake_braking_force_is_pos"];
formulas = [
(["WheelBrake_braking_force_is_pos"; "contract violation"],
Or[F["HydraulicFuse_Stuck_closed_faul"]; 
F["HydraulicPiston_Stuck_at_last_v"]; 
F["BrakeActuator_Stuck_at_last_val"]; 
F["HydraulicFuse_Stuck_closed_faul_1"]; 
F["HydraulicPiston_Stuck_at_last_v_1"]])]
}; 

{name = "wheel_brake6";
faults = ["contract violation"];
input_flows = [];
basic_events = ["HydraulicPiston_Stuck_at_last_v_1"; "HydraulicFuse_Stuck_closed_faul_1"; "HydraulicPiston_Stuck_at_last_v"; "HydraulicFuse_Stuck_closed_faul"; "BrakeActuator_Stuck_at_last_val"];
event_info = [(3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-6, 1.0)];
output_flows = ["WheelBrake_braking_force_is_pos"];
formulas = [
(["WheelBrake_braking_force_is_pos"; "contract violation"],
Or[F["HydraulicFuse_Stuck_closed_faul"]; 
F["HydraulicPiston_Stuck_at_last_v"]; 
F["BrakeActuator_Stuck_at_last_val"]; 
F["HydraulicFuse_Stuck_closed_faul_1"]; 
F["HydraulicPiston_Stuck_at_last_v_1"]])]
}; 

{name = "wheel_brake7";
faults = ["contract violation"];
input_flows = [];
basic_events = ["HydraulicPiston_Stuck_at_last_v_1"; "HydraulicFuse_Stuck_closed_faul_1"; "HydraulicPiston_Stuck_at_last_v"; "HydraulicFuse_Stuck_closed_faul"; "BrakeActuator_Stuck_at_last_val"];
event_info = [(3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-6, 1.0)];
output_flows = ["WheelBrake_braking_force_is_pos"];
formulas = [
(["WheelBrake_braking_force_is_pos"; "contract violation"],
Or[F["HydraulicFuse_Stuck_closed_faul"]; 
F["HydraulicPiston_Stuck_at_last_v"]; 
F["BrakeActuator_Stuck_at_last_val"]; 
F["HydraulicFuse_Stuck_closed_faul_1"]; 
F["HydraulicPiston_Stuck_at_last_v_1"]])]
}; 

{name = "wheel_brake8";
faults = ["contract violation"];
input_flows = [];
basic_events = ["HydraulicPiston_Stuck_at_last_v_1"; "HydraulicFuse_Stuck_closed_faul_1"; "HydraulicPiston_Stuck_at_last_v"; "HydraulicFuse_Stuck_closed_faul"; "BrakeActuator_Stuck_at_last_val"];
event_info = [(3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-5, 1.0); (1.0E-5, 1.0); (3.3E-6, 1.0)];
output_flows = ["WheelBrake_braking_force_is_pos"];
formulas = [
(["WheelBrake_braking_force_is_pos"; "contract violation"],
Or[F["HydraulicFuse_Stuck_closed_faul"]; 
F["HydraulicPiston_Stuck_at_last_v"]; 
F["BrakeActuator_Stuck_at_last_val"]; 
F["HydraulicFuse_Stuck_closed_faul_1"]; 
F["HydraulicPiston_Stuck_at_last_v_1"]])]
}; 

{name = "phys_sys";
faults = ["contract violation"];
input_flows = ["AlternateBrakeSystem_Pair_3_7_T"; "NormalBrakeSys_W7_Hydraulic_pre"; "AlternateBrakeSystem_Pair_2_6_T"; "NormalBrakeSys_W8_Hydraulic_pre"; "NormalBrakeSys_W2_Hydraulic_pre"; "NormalBrakeSys_W1_Hydraulic_pre"; "WheelBrake_braking_force_is_pos"; "AlternateBrakeSystem_Pair_4_8_T"; "NormalBrakeSys_W4_Hydraulic_pre"; "AlternateBrakeSystem_Pair_1_5_T"; "NormalBrakeSys_W3_Hydraulic_pre"; "NormalBrakeSys_W5_Hydraulic_pre"; "NormalBrakeSys_W6_Hydraulic_pre"];
basic_events = ["SelectorValve_Stuck_at_last_pos_1"; "HydraulicPump_Stuck_off_fault_g"; "Accumulator_Stuck_open_fault_ac"; "SelectorValve_Stuck_at_last_pos"; "ShutoffValve_Stuck_open_fault_s"];
event_info = [(1.0E-5, 1.0); (3.0E-5, 1.0); (5.0E-5, 1.0); (1.0E-5, 1.0); (5.0E-6, 1.0)];
output_flows = ["PhysicalSystem_Wheel_4_braking_"; "PhysicalSystem_Wheel_1_braking_"; "PhysicalSystem_Wheel_5_force_An"; "PhysicalSystem_Wheel_8_force_An"; "PhysicalSystem_Wheel_2_force_An"; "PhysicalSystem_Wheel_7_braking_"; "PhysicalSystem_Wheel_1_force_An"; "PhysicalSystem_Wheel_4_force_An"; "Physical_System_It_will_not_occ"; "PhysicalSystem_Wheel_2_braking_"; "PhysicalSystem_Wheel_6_braking_"; "PhysicalSystem_It_will_not_occu"; "PhysicalSystem_Wheel_6_force_An"; "PhysicalSystem_Wheel_3_braking_"; "PhysicalSystem_Wheel_5_braking_"; "PhysicalSystem_Green_pressure_i"; "PhysicalSystem_Wheel_7_force_An"; "PhysicalSystem_Wheel_3_force_An"; "PhysicalSystem_Wheel_8_braking_"];
formulas = [
(["PhysicalSystem_Wheel_4_braking_"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_4_8_T"; "contract violation"]; 
F["NormalBrakeSys_W4_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_1_braking_"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_1_5_T"; "contract violation"]; 
F["NormalBrakeSys_W1_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_5_force_An"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_1_5_T"; "contract violation"]; 
F["NormalBrakeSys_W5_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_8_force_An"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_4_8_T"; "contract violation"]; 
F["NormalBrakeSys_W8_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_2_force_An"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_2_6_T"; "contract violation"]; 
F["NormalBrakeSys_W2_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_7_braking_"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_3_7_T"; "contract violation"]; 
F["NormalBrakeSys_W7_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_1_force_An"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_1_5_T"; "contract violation"]; 
F["NormalBrakeSys_W1_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_4_force_An"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_4_8_T"; "contract violation"]; 
F["NormalBrakeSys_W4_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["Physical_System_It_will_not_occ"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_4_8_T"; "contract violation"]; 
F["NormalBrakeSys_W8_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_2_braking_"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_2_6_T"; "contract violation"]; 
F["NormalBrakeSys_W2_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_6_braking_"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_2_6_T"; "contract violation"]; 
F["NormalBrakeSys_W6_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_It_will_not_occu"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_1_5_T"; "contract violation"]; 
F["NormalBrakeSys_W1_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_6_force_An"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_2_6_T"; "contract violation"]; 
F["NormalBrakeSys_W6_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_3_braking_"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_3_7_T"; "contract violation"]; 
F["NormalBrakeSys_W3_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_5_braking_"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_1_5_T"; "contract violation"]; 
F["NormalBrakeSys_W5_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Green_pressure_i"; "contract violation"],
Or[F["HydraulicPump_Stuck_off_fault_g"]; 
F["ShutoffValve_Stuck_open_fault_s"]]); 
(["PhysicalSystem_Wheel_7_force_An"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_3_7_T"; "contract violation"]; 
F["NormalBrakeSys_W7_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_3_force_An"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_3_7_T"; "contract violation"]; 
F["NormalBrakeSys_W3_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]]); 
(["PhysicalSystem_Wheel_8_braking_"; "contract violation"],
Or[F["Accumulator_Stuck_open_fault_ac"]; 
F["SelectorValve_Stuck_at_last_pos"]; 
F["SelectorValve_Stuck_at_last_pos_1"]; 
F["AlternateBrakeSystem_Pair_4_8_T"; "contract violation"]; 
F["NormalBrakeSys_W8_Hydraulic_pre"; "contract violation"]; 
F["WheelBrake_braking_force_is_pos"; "contract violation"]])]
}; 

{name = "w1_w5_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "w2_w6_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "w3_w7_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "w4_w8_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "command_sys";
faults = ["contract violation"];
input_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
basic_events = [];
event_info = [];
output_flows = ["CommandSystem_Wheel_2_brake_com"; "CommandSystem_Wheel_6_brake_com"; "CommandSystem_Wheel_7_brake_com"; "CommandSystem_Wheel_3_brake_com"; "CommandSystem_Pair_1_5_Create_a"; "CommandSystem_Pair_4_8_Create_a"; "CommandSystem_Wheel_1_brake_com"; "CommandSystem_Pair_3_7_Create_a"; "CommandSystem_Wheel_4_brake_com"; "CommandSystem_Wheel_8_brake_com"; "CommandSystem_Pair_2_6_Create_a"; "CommandSystem_Wheel_5_brake_com"];
formulas = [
(["CommandSystem_Wheel_2_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_6_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_7_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_3_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Pair_1_5_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Pair_4_8_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_1_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Pair_3_7_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_4_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_8_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"]); 
(["CommandSystem_Pair_2_6_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_5_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"])]
}; 

{name = "channel1";
faults = ["contract violation"];
input_flows = ["CommandSystem_Wheel_2_brake_com"; "CommandSystem_Wheel_6_brake_com"; "CommandSystem_Wheel_7_brake_com"; "CommandSystem_Wheel_3_brake_com"; "CommandSystem_Pair_1_5_Create_a"; "CommandSystem_Pair_4_8_Create_a"; "CommandSystem_Wheel_1_brake_com"; "CommandSystem_Pair_3_7_Create_a"; "CommandSystem_Wheel_4_brake_com"; "CommandSystem_Wheel_8_brake_com"; "CommandSystem_Pair_2_6_Create_a"; "CommandSystem_Wheel_5_brake_com"];
basic_events = ["MonitorSystem_Inverted_boolean_"];
event_info = [(8.0E-7, 1.0)];
output_flows = ["Channel_Brake_antiskid_command__5"; "Channel_Brake_antiskid_command__6"; "Channel_Brake_antiskid_command__7"; "Channel_Brake_antiskid_command__1"; "Channel_Brake_antiskid_command__2"; "Channel_Brake_antiskid_command__3"; "Channel_Brake_antiskid_command__4"; "Channel_If_there_is_no_power_so"; "Channel_Antiskid_command_to_pai"; "Channel_Brake_antiskid_command_"; "Channel_Antiskid_command_to_pai_3"; "Channel_Antiskid_command_to_pai_1"; "Channel_Antiskid_command_to_pai_2"];
formulas = [
(["Channel_Brake_antiskid_command__5"; "contract violation"],
F["CommandSystem_Wheel_6_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__6"; "contract violation"],
F["CommandSystem_Wheel_7_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__7"; "contract violation"],
F["CommandSystem_Wheel_8_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__1"; "contract violation"],
F["CommandSystem_Wheel_2_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__2"; "contract violation"],
F["CommandSystem_Wheel_3_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__3"; "contract violation"],
F["CommandSystem_Wheel_4_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__4"; "contract violation"],
F["CommandSystem_Wheel_5_brake_com"; "contract violation"]); 
(["Channel_If_there_is_no_power_so"; "contract violation"],
F["MonitorSystem_Inverted_boolean_"]); 
(["Channel_Antiskid_command_to_pai"; "contract violation"],
F["CommandSystem_Pair_1_5_Create_a"; "contract violation"]); 
(["Channel_Brake_antiskid_command_"; "contract violation"],
F["CommandSystem_Wheel_1_brake_com"; "contract violation"]); 
(["Channel_Antiskid_command_to_pai_3"; "contract violation"],
F["CommandSystem_Pair_4_8_Create_a"; "contract violation"]); 
(["Channel_Antiskid_command_to_pai_1"; "contract violation"],
F["CommandSystem_Pair_2_6_Create_a"; "contract violation"]); 
(["Channel_Antiskid_command_to_pai_2"; "contract violation"],
F["CommandSystem_Pair_3_7_Create_a"; "contract violation"])]
}; 

{name = "w1_w5_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "w2_w6_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "w3_w7_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "w4_w8_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["NormalCommandCalculator_Inverte_1"; "AntiskidCommandFacility_Inverte"; "BrakeCommandFacility_Inverted_b"; "AlternateCommandCalculator_Inve"; "NormalCommandCalculator_Inverte"; "AntiskidCommandFacility_Inverte_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
formulas = [
(["WheelPairCommandSystem_3_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte_1"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte_1"]]); 
(["WheelPairCommandSystem_1_Assign"; "contract violation"],
Or[F["AlternateCommandCalculator_Inve"]; 
F["AntiskidCommandFacility_Inverte"]; 
F["AntiskidCommandFacility_Inverte_1"]]); 
(["WheelPairCommandSystem_2_Assign"; "contract violation"],
Or[F["AntiskidCommandFacility_Inverte"]; 
F["BrakeCommandFacility_Inverted_b"]; 
F["NormalCommandCalculator_Inverte"]])]
}; 

{name = "command_sys";
faults = ["contract violation"];
input_flows = ["WheelPairCommandSystem_3_Assign"; "WheelPairCommandSystem_1_Assign"; "WheelPairCommandSystem_2_Assign"];
basic_events = [];
event_info = [];
output_flows = ["CommandSystem_Wheel_2_brake_com"; "CommandSystem_Wheel_6_brake_com"; "CommandSystem_Wheel_7_brake_com"; "CommandSystem_Wheel_3_brake_com"; "CommandSystem_Pair_1_5_Create_a"; "CommandSystem_Pair_4_8_Create_a"; "CommandSystem_Wheel_1_brake_com"; "CommandSystem_Pair_3_7_Create_a"; "CommandSystem_Wheel_4_brake_com"; "CommandSystem_Wheel_8_brake_com"; "CommandSystem_Pair_2_6_Create_a"; "CommandSystem_Wheel_5_brake_com"];
formulas = [
(["CommandSystem_Wheel_2_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_6_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_7_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_3_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Pair_1_5_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Pair_4_8_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_1_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Pair_3_7_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_4_brake_com"; "contract violation"],
F["WheelPairCommandSystem_2_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_8_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"]); 
(["CommandSystem_Pair_2_6_Create_a"; "contract violation"],
F["WheelPairCommandSystem_1_Assign"; "contract violation"]); 
(["CommandSystem_Wheel_5_brake_com"; "contract violation"],
F["WheelPairCommandSystem_3_Assign"; "contract violation"])]
}; 

{name = "channel2";
faults = ["contract violation"];
input_flows = ["CommandSystem_Wheel_2_brake_com"; "CommandSystem_Wheel_6_brake_com"; "CommandSystem_Wheel_7_brake_com"; "CommandSystem_Wheel_3_brake_com"; "CommandSystem_Pair_1_5_Create_a"; "CommandSystem_Pair_4_8_Create_a"; "CommandSystem_Wheel_1_brake_com"; "CommandSystem_Pair_3_7_Create_a"; "CommandSystem_Wheel_4_brake_com"; "CommandSystem_Wheel_8_brake_com"; "CommandSystem_Pair_2_6_Create_a"; "CommandSystem_Wheel_5_brake_com"];
basic_events = ["MonitorSystem_Inverted_boolean_"];
event_info = [(8.0E-7, 1.0)];
output_flows = ["Channel_Brake_antiskid_command__5"; "Channel_Brake_antiskid_command__6"; "Channel_Brake_antiskid_command__7"; "Channel_Brake_antiskid_command__1"; "Channel_Brake_antiskid_command__2"; "Channel_Brake_antiskid_command__3"; "Channel_Brake_antiskid_command__4"; "Channel_If_there_is_no_power_so"; "Channel_Antiskid_command_to_pai"; "Channel_Brake_antiskid_command_"; "Channel_Antiskid_command_to_pai_3"; "Channel_Antiskid_command_to_pai_1"; "Channel_Antiskid_command_to_pai_2"];
formulas = [
(["Channel_Brake_antiskid_command__5"; "contract violation"],
F["CommandSystem_Wheel_6_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__6"; "contract violation"],
F["CommandSystem_Wheel_7_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__7"; "contract violation"],
F["CommandSystem_Wheel_8_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__1"; "contract violation"],
F["CommandSystem_Wheel_2_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__2"; "contract violation"],
F["CommandSystem_Wheel_3_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__3"; "contract violation"],
F["CommandSystem_Wheel_4_brake_com"; "contract violation"]); 
(["Channel_Brake_antiskid_command__4"; "contract violation"],
F["CommandSystem_Wheel_5_brake_com"; "contract violation"]); 
(["Channel_If_there_is_no_power_so"; "contract violation"],
F["MonitorSystem_Inverted_boolean_"]); 
(["Channel_Antiskid_command_to_pai"; "contract violation"],
F["CommandSystem_Pair_1_5_Create_a"; "contract violation"]); 
(["Channel_Brake_antiskid_command_"; "contract violation"],
F["CommandSystem_Wheel_1_brake_com"; "contract violation"]); 
(["Channel_Antiskid_command_to_pai_3"; "contract violation"],
F["CommandSystem_Pair_4_8_Create_a"; "contract violation"]); 
(["Channel_Antiskid_command_to_pai_1"; "contract violation"],
F["CommandSystem_Pair_2_6_Create_a"; "contract violation"]); 
(["Channel_Antiskid_command_to_pai_2"; "contract violation"],
F["CommandSystem_Pair_3_7_Create_a"; "contract violation"])]
}; 

{name = "bscu";
faults = ["contract violation"];
input_flows = ["Channel_Brake_antiskid_command__5"; "Channel_Brake_antiskid_command__6"; "Channel_Brake_antiskid_command__7"; "Channel_Brake_antiskid_command__1"; "Channel_Brake_antiskid_command__2"; "Channel_Brake_antiskid_command__3"; "Channel_Brake_antiskid_command__4"; "Channel_If_there_is_no_power_so"; "Channel_Antiskid_command_to_pai"; "Channel_Brake_antiskid_command_"; "Channel_Antiskid_command_to_pai_3"; "Channel_Antiskid_command_to_pai_1"; "Channel_Antiskid_command_to_pai_2"];
basic_events = ["SwitchGate_Gives_last_valid_cha_11"; "SwitchGate_Gives_last_valid_cha_4"; "SwitchGate_Gives_last_valid_cha_9"; "SwitchGate_Gives_last_valid_cha_2"; "SwitchGate_Gives_last_valid_cha_6"; "SwitchGate_Gives_last_valid_cha_3"; "SwitchGate_Gives_last_valid_cha_7"; "SwitchGate_Gives_last_valid_cha"; "SwitchGate_Gives_last_valid_cha_8"; "SwitchGate_Gives_last_valid_cha_1"; "SwitchGate_Gives_last_valid_cha_5"; "SwitchGate_Gives_last_valid_cha_10"];
event_info = [(1.3E-5, 1.0); (1.3E-5, 1.0); (1.3E-5, 1.0); (1.3E-5, 1.0); (1.3E-5, 1.0); (1.3E-5, 1.0); (1.3E-5, 1.0); (1.3E-5, 1.0); (1.3E-5, 1.0); (1.3E-5, 1.0); (1.3E-5, 1.0); (1.3E-5, 1.0)];
output_flows = ["ctrl_system_Brake_antiskid_comm_1"; "ctrl_system_Brake_antiskid_comm_2"; "ctrl_system_Brake_antiskid_comm_3"; "ctrl_system_Brake_antiskid_comm_4"; "Channel_Antiskid_command_to_pai_3"; "ctrl_system_Brake_antiskid_comm_5"; "ctrl_system_Brake_antiskid_comm_6"; "Channel_Antiskid_command_to_pai_1"; "ctrl_system_Brake_antiskid_comm_7"; "Channel_Antiskid_command_to_pai_2"; "ctrl_system_Brake_antiskid_comm"; "Channel_Antiskid_command_to_pai"];
formulas = [
(["ctrl_system_Brake_antiskid_comm_1"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_5"]; 
F["Channel_Brake_antiskid_command__1"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]; 
F["Channel_Brake_antiskid_command__1"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]]); 
(["ctrl_system_Brake_antiskid_comm_2"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_6"]; 
F["Channel_Brake_antiskid_command__2"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]; 
F["Channel_Brake_antiskid_command__2"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]]); 
(["ctrl_system_Brake_antiskid_comm_3"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_7"]; 
F["Channel_Brake_antiskid_command__3"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]; 
F["Channel_Brake_antiskid_command__3"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]]); 
(["ctrl_system_Brake_antiskid_comm_4"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_8"]; 
F["Channel_Brake_antiskid_command__4"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]; 
F["Channel_Brake_antiskid_command__4"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]]); 
(["Channel_Antiskid_command_to_pai_3"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_3"]; 
F["Channel_Antiskid_command_to_pai_3"; "contract violation"]; 
F["Channel_Antiskid_command_to_pai_3"; "contract violation"]]); 
(["ctrl_system_Brake_antiskid_comm_5"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_9"]; 
F["Channel_Brake_antiskid_command__5"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]; 
F["Channel_Brake_antiskid_command__5"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]]); 
(["ctrl_system_Brake_antiskid_comm_6"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_10"]; 
F["Channel_Brake_antiskid_command__6"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]; 
F["Channel_Brake_antiskid_command__6"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]]); 
(["Channel_Antiskid_command_to_pai_1"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_1"]; 
F["Channel_Antiskid_command_to_pai_1"; "contract violation"]; 
F["Channel_Antiskid_command_to_pai_1"; "contract violation"]]); 
(["ctrl_system_Brake_antiskid_comm_7"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_11"]; 
F["Channel_Brake_antiskid_command__7"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]; 
F["Channel_Brake_antiskid_command__7"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]]); 
(["Channel_Antiskid_command_to_pai_2"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_2"]; 
F["Channel_Antiskid_command_to_pai_2"; "contract violation"]; 
F["Channel_Antiskid_command_to_pai_2"; "contract violation"]]); 
(["ctrl_system_Brake_antiskid_comm"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha_4"]; 
F["Channel_Brake_antiskid_command_"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]; 
F["Channel_Brake_antiskid_command_"; "contract violation"]; 
F["Channel_If_there_is_no_power_so"; "contract violation"]]); 
(["Channel_Antiskid_command_to_pai"; "contract violation"],
Or[F["SwitchGate_Gives_last_valid_cha"]; 
F["Channel_Antiskid_command_to_pai"; "contract violation"]; 
F["Channel_Antiskid_command_to_pai"; "contract violation"]])]
}; 

{name = "ctrl_sys";
faults = ["contract violation"];
input_flows = ["ctrl_system_Brake_antiskid_comm_1"; "ctrl_system_Brake_antiskid_comm_2"; "ctrl_system_Brake_antiskid_comm_3"; "ctrl_system_Brake_antiskid_comm_4"; "Channel_Antiskid_command_to_pai_3"; "ctrl_system_Brake_antiskid_comm_5"; "ctrl_system_Brake_antiskid_comm_6"; "Channel_Antiskid_command_to_pai_1"; "ctrl_system_Brake_antiskid_comm_7"; "Channel_Antiskid_command_to_pai_2"; "ctrl_system_Brake_antiskid_comm"; "Channel_Antiskid_command_to_pai"];
basic_events = [];
event_info = [];
output_flows = ["ctrl_system_If_system_is_valid_"; "ctrl_system_Expected_antiskid_b_2"; "ctrl_system_Expected_antiskid_b_1"; "ctrl_system_1_Expected_antiskid"; "ctrl_system_Expected_antiskid_b"; "ctrl_system_Brake_antiskid_comm_1"; "ctrl_system_Brake_antiskid_comm_2"; "ctrl_system_Valid_antiskid_comm"; "ctrl_system_Brake_antiskid_comm_3"; "ctrl_system_Brake_antiskid_comm_4"; "ctrl_system_Brake_antiskid_comm_5"; "ctrl_system_Brake_antiskid_comm_6"; "ctrl_system_Brake_antiskid_comm_7"; "ctrl_system_Brake_antiskid_comm"];
formulas = [
(["ctrl_system_If_system_is_valid_"; "contract violation"],
Or[F["Channel_Antiskid_command_to_pai"; "contract violation"]; 
F["Channel_Antiskid_command_to_pai_1"; "contract violation"]; 
F["Channel_Antiskid_command_to_pai_2"; "contract violation"]; 
F["Channel_Antiskid_command_to_pai_3"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_1"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_2"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_3"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_4"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_5"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_6"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_7"; "contract violation"]]); 
(["ctrl_system_Expected_antiskid_b_2"; "contract violation"],
F["Channel_Antiskid_command_to_pai_3"; "contract violation"]); 
(["ctrl_system_Expected_antiskid_b_1"; "contract violation"],
F["Channel_Antiskid_command_to_pai_2"; "contract violation"]); 
(["ctrl_system_1_Expected_antiskid"; "contract violation"],
F["Channel_Antiskid_command_to_pai"; "contract violation"]); 
(["ctrl_system_Expected_antiskid_b"; "contract violation"],
F["Channel_Antiskid_command_to_pai_1"; "contract violation"]); 
(["ctrl_system_Brake_antiskid_comm_1"; "contract violation"],
F["ctrl_system_Brake_antiskid_comm_1"; "contract violation"]); 
(["ctrl_system_Brake_antiskid_comm_2"; "contract violation"],
F["ctrl_system_Brake_antiskid_comm_2"; "contract violation"]); 
(["ctrl_system_Valid_antiskid_comm"; "contract violation"],
Or[F["Channel_Antiskid_command_to_pai"; "contract violation"]; 
F["Channel_Antiskid_command_to_pai_1"; "contract violation"]; 
F["Channel_Antiskid_command_to_pai_2"; "contract violation"]; 
F["Channel_Antiskid_command_to_pai_3"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_1"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_2"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_3"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_4"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_5"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_6"; "contract violation"]; 
F["ctrl_system_Brake_antiskid_comm_7"; "contract violation"]]); 
(["ctrl_system_Brake_antiskid_comm_3"; "contract violation"],
F["ctrl_system_Brake_antiskid_comm_3"; "contract violation"]); 
(["ctrl_system_Brake_antiskid_comm_4"; "contract violation"],
F["ctrl_system_Brake_antiskid_comm_4"; "contract violation"]); 
(["ctrl_system_Brake_antiskid_comm_5"; "contract violation"],
F["ctrl_system_Brake_antiskid_comm_5"; "contract violation"]); 
(["ctrl_system_Brake_antiskid_comm_6"; "contract violation"],
F["ctrl_system_Brake_antiskid_comm_6"; "contract violation"]); 
(["ctrl_system_Brake_antiskid_comm_7"; "contract violation"],
F["ctrl_system_Brake_antiskid_comm_7"; "contract violation"]); 
(["ctrl_system_Brake_antiskid_comm"; "contract violation"],
F["ctrl_system_Brake_antiskid_comm"; "contract violation"])]
}; 

{name = "WBS.inst";
faults = ["contract violation"];
input_flows = ["PhysicalSystem_Wheel_4_braking_"; "PhysicalSystem_Wheel_1_braking_"; "PhysicalSystem_Wheel_5_force_An"; "PhysicalSystem_Wheel_8_force_An"; "PhysicalSystem_Wheel_2_force_An"; "PhysicalSystem_Wheel_7_braking_"; "PhysicalSystem_Wheel_1_force_An"; "PhysicalSystem_Wheel_4_force_An"; "PhysicalSystem_Wheel_2_braking_"; "PhysicalSystem_Wheel_6_braking_"; "ctrl_system_Brake_antiskid_comm_1"; "ctrl_system_Brake_antiskid_comm_2"; "ctrl_system_Brake_antiskid_comm_3"; "ctrl_system_Brake_antiskid_comm_4"; "ctrl_system_Brake_antiskid_comm_5"; "PhysicalSystem_Wheel_6_force_An"; "ctrl_system_Brake_antiskid_comm_6"; "PhysicalSystem_Wheel_3_braking_"; "ctrl_system_Brake_antiskid_comm_7"; "PhysicalSystem_Wheel_5_braking_"; "PhysicalSystem_Wheel_7_force_An"; "PhysicalSystem_Wheel_3_force_An"; "ctrl_system_Brake_antiskid_comm"; "PhysicalSystem_Wheel_8_braking_"];
basic_events = ["Sensor_No_Data_fault_wheel_sens_1"; "Sensor_No_Data_fault_wheel_sens_6"; "Sensor_No_Data_fault_wheel_sens_4"; "Sensor_No_Data_fault_wheel_sens_3"; "Sensor_No_Data_fault_wheel_sens"; "Sensor_No_Data_fault_wheel_sens_5"; "Sensor_No_Data_fault_wheel_sens_2"; "Sensor_No_Data_fault_wheel_sens_7"];
event_info = [(5.0E-6, 1.0); (5.0E-6, 1.0); (5.0E-6, 1.0); (5.0E-6, 1.0); (5.0E-6, 1.0); (5.0E-6, 1.0); (5.0E-6, 1.0); (5.0E-6, 1.0)];
output_flows = ["lemma_WBS_Inadvertent_braking_o_6"; "lemma_WBS_Inadvertent_braking_o"; "lemma_WBS_Inadvertent_braking_o_7"; "lemma_WBS_Inadvertent_braking_o_2"; "lemma_WBS_Inadvertent_braking_o_3"; "lemma_WBS_Inadvertent_braking_o_4"; "lemma_WBS_Inadvertent_braking_o_5"; "lemma_WBS_Asymmetrical_right_br"; "lemma_WBS_Never_loss_of_all_whe"; "lemma_WBS_Inadvertent_braking_o_1"; "lemma_WBS_Asymmetrical_left_bra"];
formulas = [
(["lemma_WBS_Inadvertent_braking_o_6"; "contract violation"],
Or[F["Sensor_No_Data_fault_wheel_sens_6"]; 
F["ctrl_system_Brake_antiskid_comm_6"; "contract violation"]; 
F["PhysicalSystem_Wheel_7_force_An"; "contract violation"]]); 
(["lemma_WBS_Inadvertent_braking_o"; "contract violation"],
Or[F["Sensor_No_Data_fault_wheel_sens"]; 
F["ctrl_system_Brake_antiskid_comm"; "contract violation"]; 
F["PhysicalSystem_Wheel_1_force_An"; "contract violation"]]); 
(["lemma_WBS_Inadvertent_braking_o_7"; "contract violation"],
Or[F["Sensor_No_Data_fault_wheel_sens_7"]; 
F["ctrl_system_Brake_antiskid_comm_7"; "contract violation"]; 
F["PhysicalSystem_Wheel_8_force_An"; "contract violation"]]); 
(["lemma_WBS_Inadvertent_braking_o_2"; "contract violation"],
Or[F["Sensor_No_Data_fault_wheel_sens_2"]; 
F["ctrl_system_Brake_antiskid_comm_2"; "contract violation"]; 
F["PhysicalSystem_Wheel_3_force_An"; "contract violation"]]); 
(["lemma_WBS_Inadvertent_braking_o_3"; "contract violation"],
Or[F["Sensor_No_Data_fault_wheel_sens_3"]; 
F["ctrl_system_Brake_antiskid_comm_3"; "contract violation"]; 
F["PhysicalSystem_Wheel_4_force_An"; "contract violation"]]); 
(["lemma_WBS_Inadvertent_braking_o_4"; "contract violation"],
Or[F["Sensor_No_Data_fault_wheel_sens_4"]; 
F["ctrl_system_Brake_antiskid_comm_4"; "contract violation"]; 
F["PhysicalSystem_Wheel_5_force_An"; "contract violation"]]); 
(["lemma_WBS_Inadvertent_braking_o_5"; "contract violation"],
Or[F["Sensor_No_Data_fault_wheel_sens_5"]; 
F["ctrl_system_Brake_antiskid_comm_5"; "contract violation"]; 
F["PhysicalSystem_Wheel_6_force_An"; "contract violation"]]); 
(["lemma_WBS_Asymmetrical_right_br"; "contract violation"],
Or[F["PhysicalSystem_Wheel_3_braking_"; "contract violation"]; 
F["PhysicalSystem_Wheel_4_braking_"; "contract violation"]; 
F["PhysicalSystem_Wheel_7_braking_"; "contract violation"]; 
F["PhysicalSystem_Wheel_8_braking_"; "contract violation"]]); 
(["lemma_WBS_Never_loss_of_all_whe"; "contract violation"],
F["PhysicalSystem_Wheel_1_braking_"; "contract violation"]); 
(["lemma_WBS_Inadvertent_braking_o_1"; "contract violation"],
Or[F["Sensor_No_Data_fault_wheel_sens_1"]; 
F["ctrl_system_Brake_antiskid_comm_1"; "contract violation"]; 
F["PhysicalSystem_Wheel_2_force_An"; "contract violation"]]); 
(["lemma_WBS_Asymmetrical_left_bra"; "contract violation"],
Or[F["PhysicalSystem_Wheel_1_braking_"; "contract violation"]; 
F["PhysicalSystem_Wheel_2_braking_"; "contract violation"]; 
F["PhysicalSystem_Wheel_5_braking_"; "contract violation"]; 
F["PhysicalSystem_Wheel_6_braking_"; "contract violation"]])]
}];;

(* ----- CHECK LIBRARY ----- *)
checkLibrary_componentUnique comp_library;;
checkLibrary_nonEmptyFaults comp_library;;
checkLibrary_disjointInputFlowsandBasicEvents comp_library;;
checkLibrary_listsAreConsistentLengths comp_library;;
checkLibrary_allOutputFaultsHaveFormulas comp_library;;
checkLibrary_formulasMakeSense comp_library;;


(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Inadvertent_braking_o = 
{instances = 
[makeInstance "normal_sys" "normal_sys"();
makeInstance "alt_sys" "alt_sys"();
makeInstance "wheel_brake1" "wheel_brake1"();
makeInstance "wheel_brake2" "wheel_brake2"();
makeInstance "wheel_brake3" "wheel_brake3"();
makeInstance "wheel_brake4" "wheel_brake4"();
makeInstance "wheel_brake5" "wheel_brake5"();
makeInstance "wheel_brake6" "wheel_brake6"();
makeInstance "wheel_brake7" "wheel_brake7"();
makeInstance "wheel_brake8" "wheel_brake8"();
makeInstance "phys_sys" "phys_sys"();
makeInstance "w1_w5_cmd_sys" "w1_w5_cmd_sys"();
makeInstance "w2_w6_cmd_sys" "w2_w6_cmd_sys"();
makeInstance "w3_w7_cmd_sys" "w3_w7_cmd_sys"();
makeInstance "w4_w8_cmd_sys" "w4_w8_cmd_sys"();
makeInstance "command_sys" "command_sys"();
makeInstance "channel1" "channel1"();
makeInstance "w1_w5_cmd_sys" "w1_w5_cmd_sys"();
makeInstance "w2_w6_cmd_sys" "w2_w6_cmd_sys"();
makeInstance "w3_w7_cmd_sys" "w3_w7_cmd_sys"();
makeInstance "w4_w8_cmd_sys" "w4_w8_cmd_sys"();
makeInstance "command_sys" "command_sys"();
makeInstance "channel2" "channel2"();
makeInstance "bscu" "bscu"();
makeInstance "ctrl_sys" "ctrl_sys"();
makeInstance "WBS.inst" "WBS.inst"();
];
connections = 
[(("phys_sys", "AlternateBrakeSystem_Pair_3_7_T"),("alt_sys", "AlternateBrakeSystem_Pair_3_7_T")); (("phys_sys", "NormalBrakeSys_W7_Hydraulic_pre"),("normal_sys", "NormalBrakeSys_W7_Hydraulic_pre")); (("phys_sys", "AlternateBrakeSystem_Pair_2_6_T"),("alt_sys", "AlternateBrakeSystem_Pair_2_6_T")); (("phys_sys", "NormalBrakeSys_W8_Hydraulic_pre"),("normal_sys", "NormalBrakeSys_W8_Hydraulic_pre")); (("phys_sys", "NormalBrakeSys_W2_Hydraulic_pre"),("normal_sys", "NormalBrakeSys_W2_Hydraulic_pre")); (("phys_sys", "NormalBrakeSys_W1_Hydraulic_pre"),("normal_sys", "NormalBrakeSys_W1_Hydraulic_pre")); (("phys_sys", "WheelBrake_braking_force_is_pos"),("wheel_brake1", "WheelBrake_braking_force_is_pos")); (("phys_sys", "WheelBrake_braking_force_is_pos"),("wheel_brake2", "WheelBrake_braking_force_is_pos")); (("phys_sys", "WheelBrake_braking_force_is_pos"),("wheel_brake3", "WheelBrake_braking_force_is_pos")); (("phys_sys", "WheelBrake_braking_force_is_pos"),("wheel_brake4", "WheelBrake_braking_force_is_pos")); (("phys_sys", "WheelBrake_braking_force_is_pos"),("wheel_brake5", "WheelBrake_braking_force_is_pos")); (("phys_sys", "WheelBrake_braking_force_is_pos"),("wheel_brake6", "WheelBrake_braking_force_is_pos")); (("phys_sys", "WheelBrake_braking_force_is_pos"),("wheel_brake7", "WheelBrake_braking_force_is_pos")); (("phys_sys", "WheelBrake_braking_force_is_pos"),("wheel_brake8", "WheelBrake_braking_force_is_pos")); (("phys_sys", "AlternateBrakeSystem_Pair_4_8_T"),("alt_sys", "AlternateBrakeSystem_Pair_4_8_T")); (("phys_sys", "NormalBrakeSys_W4_Hydraulic_pre"),("normal_sys", "NormalBrakeSys_W4_Hydraulic_pre")); (("phys_sys", "AlternateBrakeSystem_Pair_1_5_T"),("alt_sys", "AlternateBrakeSystem_Pair_1_5_T")); (("phys_sys", "NormalBrakeSys_W3_Hydraulic_pre"),("normal_sys", "NormalBrakeSys_W3_Hydraulic_pre")); (("phys_sys", "NormalBrakeSys_W5_Hydraulic_pre"),("normal_sys", "NormalBrakeSys_W5_Hydraulic_pre")); (("phys_sys", "NormalBrakeSys_W6_Hydraulic_pre"),("normal_sys", "NormalBrakeSys_W6_Hydraulic_pre")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("channel1", "CommandSystem_Wheel_2_brake_com"),("command_sys", "CommandSystem_Wheel_2_brake_com")); (("channel1", "CommandSystem_Wheel_2_brake_com"),("command_sys", "CommandSystem_Wheel_2_brake_com")); (("channel1", "CommandSystem_Wheel_6_brake_com"),("command_sys", "CommandSystem_Wheel_6_brake_com")); (("channel1", "CommandSystem_Wheel_6_brake_com"),("command_sys", "CommandSystem_Wheel_6_brake_com")); (("channel1", "CommandSystem_Wheel_7_brake_com"),("command_sys", "CommandSystem_Wheel_7_brake_com")); (("channel1", "CommandSystem_Wheel_7_brake_com"),("command_sys", "CommandSystem_Wheel_7_brake_com")); (("channel1", "CommandSystem_Wheel_3_brake_com"),("command_sys", "CommandSystem_Wheel_3_brake_com")); (("channel1", "CommandSystem_Wheel_3_brake_com"),("command_sys", "CommandSystem_Wheel_3_brake_com")); (("channel1", "CommandSystem_Pair_1_5_Create_a"),("command_sys", "CommandSystem_Pair_1_5_Create_a")); (("channel1", "CommandSystem_Pair_1_5_Create_a"),("command_sys", "CommandSystem_Pair_1_5_Create_a")); (("channel1", "CommandSystem_Pair_4_8_Create_a"),("command_sys", "CommandSystem_Pair_4_8_Create_a")); (("channel1", "CommandSystem_Pair_4_8_Create_a"),("command_sys", "CommandSystem_Pair_4_8_Create_a")); (("channel1", "CommandSystem_Wheel_1_brake_com"),("command_sys", "CommandSystem_Wheel_1_brake_com")); (("channel1", "CommandSystem_Wheel_1_brake_com"),("command_sys", "CommandSystem_Wheel_1_brake_com")); (("channel1", "CommandSystem_Pair_3_7_Create_a"),("command_sys", "CommandSystem_Pair_3_7_Create_a")); (("channel1", "CommandSystem_Pair_3_7_Create_a"),("command_sys", "CommandSystem_Pair_3_7_Create_a")); (("channel1", "CommandSystem_Wheel_4_brake_com"),("command_sys", "CommandSystem_Wheel_4_brake_com")); (("channel1", "CommandSystem_Wheel_4_brake_com"),("command_sys", "CommandSystem_Wheel_4_brake_com")); (("channel1", "CommandSystem_Wheel_8_brake_com"),("command_sys", "CommandSystem_Wheel_8_brake_com")); (("channel1", "CommandSystem_Wheel_8_brake_com"),("command_sys", "CommandSystem_Wheel_8_brake_com")); (("channel1", "CommandSystem_Pair_2_6_Create_a"),("command_sys", "CommandSystem_Pair_2_6_Create_a")); (("channel1", "CommandSystem_Pair_2_6_Create_a"),("command_sys", "CommandSystem_Pair_2_6_Create_a")); (("channel1", "CommandSystem_Wheel_5_brake_com"),("command_sys", "CommandSystem_Wheel_5_brake_com")); (("channel1", "CommandSystem_Wheel_5_brake_com"),("command_sys", "CommandSystem_Wheel_5_brake_com")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_3_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_3_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_1_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_1_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w1_w5_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w2_w6_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w3_w7_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("command_sys", "WheelPairCommandSystem_2_Assign"),("w4_w8_cmd_sys", "WheelPairCommandSystem_2_Assign")); (("channel2", "CommandSystem_Wheel_2_brake_com"),("command_sys", "CommandSystem_Wheel_2_brake_com")); (("channel2", "CommandSystem_Wheel_2_brake_com"),("command_sys", "CommandSystem_Wheel_2_brake_com")); (("channel2", "CommandSystem_Wheel_6_brake_com"),("command_sys", "CommandSystem_Wheel_6_brake_com")); (("channel2", "CommandSystem_Wheel_6_brake_com"),("command_sys", "CommandSystem_Wheel_6_brake_com")); (("channel2", "CommandSystem_Wheel_7_brake_com"),("command_sys", "CommandSystem_Wheel_7_brake_com")); (("channel2", "CommandSystem_Wheel_7_brake_com"),("command_sys", "CommandSystem_Wheel_7_brake_com")); (("channel2", "CommandSystem_Wheel_3_brake_com"),("command_sys", "CommandSystem_Wheel_3_brake_com")); (("channel2", "CommandSystem_Wheel_3_brake_com"),("command_sys", "CommandSystem_Wheel_3_brake_com")); (("channel2", "CommandSystem_Pair_1_5_Create_a"),("command_sys", "CommandSystem_Pair_1_5_Create_a")); (("channel2", "CommandSystem_Pair_1_5_Create_a"),("command_sys", "CommandSystem_Pair_1_5_Create_a")); (("channel2", "CommandSystem_Pair_4_8_Create_a"),("command_sys", "CommandSystem_Pair_4_8_Create_a")); (("channel2", "CommandSystem_Pair_4_8_Create_a"),("command_sys", "CommandSystem_Pair_4_8_Create_a")); (("channel2", "CommandSystem_Wheel_1_brake_com"),("command_sys", "CommandSystem_Wheel_1_brake_com")); (("channel2", "CommandSystem_Wheel_1_brake_com"),("command_sys", "CommandSystem_Wheel_1_brake_com")); (("channel2", "CommandSystem_Pair_3_7_Create_a"),("command_sys", "CommandSystem_Pair_3_7_Create_a")); (("channel2", "CommandSystem_Pair_3_7_Create_a"),("command_sys", "CommandSystem_Pair_3_7_Create_a")); (("channel2", "CommandSystem_Wheel_4_brake_com"),("command_sys", "CommandSystem_Wheel_4_brake_com")); (("channel2", "CommandSystem_Wheel_4_brake_com"),("command_sys", "CommandSystem_Wheel_4_brake_com")); (("channel2", "CommandSystem_Wheel_8_brake_com"),("command_sys", "CommandSystem_Wheel_8_brake_com")); (("channel2", "CommandSystem_Wheel_8_brake_com"),("command_sys", "CommandSystem_Wheel_8_brake_com")); (("channel2", "CommandSystem_Pair_2_6_Create_a"),("command_sys", "CommandSystem_Pair_2_6_Create_a")); (("channel2", "CommandSystem_Pair_2_6_Create_a"),("command_sys", "CommandSystem_Pair_2_6_Create_a")); (("channel2", "CommandSystem_Wheel_5_brake_com"),("command_sys", "CommandSystem_Wheel_5_brake_com")); (("channel2", "CommandSystem_Wheel_5_brake_com"),("command_sys", "CommandSystem_Wheel_5_brake_com")); (("bscu", "Channel_Brake_antiskid_command__5"),("channel1", "Channel_Brake_antiskid_command__5")); (("bscu", "Channel_Brake_antiskid_command__5"),("channel2", "Channel_Brake_antiskid_command__5")); (("bscu", "Channel_Brake_antiskid_command__6"),("channel1", "Channel_Brake_antiskid_command__6")); (("bscu", "Channel_Brake_antiskid_command__6"),("channel2", "Channel_Brake_antiskid_command__6")); (("bscu", "Channel_Brake_antiskid_command__7"),("channel1", "Channel_Brake_antiskid_command__7")); (("bscu", "Channel_Brake_antiskid_command__7"),("channel2", "Channel_Brake_antiskid_command__7")); (("bscu", "Channel_Brake_antiskid_command__1"),("channel1", "Channel_Brake_antiskid_command__1")); (("bscu", "Channel_Brake_antiskid_command__1"),("channel2", "Channel_Brake_antiskid_command__1")); (("bscu", "Channel_Brake_antiskid_command__2"),("channel1", "Channel_Brake_antiskid_command__2")); (("bscu", "Channel_Brake_antiskid_command__2"),("channel2", "Channel_Brake_antiskid_command__2")); (("bscu", "Channel_Brake_antiskid_command__3"),("channel1", "Channel_Brake_antiskid_command__3")); (("bscu", "Channel_Brake_antiskid_command__3"),("channel2", "Channel_Brake_antiskid_command__3")); (("bscu", "Channel_Brake_antiskid_command__4"),("channel1", "Channel_Brake_antiskid_command__4")); (("bscu", "Channel_Brake_antiskid_command__4"),("channel2", "Channel_Brake_antiskid_command__4")); (("bscu", "Channel_If_there_is_no_power_so"),("channel1", "Channel_If_there_is_no_power_so")); (("bscu", "Channel_If_there_is_no_power_so"),("channel2", "Channel_If_there_is_no_power_so")); (("bscu", "Channel_Antiskid_command_to_pai"),("channel1", "Channel_Antiskid_command_to_pai")); (("bscu", "Channel_Antiskid_command_to_pai"),("channel2", "Channel_Antiskid_command_to_pai")); (("bscu", "Channel_Antiskid_command_to_pai"),("bscu", "Channel_Antiskid_command_to_pai")); (("bscu", "Channel_Brake_antiskid_command_"),("channel1", "Channel_Brake_antiskid_command_")); (("bscu", "Channel_Brake_antiskid_command_"),("channel2", "Channel_Brake_antiskid_command_")); (("bscu", "Channel_Antiskid_command_to_pai_3"),("channel1", "Channel_Antiskid_command_to_pai_3")); (("bscu", "Channel_Antiskid_command_to_pai_3"),("channel2", "Channel_Antiskid_command_to_pai_3")); (("bscu", "Channel_Antiskid_command_to_pai_3"),("bscu", "Channel_Antiskid_command_to_pai_3")); (("bscu", "Channel_Antiskid_command_to_pai_1"),("channel1", "Channel_Antiskid_command_to_pai_1")); (("bscu", "Channel_Antiskid_command_to_pai_1"),("channel2", "Channel_Antiskid_command_to_pai_1")); (("bscu", "Channel_Antiskid_command_to_pai_1"),("bscu", "Channel_Antiskid_command_to_pai_1")); (("bscu", "Channel_Antiskid_command_to_pai_2"),("channel1", "Channel_Antiskid_command_to_pai_2")); (("bscu", "Channel_Antiskid_command_to_pai_2"),("channel2", "Channel_Antiskid_command_to_pai_2")); (("bscu", "Channel_Antiskid_command_to_pai_2"),("bscu", "Channel_Antiskid_command_to_pai_2")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_1"),("bscu", "ctrl_system_Brake_antiskid_comm_1")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_1"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_1")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_2"),("bscu", "ctrl_system_Brake_antiskid_comm_2")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_2"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_2")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_3"),("bscu", "ctrl_system_Brake_antiskid_comm_3")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_3"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_3")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_4"),("bscu", "ctrl_system_Brake_antiskid_comm_4")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_4"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_4")); (("ctrl_sys", "Channel_Antiskid_command_to_pai_3"),("channel1", "Channel_Antiskid_command_to_pai_3")); (("ctrl_sys", "Channel_Antiskid_command_to_pai_3"),("channel2", "Channel_Antiskid_command_to_pai_3")); (("ctrl_sys", "Channel_Antiskid_command_to_pai_3"),("bscu", "Channel_Antiskid_command_to_pai_3")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_5"),("bscu", "ctrl_system_Brake_antiskid_comm_5")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_5"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_5")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_6"),("bscu", "ctrl_system_Brake_antiskid_comm_6")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_6"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_6")); (("ctrl_sys", "Channel_Antiskid_command_to_pai_1"),("channel1", "Channel_Antiskid_command_to_pai_1")); (("ctrl_sys", "Channel_Antiskid_command_to_pai_1"),("channel2", "Channel_Antiskid_command_to_pai_1")); (("ctrl_sys", "Channel_Antiskid_command_to_pai_1"),("bscu", "Channel_Antiskid_command_to_pai_1")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_7"),("bscu", "ctrl_system_Brake_antiskid_comm_7")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm_7"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_7")); (("ctrl_sys", "Channel_Antiskid_command_to_pai_2"),("channel1", "Channel_Antiskid_command_to_pai_2")); (("ctrl_sys", "Channel_Antiskid_command_to_pai_2"),("channel2", "Channel_Antiskid_command_to_pai_2")); (("ctrl_sys", "Channel_Antiskid_command_to_pai_2"),("bscu", "Channel_Antiskid_command_to_pai_2")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm"),("bscu", "ctrl_system_Brake_antiskid_comm")); (("ctrl_sys", "ctrl_system_Brake_antiskid_comm"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm")); (("ctrl_sys", "Channel_Antiskid_command_to_pai"),("channel1", "Channel_Antiskid_command_to_pai")); (("ctrl_sys", "Channel_Antiskid_command_to_pai"),("channel2", "Channel_Antiskid_command_to_pai")); (("ctrl_sys", "Channel_Antiskid_command_to_pai"),("bscu", "Channel_Antiskid_command_to_pai")); (("WBS.inst", "PhysicalSystem_Wheel_4_braking_"),("phys_sys", "PhysicalSystem_Wheel_4_braking_")); (("WBS.inst", "PhysicalSystem_Wheel_1_braking_"),("phys_sys", "PhysicalSystem_Wheel_1_braking_")); (("WBS.inst", "PhysicalSystem_Wheel_5_force_An"),("phys_sys", "PhysicalSystem_Wheel_5_force_An")); (("WBS.inst", "PhysicalSystem_Wheel_8_force_An"),("phys_sys", "PhysicalSystem_Wheel_8_force_An")); (("WBS.inst", "PhysicalSystem_Wheel_2_force_An"),("phys_sys", "PhysicalSystem_Wheel_2_force_An")); (("WBS.inst", "PhysicalSystem_Wheel_7_braking_"),("phys_sys", "PhysicalSystem_Wheel_7_braking_")); (("WBS.inst", "PhysicalSystem_Wheel_1_force_An"),("phys_sys", "PhysicalSystem_Wheel_1_force_An")); (("WBS.inst", "PhysicalSystem_Wheel_4_force_An"),("phys_sys", "PhysicalSystem_Wheel_4_force_An")); (("WBS.inst", "PhysicalSystem_Wheel_2_braking_"),("phys_sys", "PhysicalSystem_Wheel_2_braking_")); (("WBS.inst", "PhysicalSystem_Wheel_6_braking_"),("phys_sys", "PhysicalSystem_Wheel_6_braking_")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_1"),("bscu", "ctrl_system_Brake_antiskid_comm_1")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_1"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_1")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_2"),("bscu", "ctrl_system_Brake_antiskid_comm_2")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_2"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_2")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_3"),("bscu", "ctrl_system_Brake_antiskid_comm_3")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_3"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_3")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_4"),("bscu", "ctrl_system_Brake_antiskid_comm_4")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_4"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_4")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_5"),("bscu", "ctrl_system_Brake_antiskid_comm_5")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_5"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_5")); (("WBS.inst", "PhysicalSystem_Wheel_6_force_An"),("phys_sys", "PhysicalSystem_Wheel_6_force_An")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_6"),("bscu", "ctrl_system_Brake_antiskid_comm_6")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_6"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_6")); (("WBS.inst", "PhysicalSystem_Wheel_3_braking_"),("phys_sys", "PhysicalSystem_Wheel_3_braking_")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_7"),("bscu", "ctrl_system_Brake_antiskid_comm_7")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm_7"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm_7")); (("WBS.inst", "PhysicalSystem_Wheel_5_braking_"),("phys_sys", "PhysicalSystem_Wheel_5_braking_")); (("WBS.inst", "PhysicalSystem_Wheel_7_force_An"),("phys_sys", "PhysicalSystem_Wheel_7_force_An")); (("WBS.inst", "PhysicalSystem_Wheel_3_force_An"),("phys_sys", "PhysicalSystem_Wheel_3_force_An")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm"),("bscu", "ctrl_system_Brake_antiskid_comm")); (("WBS.inst", "ctrl_system_Brake_antiskid_comm"),("ctrl_sys", "ctrl_system_Brake_antiskid_comm")); (("WBS.inst", "PhysicalSystem_Wheel_8_braking_"),("phys_sys", "PhysicalSystem_Wheel_8_braking_")); ];
top_fault = ("WBS.inst", F["lemma_WBS_Inadvertent_braking_o"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Inadvertent_braking_o;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o comp_library;;
checkModel_validConnections model_lemma_WBS_Inadvertent_braking_o comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Inadvertent_braking_o;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Inadvertent_braking_o "model_lemma_WBS_Inadvertent_braking_o_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o "model_lemma_WBS_Inadvertent_braking_o_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o "model_lemma_WBS_Inadvertent_braking_o_fault_propagation.gv";;

let model_lemma_WBS_Inadvertent_braking_o_ftree = model_to_ftree comp_library model_lemma_WBS_Inadvertent_braking_o;;
probErrorCutImp model_lemma_WBS_Inadvertent_braking_o_ftree;;
probErrorCut model_lemma_WBS_Inadvertent_braking_o_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Inadvertent_braking_o_direct_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Inadvertent_braking_o_optimized_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Inadvertent_braking_o_1 = 
{instances = model_lemma_WBS_Inadvertent_braking_o.instances;
connections=model_lemma_WBS_Inadvertent_braking_o.connections;
top_fault = ("WBS.inst", F["lemma_WBS_Inadvertent_braking_o_1"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Inadvertent_braking_o_1;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_1 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_1 comp_library;;
checkModel_validConnections model_lemma_WBS_Inadvertent_braking_o_1 comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Inadvertent_braking_o_1;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Inadvertent_braking_o_1 "model_lemma_WBS_Inadvertent_braking_o_1_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_1 "model_lemma_WBS_Inadvertent_braking_o_1_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_1 "model_lemma_WBS_Inadvertent_braking_o_1_fault_propagation.gv";;

let model_lemma_WBS_Inadvertent_braking_o_1_ftree = model_to_ftree comp_library model_lemma_WBS_Inadvertent_braking_o_1;;
probErrorCutImp model_lemma_WBS_Inadvertent_braking_o_1_ftree;;
probErrorCut model_lemma_WBS_Inadvertent_braking_o_1_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Inadvertent_braking_o_1_direct_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_1_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Inadvertent_braking_o_1_optimized_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_1_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Inadvertent_braking_o_2 = 
{instances = model_lemma_WBS_Inadvertent_braking_o.instances;
connections=model_lemma_WBS_Inadvertent_braking_o.connections;
top_fault = ("WBS.inst", F["lemma_WBS_Inadvertent_braking_o_2"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Inadvertent_braking_o_2;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_2 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_2 comp_library;;
checkModel_validConnections model_lemma_WBS_Inadvertent_braking_o_2 comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Inadvertent_braking_o_2;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Inadvertent_braking_o_2 "model_lemma_WBS_Inadvertent_braking_o_2_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_2 "model_lemma_WBS_Inadvertent_braking_o_2_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_2 "model_lemma_WBS_Inadvertent_braking_o_2_fault_propagation.gv";;

let model_lemma_WBS_Inadvertent_braking_o_2_ftree = model_to_ftree comp_library model_lemma_WBS_Inadvertent_braking_o_2;;
probErrorCutImp model_lemma_WBS_Inadvertent_braking_o_2_ftree;;
probErrorCut model_lemma_WBS_Inadvertent_braking_o_2_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Inadvertent_braking_o_2_direct_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_2_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Inadvertent_braking_o_2_optimized_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_2_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Inadvertent_braking_o_3 = 
{instances = model_lemma_WBS_Inadvertent_braking_o.instances;
connections=model_lemma_WBS_Inadvertent_braking_o.connections;
top_fault = ("WBS.inst", F["lemma_WBS_Inadvertent_braking_o_3"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Inadvertent_braking_o_3;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_3 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_3 comp_library;;
checkModel_validConnections model_lemma_WBS_Inadvertent_braking_o_3 comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Inadvertent_braking_o_3;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Inadvertent_braking_o_3 "model_lemma_WBS_Inadvertent_braking_o_3_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_3 "model_lemma_WBS_Inadvertent_braking_o_3_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_3 "model_lemma_WBS_Inadvertent_braking_o_3_fault_propagation.gv";;

let model_lemma_WBS_Inadvertent_braking_o_3_ftree = model_to_ftree comp_library model_lemma_WBS_Inadvertent_braking_o_3;;
probErrorCutImp model_lemma_WBS_Inadvertent_braking_o_3_ftree;;
probErrorCut model_lemma_WBS_Inadvertent_braking_o_3_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Inadvertent_braking_o_3_direct_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_3_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Inadvertent_braking_o_3_optimized_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_3_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Inadvertent_braking_o_4 = 
{instances = model_lemma_WBS_Inadvertent_braking_o.instances;
connections=model_lemma_WBS_Inadvertent_braking_o.connections;
top_fault = ("WBS.inst", F["lemma_WBS_Inadvertent_braking_o_4"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Inadvertent_braking_o_4;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_4 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_4 comp_library;;
checkModel_validConnections model_lemma_WBS_Inadvertent_braking_o_4 comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Inadvertent_braking_o_4;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Inadvertent_braking_o_4 "model_lemma_WBS_Inadvertent_braking_o_4_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_4 "model_lemma_WBS_Inadvertent_braking_o_4_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_4 "model_lemma_WBS_Inadvertent_braking_o_4_fault_propagation.gv";;

let model_lemma_WBS_Inadvertent_braking_o_4_ftree = model_to_ftree comp_library model_lemma_WBS_Inadvertent_braking_o_4;;
probErrorCutImp model_lemma_WBS_Inadvertent_braking_o_4_ftree;;
probErrorCut model_lemma_WBS_Inadvertent_braking_o_4_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Inadvertent_braking_o_4_direct_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_4_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Inadvertent_braking_o_4_optimized_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_4_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Inadvertent_braking_o_5 = 
{instances = model_lemma_WBS_Inadvertent_braking_o.instances;
connections=model_lemma_WBS_Inadvertent_braking_o.connections;
top_fault = ("WBS.inst", F["lemma_WBS_Inadvertent_braking_o_5"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Inadvertent_braking_o_5;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_5 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_5 comp_library;;
checkModel_validConnections model_lemma_WBS_Inadvertent_braking_o_5 comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Inadvertent_braking_o_5;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Inadvertent_braking_o_5 "model_lemma_WBS_Inadvertent_braking_o_5_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_5 "model_lemma_WBS_Inadvertent_braking_o_5_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_5 "model_lemma_WBS_Inadvertent_braking_o_5_fault_propagation.gv";;

let model_lemma_WBS_Inadvertent_braking_o_5_ftree = model_to_ftree comp_library model_lemma_WBS_Inadvertent_braking_o_5;;
probErrorCutImp model_lemma_WBS_Inadvertent_braking_o_5_ftree;;
probErrorCut model_lemma_WBS_Inadvertent_braking_o_5_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Inadvertent_braking_o_5_direct_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_5_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Inadvertent_braking_o_5_optimized_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_5_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Inadvertent_braking_o_6 = 
{instances = model_lemma_WBS_Inadvertent_braking_o.instances;
connections=model_lemma_WBS_Inadvertent_braking_o.connections;
top_fault = ("WBS.inst", F["lemma_WBS_Inadvertent_braking_o_6"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Inadvertent_braking_o_6;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_6 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_6 comp_library;;
checkModel_validConnections model_lemma_WBS_Inadvertent_braking_o_6 comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Inadvertent_braking_o_6;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Inadvertent_braking_o_6 "model_lemma_WBS_Inadvertent_braking_o_6_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_6 "model_lemma_WBS_Inadvertent_braking_o_6_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_6 "model_lemma_WBS_Inadvertent_braking_o_6_fault_propagation.gv";;

let model_lemma_WBS_Inadvertent_braking_o_6_ftree = model_to_ftree comp_library model_lemma_WBS_Inadvertent_braking_o_6;;
probErrorCutImp model_lemma_WBS_Inadvertent_braking_o_6_ftree;;
probErrorCut model_lemma_WBS_Inadvertent_braking_o_6_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Inadvertent_braking_o_6_direct_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_6_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Inadvertent_braking_o_6_optimized_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_6_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Inadvertent_braking_o_7 = 
{instances = model_lemma_WBS_Inadvertent_braking_o.instances;
connections=model_lemma_WBS_Inadvertent_braking_o.connections;
top_fault = ("WBS.inst", F["lemma_WBS_Inadvertent_braking_o_7"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Inadvertent_braking_o_7;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_7 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Inadvertent_braking_o_7 comp_library;;
checkModel_validConnections model_lemma_WBS_Inadvertent_braking_o_7 comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Inadvertent_braking_o_7;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Inadvertent_braking_o_7 "model_lemma_WBS_Inadvertent_braking_o_7_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_7 "model_lemma_WBS_Inadvertent_braking_o_7_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Inadvertent_braking_o_7 "model_lemma_WBS_Inadvertent_braking_o_7_fault_propagation.gv";;

let model_lemma_WBS_Inadvertent_braking_o_7_ftree = model_to_ftree comp_library model_lemma_WBS_Inadvertent_braking_o_7;;
probErrorCutImp model_lemma_WBS_Inadvertent_braking_o_7_ftree;;
probErrorCut model_lemma_WBS_Inadvertent_braking_o_7_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Inadvertent_braking_o_7_direct_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_7_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Inadvertent_braking_o_7_optimized_ftree.gv" model_lemma_WBS_Inadvertent_braking_o_7_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Asymmetrical_left_bra = 
{instances = model_lemma_WBS_Inadvertent_braking_o.instances;
connections=model_lemma_WBS_Inadvertent_braking_o.connections;
top_fault = ("WBS.inst", F["lemma_WBS_Asymmetrical_left_bra"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Asymmetrical_left_bra;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Asymmetrical_left_bra comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Asymmetrical_left_bra comp_library;;
checkModel_validConnections model_lemma_WBS_Asymmetrical_left_bra comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Asymmetrical_left_bra;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Asymmetrical_left_bra "model_lemma_WBS_Asymmetrical_left_bra_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Asymmetrical_left_bra "model_lemma_WBS_Asymmetrical_left_bra_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Asymmetrical_left_bra "model_lemma_WBS_Asymmetrical_left_bra_fault_propagation.gv";;

let model_lemma_WBS_Asymmetrical_left_bra_ftree = model_to_ftree comp_library model_lemma_WBS_Asymmetrical_left_bra;;
probErrorCutImp model_lemma_WBS_Asymmetrical_left_bra_ftree;;
probErrorCut model_lemma_WBS_Asymmetrical_left_bra_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Asymmetrical_left_bra_direct_ftree.gv" model_lemma_WBS_Asymmetrical_left_bra_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Asymmetrical_left_bra_optimized_ftree.gv" model_lemma_WBS_Asymmetrical_left_bra_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Asymmetrical_right_br = 
{instances = model_lemma_WBS_Inadvertent_braking_o.instances;
connections=model_lemma_WBS_Inadvertent_braking_o.connections;
top_fault = ("WBS.inst", F["lemma_WBS_Asymmetrical_right_br"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Asymmetrical_right_br;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Asymmetrical_right_br comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Asymmetrical_right_br comp_library;;
checkModel_validConnections model_lemma_WBS_Asymmetrical_right_br comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Asymmetrical_right_br;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Asymmetrical_right_br "model_lemma_WBS_Asymmetrical_right_br_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Asymmetrical_right_br "model_lemma_WBS_Asymmetrical_right_br_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Asymmetrical_right_br "model_lemma_WBS_Asymmetrical_right_br_fault_propagation.gv";;

let model_lemma_WBS_Asymmetrical_right_br_ftree = model_to_ftree comp_library model_lemma_WBS_Asymmetrical_right_br;;
probErrorCutImp model_lemma_WBS_Asymmetrical_right_br_ftree;;
probErrorCut model_lemma_WBS_Asymmetrical_right_br_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Asymmetrical_right_br_direct_ftree.gv" model_lemma_WBS_Asymmetrical_right_br_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Asymmetrical_right_br_optimized_ftree.gv" model_lemma_WBS_Asymmetrical_right_br_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_lemma_WBS_Never_loss_of_all_whe = 
{instances = model_lemma_WBS_Inadvertent_braking_o.instances;
connections=model_lemma_WBS_Inadvertent_braking_o.connections;
top_fault = ("WBS.inst", F["lemma_WBS_Never_loss_of_all_whe"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_lemma_WBS_Never_loss_of_all_whe;;
checkModel_cnameInstanceIsDefinedInLibrary model_lemma_WBS_Never_loss_of_all_whe comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_lemma_WBS_Never_loss_of_all_whe comp_library;;
checkModel_validConnections model_lemma_WBS_Never_loss_of_all_whe comp_library;;
checkModel_inputFlowUnique model_lemma_WBS_Never_loss_of_all_whe;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_lemma_WBS_Never_loss_of_all_whe "model_lemma_WBS_Never_loss_of_all_whe_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_lemma_WBS_Never_loss_of_all_whe "model_lemma_WBS_Never_loss_of_all_whe_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_lemma_WBS_Never_loss_of_all_whe "model_lemma_WBS_Never_loss_of_all_whe_fault_propagation.gv";;

let model_lemma_WBS_Never_loss_of_all_whe_ftree = model_to_ftree comp_library model_lemma_WBS_Never_loss_of_all_whe;;
probErrorCutImp model_lemma_WBS_Never_loss_of_all_whe_ftree;;
probErrorCut model_lemma_WBS_Never_loss_of_all_whe_ftree;;
dot_gen_show_direct_tree_file "model_lemma_WBS_Never_loss_of_all_whe_direct_ftree.gv" model_lemma_WBS_Never_loss_of_all_whe_ftree ;;
dot_gen_show_tree_file "model_lemma_WBS_Never_loss_of_all_whe_optimized_ftree.gv" model_lemma_WBS_Never_loss_of_all_whe_ftree ;;

