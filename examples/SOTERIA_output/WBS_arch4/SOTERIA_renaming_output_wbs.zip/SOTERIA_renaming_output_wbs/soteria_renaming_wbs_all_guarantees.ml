#use "top.ml";;
(* ----- COMPONENT LIBRARY ----- *)

let comp_library = 
  [
{name = "normal_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__mv6__mv6__fault_4";
"fault__independently__active__mv3__mv3__fault_4";
"fault__independently__active__mv8__mv8__fault_4";
"fault__independently__active__mv5__mv5__fault_4";
"fault__independently__active__mv2__mv2__fault_4";
"fault__independently__active__mv4__mv4__fault_4";
"fault__independently__active__mv1__mv1__fault_4";
"fault__independently__active__mv7__mv7__fault_4"];
event_info = [(3.25E-6, 1.0);
(3.25E-6, 1.0);
(3.25E-6, 1.0);
(3.25E-6, 1.0);
(3.25E-6, 1.0);
(3.25E-6, 1.0);
(3.25E-6, 1.0);
(3.25E-6, 1.0)];
output_flows = ["normal_sys___GUARANTEE6";
"normal_sys___GUARANTEE7";
"normal_sys___GUARANTEE2";
"normal_sys___GUARANTEE3";
"normal_sys___GUARANTEE4";
"normal_sys___GUARANTEE5";
"normal_sys___GUARANTEE0";
"normal_sys___GUARANTEE1"];
formulas = [
(["normal_sys___GUARANTEE6"; "contract violation"],
F["fault__independently__active__mv7__mv7__fault_4"]);
(["normal_sys___GUARANTEE7"; "contract violation"],
F["fault__independently__active__mv8__mv8__fault_4"]);
(["normal_sys___GUARANTEE2"; "contract violation"],
F["fault__independently__active__mv3__mv3__fault_4"]);
(["normal_sys___GUARANTEE3"; "contract violation"],
F["fault__independently__active__mv4__mv4__fault_4"]);
(["normal_sys___GUARANTEE4"; "contract violation"],
F["fault__independently__active__mv5__mv5__fault_4"]);
(["normal_sys___GUARANTEE5"; "contract violation"],
F["fault__independently__active__mv6__mv6__fault_4"]);
(["normal_sys___GUARANTEE0"; "contract violation"],
F["fault__independently__active__mv1__mv1__fault_4"]);
(["normal_sys___GUARANTEE1"; "contract violation"],
F["fault__independently__active__mv2__mv2__fault_4"])]
};

{name = "alt_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__mv3__mv3__fault_4";
"fault__independently__active__mv2__mv2__fault_4";
"fault__independently__active__mv4__mv4__fault_4";
"fault__independently__active__mv1__mv1__fault_4"];
event_info = [(3.25E-6, 1.0);
(3.25E-6, 1.0);
(3.25E-6, 1.0);
(3.25E-6, 1.0)];
output_flows = ["alt_sys___GUARANTEE2";
"alt_sys___GUARANTEE3";
"alt_sys___GUARANTEE0";
"alt_sys___GUARANTEE1"];
formulas = [
(["alt_sys___GUARANTEE2"; "contract violation"],
F["fault__independently__active__mv3__mv3__fault_4"]);
(["alt_sys___GUARANTEE3"; "contract violation"],
F["fault__independently__active__mv4__mv4__fault_4"]);
(["alt_sys___GUARANTEE0"; "contract violation"],
F["fault__independently__active__mv1__mv1__fault_4"]);
(["alt_sys___GUARANTEE1"; "contract violation"],
F["fault__independently__active__mv2__mv2__fault_4"])]
};

{name = "wheel_brake1";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1";
"fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1";
"fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2";
"fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2";
"fault__independently__active__brake_actuator__brake_actuator__fault_2"];
event_info = [(1.0E-5, 1.0);
(1.0E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-6, 1.0)];
output_flows = ["wheel_brake1___GUARANTEE0"];
formulas = [
(["wheel_brake1___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"]; 
F["fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2"]; 
F["fault__independently__active__brake_actuator__brake_actuator__fault_2"]; 
F["fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"]; 
F["fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2"]])]
};

{name = "wheel_brake2";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1";
"fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1";
"fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2";
"fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2";
"fault__independently__active__brake_actuator__brake_actuator__fault_2"];
event_info = [(1.0E-5, 1.0);
(1.0E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-6, 1.0)];
output_flows = ["wheel_brake2___GUARANTEE0"];
formulas = [
(["wheel_brake2___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"]; 
F["fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2"]; 
F["fault__independently__active__brake_actuator__brake_actuator__fault_2"]; 
F["fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"]; 
F["fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2"]])]
};

{name = "wheel_brake3";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1";
"fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1";
"fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2";
"fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2";
"fault__independently__active__brake_actuator__brake_actuator__fault_2"];
event_info = [(1.0E-5, 1.0);
(1.0E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-6, 1.0)];
output_flows = ["wheel_brake3___GUARANTEE0"];
formulas = [
(["wheel_brake3___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"]; 
F["fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2"]; 
F["fault__independently__active__brake_actuator__brake_actuator__fault_2"]; 
F["fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"]; 
F["fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2"]])]
};

{name = "wheel_brake4";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1";
"fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1";
"fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2";
"fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2";
"fault__independently__active__brake_actuator__brake_actuator__fault_2"];
event_info = [(1.0E-5, 1.0);
(1.0E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-6, 1.0)];
output_flows = ["wheel_brake4___GUARANTEE0"];
formulas = [
(["wheel_brake4___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"]; 
F["fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2"]; 
F["fault__independently__active__brake_actuator__brake_actuator__fault_2"]; 
F["fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"]; 
F["fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2"]])]
};

{name = "wheel_brake5";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1";
"fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1";
"fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2";
"fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2";
"fault__independently__active__brake_actuator__brake_actuator__fault_2"];
event_info = [(1.0E-5, 1.0);
(1.0E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-6, 1.0)];
output_flows = ["wheel_brake5___GUARANTEE0"];
formulas = [
(["wheel_brake5___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"]; 
F["fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2"]; 
F["fault__independently__active__brake_actuator__brake_actuator__fault_2"]; 
F["fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"]; 
F["fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2"]])]
};

{name = "wheel_brake6";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1";
"fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1";
"fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2";
"fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2";
"fault__independently__active__brake_actuator__brake_actuator__fault_2"];
event_info = [(1.0E-5, 1.0);
(1.0E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-6, 1.0)];
output_flows = ["wheel_brake6___GUARANTEE0"];
formulas = [
(["wheel_brake6___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"]; 
F["fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2"]; 
F["fault__independently__active__brake_actuator__brake_actuator__fault_2"]; 
F["fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"]; 
F["fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2"]])]
};

{name = "wheel_brake7";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1";
"fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1";
"fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2";
"fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2";
"fault__independently__active__brake_actuator__brake_actuator__fault_2"];
event_info = [(1.0E-5, 1.0);
(1.0E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-6, 1.0)];
output_flows = ["wheel_brake7___GUARANTEE0"];
formulas = [
(["wheel_brake7___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"]; 
F["fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2"]; 
F["fault__independently__active__brake_actuator__brake_actuator__fault_2"]; 
F["fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"]; 
F["fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2"]])]
};

{name = "wheel_brake8";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1";
"fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1";
"fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2";
"fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2";
"fault__independently__active__brake_actuator__brake_actuator__fault_2"];
event_info = [(1.0E-5, 1.0);
(1.0E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-5, 1.0);
(3.3E-6, 1.0)];
output_flows = ["wheel_brake8___GUARANTEE0"];
formulas = [
(["wheel_brake8___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"]; 
F["fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2"]; 
F["fault__independently__active__brake_actuator__brake_actuator__fault_2"]; 
F["fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"]; 
F["fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2"]])]
};

{name = "phys_sys";
faults = ["contract violation"];
input_flows = ["normal_sys___GUARANTEE6";
"normal_sys___GUARANTEE7";
"normal_sys___GUARANTEE2";
"normal_sys___GUARANTEE3";
"normal_sys___GUARANTEE4";
"normal_sys___GUARANTEE5";
"alt_sys___GUARANTEE2";
"wheel_brake2___GUARANTEE0";
"alt_sys___GUARANTEE3";
"alt_sys___GUARANTEE0";
"normal_sys___GUARANTEE0";
"wheel_brake1___GUARANTEE0";
"alt_sys___GUARANTEE1";
"normal_sys___GUARANTEE1";
"wheel_brake6___GUARANTEE0";
"wheel_brake7___GUARANTEE0";
"wheel_brake8___GUARANTEE0";
"wheel_brake5___GUARANTEE0";
"wheel_brake3___GUARANTEE0";
"wheel_brake4___GUARANTEE0"];
basic_events = ["fault__independently__active__accumulator__accumulator__fault_2";
"fault__independently__active__shutoff_valve__shutoff_valve__fault_2";
"fault__independently__active__selector_valve__selector_valve__fault_2";
"fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1";
"fault__independently__active__selector_valve__selector_valve__fault_1"];
event_info = [(5.0E-5, 1.0);
(5.0E-6, 1.0);
(1.0E-5, 1.0);
(3.0E-5, 1.0);
(1.0E-5, 1.0)];
output_flows = ["phys_sys___GUARANTEE5";
"phys_sys___GUARANTEE6";
"phys_sys___GUARANTEE7";
"phys_sys___GUARANTEE8";
"phys_sys___GUARANTEE1";
"phys_sys___GUARANTEE2";
"phys_sys___GUARANTEE3";
"phys_sys___GUARANTEE4";
"phys_sys___GUARANTEE0";
"phys_sys___GUARANTEE18";
"phys_sys___GUARANTEE13";
"phys_sys___GUARANTEE12";
"phys_sys___GUARANTEE11";
"phys_sys___GUARANTEE10";
"phys_sys___GUARANTEE17";
"phys_sys___GUARANTEE16";
"phys_sys___GUARANTEE15";
"phys_sys___GUARANTEE14";
"phys_sys___GUARANTEE9"];
formulas = [
(["phys_sys___GUARANTEE5"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE1"; "contract violation"]; 
F["normal_sys___GUARANTEE5"; "contract violation"]; 
F["wheel_brake6___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE6"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE2"; "contract violation"]; 
F["normal_sys___GUARANTEE6"; "contract violation"]; 
F["wheel_brake7___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE7"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE3"; "contract violation"]; 
F["normal_sys___GUARANTEE7"; "contract violation"]; 
F["wheel_brake8___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE8"; "contract violation"],
Or[F["fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1"]; 
F["fault__independently__active__shutoff_valve__shutoff_valve__fault_2"]]);
(["phys_sys___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE1"; "contract violation"]; 
F["normal_sys___GUARANTEE1"; "contract violation"]; 
F["wheel_brake2___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE2"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE2"; "contract violation"]; 
F["normal_sys___GUARANTEE2"; "contract violation"]; 
F["wheel_brake3___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE3"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE3"; "contract violation"]; 
F["normal_sys___GUARANTEE3"; "contract violation"]; 
F["wheel_brake4___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE4"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE0"; "contract violation"]; 
F["normal_sys___GUARANTEE4"; "contract violation"]; 
F["wheel_brake5___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE0"; "contract violation"]; 
F["normal_sys___GUARANTEE0"; "contract violation"]; 
F["wheel_brake1___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE18"; "contract violation"],
And[Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE0"; "contract violation"]; 
F["normal_sys___GUARANTEE4"; "contract violation"]; 
F["wheel_brake5___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE0"; "contract violation"]; 
F["normal_sys___GUARANTEE0"; "contract violation"]; 
F["wheel_brake1___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE1"; "contract violation"]; 
F["normal_sys___GUARANTEE1"; "contract violation"]; 
F["wheel_brake2___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE1"; "contract violation"]; 
F["normal_sys___GUARANTEE5"; "contract violation"]; 
F["wheel_brake6___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE2"; "contract violation"]; 
F["normal_sys___GUARANTEE2"; "contract violation"]; 
F["wheel_brake3___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE3"; "contract violation"]; 
F["normal_sys___GUARANTEE7"; "contract violation"]; 
F["wheel_brake8___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE2"; "contract violation"]; 
F["normal_sys___GUARANTEE6"; "contract violation"]; 
F["wheel_brake7___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE3"; "contract violation"]; 
F["normal_sys___GUARANTEE3"; "contract violation"]; 
F["wheel_brake4___GUARANTEE0"; "contract violation"]]]);
(["phys_sys___GUARANTEE13"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE0"; "contract violation"]; 
F["normal_sys___GUARANTEE4"; "contract violation"]; 
F["wheel_brake5___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE12"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE3"; "contract violation"]; 
F["normal_sys___GUARANTEE3"; "contract violation"]; 
F["wheel_brake4___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE11"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE2"; "contract violation"]; 
F["normal_sys___GUARANTEE2"; "contract violation"]; 
F["wheel_brake3___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE10"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE1"; "contract violation"]; 
F["normal_sys___GUARANTEE1"; "contract violation"]; 
F["wheel_brake2___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE17"; "contract violation"],
And[Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE0"; "contract violation"]; 
F["normal_sys___GUARANTEE4"; "contract violation"]; 
F["wheel_brake5___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE0"; "contract violation"]; 
F["normal_sys___GUARANTEE0"; "contract violation"]; 
F["wheel_brake1___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE1"; "contract violation"]; 
F["normal_sys___GUARANTEE1"; "contract violation"]; 
F["wheel_brake2___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE1"; "contract violation"]; 
F["normal_sys___GUARANTEE5"; "contract violation"]; 
F["wheel_brake6___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE2"; "contract violation"]; 
F["normal_sys___GUARANTEE2"; "contract violation"]; 
F["wheel_brake3___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE3"; "contract violation"]; 
F["normal_sys___GUARANTEE7"; "contract violation"]; 
F["wheel_brake8___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE2"; "contract violation"]; 
F["normal_sys___GUARANTEE6"; "contract violation"]; 
F["wheel_brake7___GUARANTEE0"; "contract violation"]];
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE3"; "contract violation"]; 
F["normal_sys___GUARANTEE3"; "contract violation"]; 
F["wheel_brake4___GUARANTEE0"; "contract violation"]]]);
(["phys_sys___GUARANTEE16"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE3"; "contract violation"]; 
F["normal_sys___GUARANTEE7"; "contract violation"]; 
F["wheel_brake8___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE15"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE2"; "contract violation"]; 
F["normal_sys___GUARANTEE6"; "contract violation"]; 
F["wheel_brake7___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE14"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE1"; "contract violation"]; 
F["normal_sys___GUARANTEE5"; "contract violation"]; 
F["wheel_brake6___GUARANTEE0"; "contract violation"]]);
(["phys_sys___GUARANTEE9"; "contract violation"],
Or[F["fault__independently__active__accumulator__accumulator__fault_2"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_1"]; 
F["fault__independently__active__selector_valve__selector_valve__fault_2"]; 
F["alt_sys___GUARANTEE0"; "contract violation"]; 
F["normal_sys___GUARANTEE0"; "contract violation"]; 
F["wheel_brake1___GUARANTEE0"; "contract violation"]])]
};

{name = "w1_w5_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1";
"fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1";
"fault__independently__active__brake_command_facility__brake_command_facility__fault_1";
"fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1";
"fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1";
"fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"];
event_info = [(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0)];
output_flows = ["w1_w5_cmd_sys___GUARANTEE0";
"w1_w5_cmd_sys___GUARANTEE1";
"w1_w5_cmd_sys___GUARANTEE2"];
formulas = [
(["w1_w5_cmd_sys___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]]);
(["w1_w5_cmd_sys___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"]]);
(["w1_w5_cmd_sys___GUARANTEE2"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"]])]
};

{name = "w2_w6_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1";
"fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1";
"fault__independently__active__brake_command_facility__brake_command_facility__fault_1";
"fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1";
"fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1";
"fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"];
event_info = [(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0)];
output_flows = ["w2_w6_cmd_sys___GUARANTEE1";
"w2_w6_cmd_sys___GUARANTEE2";
"w2_w6_cmd_sys___GUARANTEE0"];
formulas = [
(["w2_w6_cmd_sys___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"]]);
(["w2_w6_cmd_sys___GUARANTEE2"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"]]);
(["w2_w6_cmd_sys___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]])]
};

{name = "w3_w7_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1";
"fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1";
"fault__independently__active__brake_command_facility__brake_command_facility__fault_1";
"fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1";
"fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1";
"fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"];
event_info = [(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0)];
output_flows = ["w3_w7_cmd_sys___GUARANTEE1";
"w3_w7_cmd_sys___GUARANTEE2";
"w3_w7_cmd_sys___GUARANTEE0"];
formulas = [
(["w3_w7_cmd_sys___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"]]);
(["w3_w7_cmd_sys___GUARANTEE2"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"]]);
(["w3_w7_cmd_sys___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]])]
};

{name = "w4_w8_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1";
"fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1";
"fault__independently__active__brake_command_facility__brake_command_facility__fault_1";
"fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1";
"fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1";
"fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"];
event_info = [(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0);
(9.0E-6, 1.0)];
output_flows = ["w4_w8_cmd_sys___GUARANTEE0";
"w4_w8_cmd_sys___GUARANTEE1";
"w4_w8_cmd_sys___GUARANTEE2"];
formulas = [
(["w4_w8_cmd_sys___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]]);
(["w4_w8_cmd_sys___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"]]);
(["w4_w8_cmd_sys___GUARANTEE2"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"]])]
};

{name = "command_sys";
faults = ["contract violation"];
input_flows = ["w4_w8_cmd_sys___GUARANTEE0";
"w2_w6_cmd_sys___GUARANTEE1";
"w1_w5_cmd_sys___GUARANTEE0";
"w2_w6_cmd_sys___GUARANTEE2";
"w1_w5_cmd_sys___GUARANTEE1";
"w2_w6_cmd_sys___GUARANTEE0";
"w1_w5_cmd_sys___GUARANTEE2";
"w4_w8_cmd_sys___GUARANTEE1";
"w4_w8_cmd_sys___GUARANTEE2";
"w3_w7_cmd_sys___GUARANTEE1";
"w3_w7_cmd_sys___GUARANTEE2";
"w3_w7_cmd_sys___GUARANTEE0"];
basic_events = [];
event_info = [];
output_flows = ["command_sys___GUARANTEE4";
"command_sys___GUARANTEE5";
"command_sys___GUARANTEE2";
"command_sys___GUARANTEE3";
"command_sys___GUARANTEE8";
"command_sys___GUARANTEE9";
"command_sys___GUARANTEE10";
"command_sys___GUARANTEE6";
"command_sys___GUARANTEE11";
"command_sys___GUARANTEE7";
"command_sys___GUARANTEE0";
"command_sys___GUARANTEE1"];
formulas = [
(["command_sys___GUARANTEE4"; "contract violation"],
F["w1_w5_cmd_sys___GUARANTEE1"; "contract violation"]);
(["command_sys___GUARANTEE5"; "contract violation"],
F["w2_w6_cmd_sys___GUARANTEE1"; "contract violation"]);
(["command_sys___GUARANTEE2"; "contract violation"],
F["w3_w7_cmd_sys___GUARANTEE0"; "contract violation"]);
(["command_sys___GUARANTEE3"; "contract violation"],
F["w4_w8_cmd_sys___GUARANTEE0"; "contract violation"]);
(["command_sys___GUARANTEE8"; "contract violation"],
F["w1_w5_cmd_sys___GUARANTEE2"; "contract violation"]);
(["command_sys___GUARANTEE9"; "contract violation"],
F["w2_w6_cmd_sys___GUARANTEE2"; "contract violation"]);
(["command_sys___GUARANTEE10"; "contract violation"],
F["w3_w7_cmd_sys___GUARANTEE2"; "contract violation"]);
(["command_sys___GUARANTEE6"; "contract violation"],
F["w3_w7_cmd_sys___GUARANTEE1"; "contract violation"]);
(["command_sys___GUARANTEE11"; "contract violation"],
F["w4_w8_cmd_sys___GUARANTEE2"; "contract violation"]);
(["command_sys___GUARANTEE7"; "contract violation"],
F["w4_w8_cmd_sys___GUARANTEE1"; "contract violation"]);
(["command_sys___GUARANTEE0"; "contract violation"],
F["w1_w5_cmd_sys___GUARANTEE0"; "contract violation"]);
(["command_sys___GUARANTEE1"; "contract violation"],
F["w2_w6_cmd_sys___GUARANTEE0"; "contract violation"])]
};

{name = "channel1";
faults = ["contract violation"];
input_flows = ["command_sys___GUARANTEE4";
"command_sys___GUARANTEE5";
"command_sys___GUARANTEE2";
"command_sys___GUARANTEE3";
"command_sys___GUARANTEE8";
"command_sys___GUARANTEE9";
"command_sys___GUARANTEE10";
"command_sys___GUARANTEE6";
"command_sys___GUARANTEE11";
"command_sys___GUARANTEE7";
"command_sys___GUARANTEE0";
"command_sys___GUARANTEE1"];
basic_events = ["fault__independently__active__monitor_sys__monitor_sys__fault_1"];
event_info = [(8.0E-7, 1.0)];
output_flows = ["channel1___GUARANTEE3";
"channel1___GUARANTEE4";
"channel1___GUARANTEE12";
"channel1___GUARANTEE5";
"channel1___GUARANTEE6";
"channel1___GUARANTEE0";
"channel1___GUARANTEE1";
"channel1___GUARANTEE2";
"channel1___GUARANTEE11";
"channel1___GUARANTEE10";
"channel1___GUARANTEE7";
"channel1___GUARANTEE8";
"channel1___GUARANTEE9"];
formulas = [
(["channel1___GUARANTEE3"; "contract violation"],
F["command_sys___GUARANTEE3"; "contract violation"]);
(["channel1___GUARANTEE4"; "contract violation"],
F["command_sys___GUARANTEE4"; "contract violation"]);
(["channel1___GUARANTEE12"; "contract violation"],
F["fault__independently__active__monitor_sys__monitor_sys__fault_1"]);
(["channel1___GUARANTEE5"; "contract violation"],
F["command_sys___GUARANTEE5"; "contract violation"]);
(["channel1___GUARANTEE6"; "contract violation"],
F["command_sys___GUARANTEE6"; "contract violation"]);
(["channel1___GUARANTEE0"; "contract violation"],
F["command_sys___GUARANTEE0"; "contract violation"]);
(["channel1___GUARANTEE1"; "contract violation"],
F["command_sys___GUARANTEE1"; "contract violation"]);
(["channel1___GUARANTEE2"; "contract violation"],
F["command_sys___GUARANTEE2"; "contract violation"]);
(["channel1___GUARANTEE11"; "contract violation"],
F["command_sys___GUARANTEE11"; "contract violation"]);
(["channel1___GUARANTEE10"; "contract violation"],
F["command_sys___GUARANTEE10"; "contract violation"]);
(["channel1___GUARANTEE7"; "contract violation"],
F["command_sys___GUARANTEE7"; "contract violation"]);
(["channel1___GUARANTEE8"; "contract violation"],
F["command_sys___GUARANTEE8"; "contract violation"]);
(["channel1___GUARANTEE9"; "contract violation"],
F["command_sys___GUARANTEE9"; "contract violation"])]
};

{name = "channel2";
faults = ["contract violation"];
input_flows = ["command_sys___GUARANTEE4";
"command_sys___GUARANTEE5";
"command_sys___GUARANTEE2";
"command_sys___GUARANTEE3";
"command_sys___GUARANTEE8";
"command_sys___GUARANTEE9";
"command_sys___GUARANTEE10";
"command_sys___GUARANTEE6";
"command_sys___GUARANTEE11";
"command_sys___GUARANTEE7";
"command_sys___GUARANTEE0";
"command_sys___GUARANTEE1"];
basic_events = ["fault__independently__active__monitor_sys__monitor_sys__fault_1"];
event_info = [(8.0E-7, 1.0)];
output_flows = ["channel2___GUARANTEE2";
"channel2___GUARANTEE3";
"channel2___GUARANTEE0";
"channel2___GUARANTEE1";
"channel2___GUARANTEE10";
"channel2___GUARANTEE6";
"channel2___GUARANTEE7";
"channel2___GUARANTEE4";
"channel2___GUARANTEE5";
"channel2___GUARANTEE11";
"channel2___GUARANTEE12";
"channel2___GUARANTEE8";
"channel2___GUARANTEE9"];
formulas = [
(["channel2___GUARANTEE2"; "contract violation"],
F["command_sys___GUARANTEE2"; "contract violation"]);
(["channel2___GUARANTEE3"; "contract violation"],
F["command_sys___GUARANTEE3"; "contract violation"]);
(["channel2___GUARANTEE0"; "contract violation"],
F["command_sys___GUARANTEE0"; "contract violation"]);
(["channel2___GUARANTEE1"; "contract violation"],
F["command_sys___GUARANTEE1"; "contract violation"]);
(["channel2___GUARANTEE10"; "contract violation"],
F["command_sys___GUARANTEE10"; "contract violation"]);
(["channel2___GUARANTEE6"; "contract violation"],
F["command_sys___GUARANTEE6"; "contract violation"]);
(["channel2___GUARANTEE7"; "contract violation"],
F["command_sys___GUARANTEE7"; "contract violation"]);
(["channel2___GUARANTEE4"; "contract violation"],
F["command_sys___GUARANTEE4"; "contract violation"]);
(["channel2___GUARANTEE5"; "contract violation"],
F["command_sys___GUARANTEE5"; "contract violation"]);
(["channel2___GUARANTEE11"; "contract violation"],
F["command_sys___GUARANTEE11"; "contract violation"]);
(["channel2___GUARANTEE12"; "contract violation"],
F["fault__independently__active__monitor_sys__monitor_sys__fault_1"]);
(["channel2___GUARANTEE8"; "contract violation"],
F["command_sys___GUARANTEE8"; "contract violation"]);
(["channel2___GUARANTEE9"; "contract violation"],
F["command_sys___GUARANTEE9"; "contract violation"])]
};

{name = "bscu";
faults = ["contract violation"];
input_flows = ["channel2___GUARANTEE2";
"channel1___GUARANTEE3";
"channel2___GUARANTEE3";
"channel1___GUARANTEE4";
"channel2___GUARANTEE0";
"channel1___GUARANTEE5";
"channel2___GUARANTEE1";
"channel1___GUARANTEE6";
"channel2___GUARANTEE10";
"channel2___GUARANTEE6";
"channel1___GUARANTEE0";
"channel2___GUARANTEE7";
"channel1___GUARANTEE1";
"channel2___GUARANTEE4";
"channel1___GUARANTEE2";
"channel2___GUARANTEE5";
"channel2___GUARANTEE11";
"channel2___GUARANTEE12";
"channel1___GUARANTEE12";
"channel1___GUARANTEE11";
"channel1___GUARANTEE10";
"channel2___GUARANTEE8";
"channel2___GUARANTEE9";
"channel1___GUARANTEE7";
"channel1___GUARANTEE8";
"channel1___GUARANTEE9"];
basic_events = ["fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_pair_3_7__switch_gate_brake_as_cmd_pair_3_7__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_pair_4_8__switch_gate_brake_as_cmd_pair_4_8__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_pair_1_5__switch_gate_brake_as_cmd_pair_1_5__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_pair_2_6__switch_gate_brake_as_cmd_pair_2_6__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2";
"fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2"];
event_info = [(1.3E-5, 1.0);
(1.3E-5, 1.0);
(1.3E-5, 1.0);
(1.3E-5, 1.0);
(1.3E-5, 1.0);
(1.3E-5, 1.0);
(1.3E-5, 1.0);
(1.3E-5, 1.0);
(1.3E-5, 1.0);
(1.3E-5, 1.0);
(1.3E-5, 1.0);
(1.3E-5, 1.0)];
output_flows = ["bscu___GUARANTEE9";
"bscu___GUARANTEE8";
"bscu___GUARANTEE7";
"bscu___GUARANTEE6";
"bscu___GUARANTEE5";
"bscu___GUARANTEE4";
"bscu___GUARANTEE3";
"bscu___GUARANTEE2";
"bscu___GUARANTEE1";
"bscu___GUARANTEE10";
"bscu___GUARANTEE0";
"bscu___GUARANTEE11"];
formulas = [
(["bscu___GUARANTEE9"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2"]; 
F["channel1___GUARANTEE9"; "contract violation"]; 
F["channel1___GUARANTEE12"; "contract violation"]; 
F["channel2___GUARANTEE9"; "contract violation"]; 
F["channel2___GUARANTEE12"; "contract violation"]]);
(["bscu___GUARANTEE8"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2"]; 
F["channel1___GUARANTEE8"; "contract violation"]; 
F["channel1___GUARANTEE12"; "contract violation"]; 
F["channel2___GUARANTEE8"; "contract violation"]; 
F["channel2___GUARANTEE12"; "contract violation"]]);
(["bscu___GUARANTEE7"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2"]; 
F["channel1___GUARANTEE7"; "contract violation"]; 
F["channel1___GUARANTEE12"; "contract violation"]; 
F["channel2___GUARANTEE7"; "contract violation"]; 
F["channel2___GUARANTEE12"; "contract violation"]]);
(["bscu___GUARANTEE6"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2"]; 
F["channel1___GUARANTEE6"; "contract violation"]; 
F["channel1___GUARANTEE12"; "contract violation"]; 
F["channel2___GUARANTEE6"; "contract violation"]; 
F["channel2___GUARANTEE12"; "contract violation"]]);
(["bscu___GUARANTEE5"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2"]; 
F["channel1___GUARANTEE5"; "contract violation"]; 
F["channel1___GUARANTEE12"; "contract violation"]; 
F["channel2___GUARANTEE5"; "contract violation"]; 
F["channel2___GUARANTEE12"; "contract violation"]]);
(["bscu___GUARANTEE4"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2"]; 
F["channel1___GUARANTEE4"; "contract violation"]; 
F["channel1___GUARANTEE12"; "contract violation"]; 
F["channel2___GUARANTEE4"; "contract violation"]; 
F["channel2___GUARANTEE12"; "contract violation"]]);
(["bscu___GUARANTEE3"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_pair_4_8__switch_gate_brake_as_cmd_pair_4_8__fault_2"]; 
F["channel1___GUARANTEE3"; "contract violation"]; 
F["channel2___GUARANTEE3"; "contract violation"]]);
(["bscu___GUARANTEE2"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_pair_3_7__switch_gate_brake_as_cmd_pair_3_7__fault_2"]; 
F["channel1___GUARANTEE2"; "contract violation"]; 
F["channel2___GUARANTEE2"; "contract violation"]]);
(["bscu___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_pair_2_6__switch_gate_brake_as_cmd_pair_2_6__fault_2"]; 
F["channel1___GUARANTEE1"; "contract violation"]; 
F["channel2___GUARANTEE1"; "contract violation"]]);
(["bscu___GUARANTEE10"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2"]; 
F["channel1___GUARANTEE10"; "contract violation"]; 
F["channel1___GUARANTEE12"; "contract violation"]; 
F["channel2___GUARANTEE10"; "contract violation"]; 
F["channel2___GUARANTEE12"; "contract violation"]]);
(["bscu___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_pair_1_5__switch_gate_brake_as_cmd_pair_1_5__fault_2"]; 
F["channel1___GUARANTEE0"; "contract violation"]; 
F["channel2___GUARANTEE0"; "contract violation"]]);
(["bscu___GUARANTEE11"; "contract violation"],
Or[F["fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2"]; 
F["channel1___GUARANTEE11"; "contract violation"]; 
F["channel1___GUARANTEE12"; "contract violation"]; 
F["channel2___GUARANTEE11"; "contract violation"]; 
F["channel2___GUARANTEE12"; "contract violation"]])]
};

{name = "ctrl_sys";
faults = ["contract violation"];
input_flows = ["bscu___GUARANTEE9";
"bscu___GUARANTEE8";
"bscu___GUARANTEE7";
"bscu___GUARANTEE6";
"bscu___GUARANTEE5";
"bscu___GUARANTEE4";
"bscu___GUARANTEE3";
"bscu___GUARANTEE2";
"bscu___GUARANTEE1";
"bscu___GUARANTEE10";
"bscu___GUARANTEE0";
"bscu___GUARANTEE11"];
basic_events = [];
event_info = [];
output_flows = ["ctrl_sys___GUARANTEE9";
"ctrl_sys___GUARANTEE8";
"ctrl_sys___GUARANTEE7";
"ctrl_sys___GUARANTEE13";
"ctrl_sys___GUARANTEE6";
"ctrl_sys___GUARANTEE5";
"ctrl_sys___GUARANTEE11";
"ctrl_sys___GUARANTEE4";
"ctrl_sys___GUARANTEE12";
"ctrl_sys___GUARANTEE3";
"ctrl_sys___GUARANTEE2";
"ctrl_sys___GUARANTEE10";
"ctrl_sys___GUARANTEE1";
"ctrl_sys___GUARANTEE0"];
formulas = [
(["ctrl_sys___GUARANTEE9"; "contract violation"],
F["bscu___GUARANTEE7"; "contract violation"]);
(["ctrl_sys___GUARANTEE8"; "contract violation"],
F["bscu___GUARANTEE6"; "contract violation"]);
(["ctrl_sys___GUARANTEE7"; "contract violation"],
F["bscu___GUARANTEE5"; "contract violation"]);
(["ctrl_sys___GUARANTEE13"; "contract violation"],
F["bscu___GUARANTEE11"; "contract violation"]);
(["ctrl_sys___GUARANTEE6"; "contract violation"],
F["bscu___GUARANTEE4"; "contract violation"]);
(["ctrl_sys___GUARANTEE5"; "contract violation"],
Or[F["bscu___GUARANTEE0"; "contract violation"]; 
F["bscu___GUARANTEE1"; "contract violation"]; 
F["bscu___GUARANTEE2"; "contract violation"]; 
F["bscu___GUARANTEE3"; "contract violation"]; 
F["bscu___GUARANTEE4"; "contract violation"]; 
F["bscu___GUARANTEE5"; "contract violation"]; 
F["bscu___GUARANTEE6"; "contract violation"]; 
F["bscu___GUARANTEE7"; "contract violation"]; 
F["bscu___GUARANTEE8"; "contract violation"]; 
F["bscu___GUARANTEE9"; "contract violation"]; 
F["bscu___GUARANTEE10"; "contract violation"]; 
F["bscu___GUARANTEE11"; "contract violation"]]);
(["ctrl_sys___GUARANTEE11"; "contract violation"],
F["bscu___GUARANTEE9"; "contract violation"]);
(["ctrl_sys___GUARANTEE4"; "contract violation"],
Or[F["bscu___GUARANTEE0"; "contract violation"]; 
F["bscu___GUARANTEE1"; "contract violation"]; 
F["bscu___GUARANTEE2"; "contract violation"]; 
F["bscu___GUARANTEE3"; "contract violation"]; 
F["bscu___GUARANTEE4"; "contract violation"]; 
F["bscu___GUARANTEE5"; "contract violation"]; 
F["bscu___GUARANTEE6"; "contract violation"]; 
F["bscu___GUARANTEE7"; "contract violation"]; 
F["bscu___GUARANTEE8"; "contract violation"]; 
F["bscu___GUARANTEE9"; "contract violation"]; 
F["bscu___GUARANTEE10"; "contract violation"]; 
F["bscu___GUARANTEE11"; "contract violation"]]);
(["ctrl_sys___GUARANTEE12"; "contract violation"],
F["bscu___GUARANTEE10"; "contract violation"]);
(["ctrl_sys___GUARANTEE3"; "contract violation"],
F["bscu___GUARANTEE3"; "contract violation"]);
(["ctrl_sys___GUARANTEE2"; "contract violation"],
F["bscu___GUARANTEE2"; "contract violation"]);
(["ctrl_sys___GUARANTEE10"; "contract violation"],
F["bscu___GUARANTEE8"; "contract violation"]);
(["ctrl_sys___GUARANTEE1"; "contract violation"],
F["bscu___GUARANTEE1"; "contract violation"]);
(["ctrl_sys___GUARANTEE0"; "contract violation"],
F["bscu___GUARANTEE0"; "contract violation"])]
};

{name = "WBS_inst";
faults = ["contract violation"];
input_flows = ["phys_sys___GUARANTEE5";
"phys_sys___GUARANTEE6";
"phys_sys___GUARANTEE7";
"ctrl_sys___GUARANTEE13";
"phys_sys___GUARANTEE1";
"ctrl_sys___GUARANTEE11";
"phys_sys___GUARANTEE2";
"ctrl_sys___GUARANTEE12";
"phys_sys___GUARANTEE3";
"phys_sys___GUARANTEE4";
"ctrl_sys___GUARANTEE10";
"phys_sys___GUARANTEE0";
"phys_sys___GUARANTEE18";
"phys_sys___GUARANTEE13";
"phys_sys___GUARANTEE12";
"phys_sys___GUARANTEE11";
"phys_sys___GUARANTEE10";
"phys_sys___GUARANTEE17";
"phys_sys___GUARANTEE16";
"phys_sys___GUARANTEE15";
"phys_sys___GUARANTEE14";
"phys_sys___GUARANTEE9";
"ctrl_sys___GUARANTEE9";
"ctrl_sys___GUARANTEE8";
"ctrl_sys___GUARANTEE7";
"ctrl_sys___GUARANTEE6"];
basic_events = ["fault__independently__active__wheel_sensor4__wheel_sensor4__fault_2";
"fault__independently__active__wheel_sensor3__wheel_sensor3__fault_2";
"fault__independently__active__wheel_sensor1__wheel_sensor1__fault_2";
"fault__independently__active__wheel_sensor6__wheel_sensor6__fault_2";
"fault__independently__active__wheel_sensor5__wheel_sensor5__fault_2";
"fault__independently__active__wheel_sensor8__wheel_sensor8__fault_2";
"fault__independently__active__wheel_sensor7__wheel_sensor7__fault_2";
"fault__independently__active__wheel_sensor2__wheel_sensor2__fault_2"];
event_info = [(5.0E-6, 1.0);
(5.0E-6, 1.0);
(5.0E-6, 1.0);
(5.0E-6, 1.0);
(5.0E-6, 1.0);
(5.0E-6, 1.0);
(5.0E-6, 1.0);
(5.0E-6, 1.0)];
output_flows = ["WBS_inst___GUARANTEE23";
"WBS_inst___GUARANTEE22";
"WBS_inst___GUARANTEE21";
"WBS_inst___GUARANTEE20";
"WBS_inst___GUARANTEE27";
"WBS_inst___GUARANTEE26";
"WBS_inst___GUARANTEE25";
"WBS_inst___GUARANTEE24";
"WBS_inst___GUARANTEE28";
"WBS_inst___GUARANTEE0";
"WBS_inst___GUARANTEE1";
"WBS_inst___GUARANTEE2";
"WBS_inst___GUARANTEE3";
"WBS_inst___GUARANTEE4";
"WBS_inst___GUARANTEE5";
"WBS_inst___GUARANTEE12";
"WBS_inst___GUARANTEE11";
"WBS_inst___GUARANTEE10";
"WBS_inst___GUARANTEE6";
"WBS_inst___GUARANTEE16";
"WBS_inst___GUARANTEE7";
"WBS_inst___GUARANTEE15";
"WBS_inst___GUARANTEE8";
"WBS_inst___GUARANTEE14";
"WBS_inst___GUARANTEE9";
"WBS_inst___GUARANTEE13";
"WBS_inst___GUARANTEE19";
"WBS_inst___GUARANTEE18";
"WBS_inst___GUARANTEE17"];
formulas = [
(["WBS_inst___GUARANTEE23"; "contract violation"],
F["phys_sys___GUARANTEE2"; "contract violation"]);
(["WBS_inst___GUARANTEE22"; "contract violation"],
F["phys_sys___GUARANTEE1"; "contract violation"]);
(["WBS_inst___GUARANTEE21"; "contract violation"],
F["phys_sys___GUARANTEE0"; "contract violation"]);
(["WBS_inst___GUARANTEE20"; "contract violation"],
F["phys_sys___GUARANTEE16"; "contract violation"]);
(["WBS_inst___GUARANTEE27"; "contract violation"],
F["phys_sys___GUARANTEE6"; "contract violation"]);
(["WBS_inst___GUARANTEE26"; "contract violation"],
F["phys_sys___GUARANTEE5"; "contract violation"]);
(["WBS_inst___GUARANTEE25"; "contract violation"],
F["phys_sys___GUARANTEE4"; "contract violation"]);
(["WBS_inst___GUARANTEE24"; "contract violation"],
F["phys_sys___GUARANTEE3"; "contract violation"]);
(["WBS_inst___GUARANTEE28"; "contract violation"],
F["phys_sys___GUARANTEE7"; "contract violation"]);
(["WBS_inst___GUARANTEE0"; "contract violation"],
And[F["phys_sys___GUARANTEE2"; "contract violation"];
F["phys_sys___GUARANTEE1"; "contract violation"];
F["phys_sys___GUARANTEE0"; "contract violation"];
F["phys_sys___GUARANTEE7"; "contract violation"];
F["phys_sys___GUARANTEE6"; "contract violation"];
F["phys_sys___GUARANTEE5"; "contract violation"];
F["phys_sys___GUARANTEE4"; "contract violation"];
F["phys_sys___GUARANTEE3"; "contract violation"]]);
(["WBS_inst___GUARANTEE1"; "contract violation"],
Or[F["phys_sys___GUARANTEE0"; "contract violation"]; 
F["phys_sys___GUARANTEE1"; "contract violation"]; 
F["phys_sys___GUARANTEE4"; "contract violation"]; 
F["phys_sys___GUARANTEE5"; "contract violation"]]);
(["WBS_inst___GUARANTEE2"; "contract violation"],
Or[F["phys_sys___GUARANTEE2"; "contract violation"]; 
F["phys_sys___GUARANTEE3"; "contract violation"]; 
F["phys_sys___GUARANTEE6"; "contract violation"]; 
F["phys_sys___GUARANTEE7"; "contract violation"]]);
(["WBS_inst___GUARANTEE3"; "contract violation"],
And[F["phys_sys___GUARANTEE18"; "contract violation"];
F["phys_sys___GUARANTEE17"; "contract violation"];
F["phys_sys___GUARANTEE16"; "contract violation"];
F["phys_sys___GUARANTEE9"; "contract violation"];
F["phys_sys___GUARANTEE15"; "contract violation"];
F["phys_sys___GUARANTEE14"; "contract violation"];
F["phys_sys___GUARANTEE13"; "contract violation"];
F["phys_sys___GUARANTEE12"; "contract violation"];
F["phys_sys___GUARANTEE11"; "contract violation"];
F["phys_sys___GUARANTEE10"; "contract violation"]]);
(["WBS_inst___GUARANTEE4"; "contract violation"],
And[F["phys_sys___GUARANTEE18"; "contract violation"];
F["phys_sys___GUARANTEE16"; "contract violation"];
F["phys_sys___GUARANTEE9"; "contract violation"];
F["phys_sys___GUARANTEE15"; "contract violation"];
F["phys_sys___GUARANTEE14"; "contract violation"];
F["phys_sys___GUARANTEE13"; "contract violation"];
F["phys_sys___GUARANTEE12"; "contract violation"];
F["phys_sys___GUARANTEE11"; "contract violation"];
F["phys_sys___GUARANTEE10"; "contract violation"]]);
(["WBS_inst___GUARANTEE5"; "contract violation"],
Or[F["fault__independently__active__wheel_sensor1__wheel_sensor1__fault_2"]; 
F["ctrl_sys___GUARANTEE6"; "contract violation"]; 
F["phys_sys___GUARANTEE9"; "contract violation"]]);
(["WBS_inst___GUARANTEE12"; "contract violation"],
Or[F["fault__independently__active__wheel_sensor8__wheel_sensor8__fault_2"]; 
F["ctrl_sys___GUARANTEE13"; "contract violation"]; 
F["phys_sys___GUARANTEE16"; "contract violation"]]);
(["WBS_inst___GUARANTEE11"; "contract violation"],
Or[F["fault__independently__active__wheel_sensor7__wheel_sensor7__fault_2"]; 
F["ctrl_sys___GUARANTEE12"; "contract violation"]; 
F["phys_sys___GUARANTEE15"; "contract violation"]]);
(["WBS_inst___GUARANTEE10"; "contract violation"],
Or[F["fault__independently__active__wheel_sensor6__wheel_sensor6__fault_2"]; 
F["ctrl_sys___GUARANTEE11"; "contract violation"]; 
F["phys_sys___GUARANTEE14"; "contract violation"]]);
(["WBS_inst___GUARANTEE6"; "contract violation"],
Or[F["fault__independently__active__wheel_sensor2__wheel_sensor2__fault_2"]; 
F["ctrl_sys___GUARANTEE7"; "contract violation"]; 
F["phys_sys___GUARANTEE10"; "contract violation"]]);
(["WBS_inst___GUARANTEE16"; "contract violation"],
F["phys_sys___GUARANTEE12"; "contract violation"]);
(["WBS_inst___GUARANTEE7"; "contract violation"],
Or[F["fault__independently__active__wheel_sensor3__wheel_sensor3__fault_2"]; 
F["ctrl_sys___GUARANTEE8"; "contract violation"]; 
F["phys_sys___GUARANTEE11"; "contract violation"]]);
(["WBS_inst___GUARANTEE15"; "contract violation"],
F["phys_sys___GUARANTEE11"; "contract violation"]);
(["WBS_inst___GUARANTEE8"; "contract violation"],
Or[F["fault__independently__active__wheel_sensor4__wheel_sensor4__fault_2"]; 
F["ctrl_sys___GUARANTEE9"; "contract violation"]; 
F["phys_sys___GUARANTEE12"; "contract violation"]]);
(["WBS_inst___GUARANTEE14"; "contract violation"],
F["phys_sys___GUARANTEE10"; "contract violation"]);
(["WBS_inst___GUARANTEE9"; "contract violation"],
Or[F["fault__independently__active__wheel_sensor5__wheel_sensor5__fault_2"]; 
F["ctrl_sys___GUARANTEE10"; "contract violation"]; 
F["phys_sys___GUARANTEE13"; "contract violation"]]);
(["WBS_inst___GUARANTEE13"; "contract violation"],
F["phys_sys___GUARANTEE9"; "contract violation"]);
(["WBS_inst___GUARANTEE19"; "contract violation"],
F["phys_sys___GUARANTEE15"; "contract violation"]);
(["WBS_inst___GUARANTEE18"; "contract violation"],
F["phys_sys___GUARANTEE14"; "contract violation"]);
(["WBS_inst___GUARANTEE17"; "contract violation"],
F["phys_sys___GUARANTEE13"; "contract violation"])]
}];;

(* ----- CHECK LIBRARY ----- *)
checkLibrary_componentUnique comp_library;;
checkLibrary_nonEmptyFaults comp_library;;
checkLibrary_disjointInputFlowsandBasicEvents comp_library;;
checkLibrary_listsAreConsistentLengths comp_library;;
checkLibrary_allOutputFaultsHaveFormulas comp_library;;
checkLibrary_formulasMakeSense comp_library;;


(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE0 = 
{instances = 
[makeInstance "normal_sys" "normal_sys"();
makeInstance "alt_sys" "alt_sys"();
makeInstance "wheel_brake1" "wheel_brake1"();
makeInstance "wheel_brake2" "wheel_brake2"();
makeInstance "wheel_brake3" "wheel_brake3"();
makeInstance "wheel_brake4" "wheel_brake4"();
makeInstance "wheel_brake5" "wheel_brake5"();
makeInstance "wheel_brake6" "wheel_brake6"();
makeInstance "wheel_brake7" "wheel_brake7"();
makeInstance "wheel_brake8" "wheel_brake8"();
makeInstance "phys_sys" "phys_sys"();
makeInstance "w1_w5_cmd_sys" "w1_w5_cmd_sys"();
makeInstance "w2_w6_cmd_sys" "w2_w6_cmd_sys"();
makeInstance "w3_w7_cmd_sys" "w3_w7_cmd_sys"();
makeInstance "w4_w8_cmd_sys" "w4_w8_cmd_sys"();
makeInstance "command_sys" "command_sys"();
makeInstance "channel1" "channel1"();
makeInstance "channel2" "channel2"();
makeInstance "bscu" "bscu"();
makeInstance "ctrl_sys" "ctrl_sys"();
makeInstance "WBS_inst" "WBS_inst"();
];
connections = 
[(("phys_sys", "normal_sys___GUARANTEE6"),("normal_sys", "normal_sys___GUARANTEE6"));
(("phys_sys", "normal_sys___GUARANTEE7"),("normal_sys", "normal_sys___GUARANTEE7"));
(("phys_sys", "normal_sys___GUARANTEE2"),("normal_sys", "normal_sys___GUARANTEE2"));
(("phys_sys", "normal_sys___GUARANTEE3"),("normal_sys", "normal_sys___GUARANTEE3"));
(("phys_sys", "normal_sys___GUARANTEE4"),("normal_sys", "normal_sys___GUARANTEE4"));
(("phys_sys", "normal_sys___GUARANTEE5"),("normal_sys", "normal_sys___GUARANTEE5"));
(("phys_sys", "alt_sys___GUARANTEE2"),("alt_sys", "alt_sys___GUARANTEE2"));
(("phys_sys", "wheel_brake2___GUARANTEE0"),("wheel_brake2", "wheel_brake2___GUARANTEE0"));
(("phys_sys", "alt_sys___GUARANTEE3"),("alt_sys", "alt_sys___GUARANTEE3"));
(("phys_sys", "alt_sys___GUARANTEE0"),("alt_sys", "alt_sys___GUARANTEE0"));
(("phys_sys", "normal_sys___GUARANTEE0"),("normal_sys", "normal_sys___GUARANTEE0"));
(("phys_sys", "wheel_brake1___GUARANTEE0"),("wheel_brake1", "wheel_brake1___GUARANTEE0"));
(("phys_sys", "alt_sys___GUARANTEE1"),("alt_sys", "alt_sys___GUARANTEE1"));
(("phys_sys", "normal_sys___GUARANTEE1"),("normal_sys", "normal_sys___GUARANTEE1"));
(("phys_sys", "wheel_brake6___GUARANTEE0"),("wheel_brake6", "wheel_brake6___GUARANTEE0"));
(("phys_sys", "wheel_brake7___GUARANTEE0"),("wheel_brake7", "wheel_brake7___GUARANTEE0"));
(("phys_sys", "wheel_brake8___GUARANTEE0"),("wheel_brake8", "wheel_brake8___GUARANTEE0"));
(("phys_sys", "wheel_brake5___GUARANTEE0"),("wheel_brake5", "wheel_brake5___GUARANTEE0"));
(("phys_sys", "wheel_brake3___GUARANTEE0"),("wheel_brake3", "wheel_brake3___GUARANTEE0"));
(("phys_sys", "wheel_brake4___GUARANTEE0"),("wheel_brake4", "wheel_brake4___GUARANTEE0"));
(("command_sys", "w4_w8_cmd_sys___GUARANTEE0"),("w4_w8_cmd_sys", "w4_w8_cmd_sys___GUARANTEE0"));
(("command_sys", "w2_w6_cmd_sys___GUARANTEE1"),("w2_w6_cmd_sys", "w2_w6_cmd_sys___GUARANTEE1"));
(("command_sys", "w1_w5_cmd_sys___GUARANTEE0"),("w1_w5_cmd_sys", "w1_w5_cmd_sys___GUARANTEE0"));
(("command_sys", "w2_w6_cmd_sys___GUARANTEE2"),("w2_w6_cmd_sys", "w2_w6_cmd_sys___GUARANTEE2"));
(("command_sys", "w1_w5_cmd_sys___GUARANTEE1"),("w1_w5_cmd_sys", "w1_w5_cmd_sys___GUARANTEE1"));
(("command_sys", "w2_w6_cmd_sys___GUARANTEE0"),("w2_w6_cmd_sys", "w2_w6_cmd_sys___GUARANTEE0"));
(("command_sys", "w1_w5_cmd_sys___GUARANTEE2"),("w1_w5_cmd_sys", "w1_w5_cmd_sys___GUARANTEE2"));
(("command_sys", "w4_w8_cmd_sys___GUARANTEE1"),("w4_w8_cmd_sys", "w4_w8_cmd_sys___GUARANTEE1"));
(("command_sys", "w4_w8_cmd_sys___GUARANTEE2"),("w4_w8_cmd_sys", "w4_w8_cmd_sys___GUARANTEE2"));
(("command_sys", "w3_w7_cmd_sys___GUARANTEE1"),("w3_w7_cmd_sys", "w3_w7_cmd_sys___GUARANTEE1"));
(("command_sys", "w3_w7_cmd_sys___GUARANTEE2"),("w3_w7_cmd_sys", "w3_w7_cmd_sys___GUARANTEE2"));
(("command_sys", "w3_w7_cmd_sys___GUARANTEE0"),("w3_w7_cmd_sys", "w3_w7_cmd_sys___GUARANTEE0"));
(("channel1", "command_sys___GUARANTEE4"),("command_sys", "command_sys___GUARANTEE4"));
(("channel1", "command_sys___GUARANTEE5"),("command_sys", "command_sys___GUARANTEE5"));
(("channel1", "command_sys___GUARANTEE2"),("command_sys", "command_sys___GUARANTEE2"));
(("channel1", "command_sys___GUARANTEE3"),("command_sys", "command_sys___GUARANTEE3"));
(("channel1", "command_sys___GUARANTEE8"),("command_sys", "command_sys___GUARANTEE8"));
(("channel1", "command_sys___GUARANTEE9"),("command_sys", "command_sys___GUARANTEE9"));
(("channel1", "command_sys___GUARANTEE10"),("command_sys", "command_sys___GUARANTEE10"));
(("channel1", "command_sys___GUARANTEE6"),("command_sys", "command_sys___GUARANTEE6"));
(("channel1", "command_sys___GUARANTEE11"),("command_sys", "command_sys___GUARANTEE11"));
(("channel1", "command_sys___GUARANTEE7"),("command_sys", "command_sys___GUARANTEE7"));
(("channel1", "command_sys___GUARANTEE0"),("command_sys", "command_sys___GUARANTEE0"));
(("channel1", "command_sys___GUARANTEE1"),("command_sys", "command_sys___GUARANTEE1"));
(("channel2", "command_sys___GUARANTEE4"),("command_sys", "command_sys___GUARANTEE4"));
(("channel2", "command_sys___GUARANTEE5"),("command_sys", "command_sys___GUARANTEE5"));
(("channel2", "command_sys___GUARANTEE2"),("command_sys", "command_sys___GUARANTEE2"));
(("channel2", "command_sys___GUARANTEE3"),("command_sys", "command_sys___GUARANTEE3"));
(("channel2", "command_sys___GUARANTEE8"),("command_sys", "command_sys___GUARANTEE8"));
(("channel2", "command_sys___GUARANTEE9"),("command_sys", "command_sys___GUARANTEE9"));
(("channel2", "command_sys___GUARANTEE10"),("command_sys", "command_sys___GUARANTEE10"));
(("channel2", "command_sys___GUARANTEE6"),("command_sys", "command_sys___GUARANTEE6"));
(("channel2", "command_sys___GUARANTEE11"),("command_sys", "command_sys___GUARANTEE11"));
(("channel2", "command_sys___GUARANTEE7"),("command_sys", "command_sys___GUARANTEE7"));
(("channel2", "command_sys___GUARANTEE0"),("command_sys", "command_sys___GUARANTEE0"));
(("channel2", "command_sys___GUARANTEE1"),("command_sys", "command_sys___GUARANTEE1"));
(("bscu", "channel2___GUARANTEE2"),("channel2", "channel2___GUARANTEE2"));
(("bscu", "channel1___GUARANTEE3"),("channel1", "channel1___GUARANTEE3"));
(("bscu", "channel2___GUARANTEE3"),("channel2", "channel2___GUARANTEE3"));
(("bscu", "channel1___GUARANTEE4"),("channel1", "channel1___GUARANTEE4"));
(("bscu", "channel2___GUARANTEE0"),("channel2", "channel2___GUARANTEE0"));
(("bscu", "channel1___GUARANTEE5"),("channel1", "channel1___GUARANTEE5"));
(("bscu", "channel2___GUARANTEE1"),("channel2", "channel2___GUARANTEE1"));
(("bscu", "channel1___GUARANTEE6"),("channel1", "channel1___GUARANTEE6"));
(("bscu", "channel2___GUARANTEE10"),("channel2", "channel2___GUARANTEE10"));
(("bscu", "channel2___GUARANTEE6"),("channel2", "channel2___GUARANTEE6"));
(("bscu", "channel1___GUARANTEE0"),("channel1", "channel1___GUARANTEE0"));
(("bscu", "channel2___GUARANTEE7"),("channel2", "channel2___GUARANTEE7"));
(("bscu", "channel1___GUARANTEE1"),("channel1", "channel1___GUARANTEE1"));
(("bscu", "channel2___GUARANTEE4"),("channel2", "channel2___GUARANTEE4"));
(("bscu", "channel1___GUARANTEE2"),("channel1", "channel1___GUARANTEE2"));
(("bscu", "channel2___GUARANTEE5"),("channel2", "channel2___GUARANTEE5"));
(("bscu", "channel2___GUARANTEE11"),("channel2", "channel2___GUARANTEE11"));
(("bscu", "channel2___GUARANTEE12"),("channel2", "channel2___GUARANTEE12"));
(("bscu", "channel1___GUARANTEE12"),("channel1", "channel1___GUARANTEE12"));
(("bscu", "channel1___GUARANTEE11"),("channel1", "channel1___GUARANTEE11"));
(("bscu", "channel1___GUARANTEE10"),("channel1", "channel1___GUARANTEE10"));
(("bscu", "channel2___GUARANTEE8"),("channel2", "channel2___GUARANTEE8"));
(("bscu", "channel2___GUARANTEE9"),("channel2", "channel2___GUARANTEE9"));
(("bscu", "channel1___GUARANTEE7"),("channel1", "channel1___GUARANTEE7"));
(("bscu", "channel1___GUARANTEE8"),("channel1", "channel1___GUARANTEE8"));
(("bscu", "channel1___GUARANTEE9"),("channel1", "channel1___GUARANTEE9"));
(("ctrl_sys", "bscu___GUARANTEE9"),("bscu", "bscu___GUARANTEE9"));
(("ctrl_sys", "bscu___GUARANTEE8"),("bscu", "bscu___GUARANTEE8"));
(("ctrl_sys", "bscu___GUARANTEE7"),("bscu", "bscu___GUARANTEE7"));
(("ctrl_sys", "bscu___GUARANTEE6"),("bscu", "bscu___GUARANTEE6"));
(("ctrl_sys", "bscu___GUARANTEE5"),("bscu", "bscu___GUARANTEE5"));
(("ctrl_sys", "bscu___GUARANTEE4"),("bscu", "bscu___GUARANTEE4"));
(("ctrl_sys", "bscu___GUARANTEE3"),("bscu", "bscu___GUARANTEE3"));
(("ctrl_sys", "bscu___GUARANTEE2"),("bscu", "bscu___GUARANTEE2"));
(("ctrl_sys", "bscu___GUARANTEE1"),("bscu", "bscu___GUARANTEE1"));
(("ctrl_sys", "bscu___GUARANTEE10"),("bscu", "bscu___GUARANTEE10"));
(("ctrl_sys", "bscu___GUARANTEE0"),("bscu", "bscu___GUARANTEE0"));
(("ctrl_sys", "bscu___GUARANTEE11"),("bscu", "bscu___GUARANTEE11"));
(("WBS_inst", "phys_sys___GUARANTEE5"),("phys_sys", "phys_sys___GUARANTEE5"));
(("WBS_inst", "phys_sys___GUARANTEE6"),("phys_sys", "phys_sys___GUARANTEE6"));
(("WBS_inst", "phys_sys___GUARANTEE7"),("phys_sys", "phys_sys___GUARANTEE7"));
(("WBS_inst", "ctrl_sys___GUARANTEE13"),("ctrl_sys", "ctrl_sys___GUARANTEE13"));
(("WBS_inst", "phys_sys___GUARANTEE1"),("phys_sys", "phys_sys___GUARANTEE1"));
(("WBS_inst", "ctrl_sys___GUARANTEE11"),("ctrl_sys", "ctrl_sys___GUARANTEE11"));
(("WBS_inst", "phys_sys___GUARANTEE2"),("phys_sys", "phys_sys___GUARANTEE2"));
(("WBS_inst", "ctrl_sys___GUARANTEE12"),("ctrl_sys", "ctrl_sys___GUARANTEE12"));
(("WBS_inst", "phys_sys___GUARANTEE3"),("phys_sys", "phys_sys___GUARANTEE3"));
(("WBS_inst", "phys_sys___GUARANTEE4"),("phys_sys", "phys_sys___GUARANTEE4"));
(("WBS_inst", "ctrl_sys___GUARANTEE10"),("ctrl_sys", "ctrl_sys___GUARANTEE10"));
(("WBS_inst", "phys_sys___GUARANTEE0"),("phys_sys", "phys_sys___GUARANTEE0"));
(("WBS_inst", "phys_sys___GUARANTEE18"),("phys_sys", "phys_sys___GUARANTEE18"));
(("WBS_inst", "phys_sys___GUARANTEE13"),("phys_sys", "phys_sys___GUARANTEE13"));
(("WBS_inst", "phys_sys___GUARANTEE12"),("phys_sys", "phys_sys___GUARANTEE12"));
(("WBS_inst", "phys_sys___GUARANTEE11"),("phys_sys", "phys_sys___GUARANTEE11"));
(("WBS_inst", "phys_sys___GUARANTEE10"),("phys_sys", "phys_sys___GUARANTEE10"));
(("WBS_inst", "phys_sys___GUARANTEE17"),("phys_sys", "phys_sys___GUARANTEE17"));
(("WBS_inst", "phys_sys___GUARANTEE16"),("phys_sys", "phys_sys___GUARANTEE16"));
(("WBS_inst", "phys_sys___GUARANTEE15"),("phys_sys", "phys_sys___GUARANTEE15"));
(("WBS_inst", "phys_sys___GUARANTEE14"),("phys_sys", "phys_sys___GUARANTEE14"));
(("WBS_inst", "phys_sys___GUARANTEE9"),("phys_sys", "phys_sys___GUARANTEE9"));
(("WBS_inst", "ctrl_sys___GUARANTEE9"),("ctrl_sys", "ctrl_sys___GUARANTEE9"));
(("WBS_inst", "ctrl_sys___GUARANTEE8"),("ctrl_sys", "ctrl_sys___GUARANTEE8"));
(("WBS_inst", "ctrl_sys___GUARANTEE7"),("ctrl_sys", "ctrl_sys___GUARANTEE7"));
(("WBS_inst", "ctrl_sys___GUARANTEE6"),("ctrl_sys", "ctrl_sys___GUARANTEE6"));
];
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE0"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE0;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE0 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE0 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE0 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE0;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE0 "model_WBS_inst___GUARANTEE0_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE0 "model_WBS_inst___GUARANTEE0_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE0 "model_WBS_inst___GUARANTEE0_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE0_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE0;;
probErrorCutImp model_WBS_inst___GUARANTEE0_ftree;;
probErrorCut model_WBS_inst___GUARANTEE0_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE0_direct_ftree.gv" model_WBS_inst___GUARANTEE0_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE0_optimized_ftree.gv" model_WBS_inst___GUARANTEE0_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE1 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE1"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE1;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE1 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE1 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE1 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE1;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE1 "model_WBS_inst___GUARANTEE1_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE1 "model_WBS_inst___GUARANTEE1_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE1 "model_WBS_inst___GUARANTEE1_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE1_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE1;;
probErrorCutImp model_WBS_inst___GUARANTEE1_ftree;;
probErrorCut model_WBS_inst___GUARANTEE1_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE1_direct_ftree.gv" model_WBS_inst___GUARANTEE1_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE1_optimized_ftree.gv" model_WBS_inst___GUARANTEE1_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE2 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE2"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE2;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE2 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE2 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE2 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE2;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE2 "model_WBS_inst___GUARANTEE2_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE2 "model_WBS_inst___GUARANTEE2_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE2 "model_WBS_inst___GUARANTEE2_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE2_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE2;;
probErrorCutImp model_WBS_inst___GUARANTEE2_ftree;;
probErrorCut model_WBS_inst___GUARANTEE2_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE2_direct_ftree.gv" model_WBS_inst___GUARANTEE2_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE2_optimized_ftree.gv" model_WBS_inst___GUARANTEE2_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE3 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE3"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE3;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE3 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE3 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE3 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE3;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE3 "model_WBS_inst___GUARANTEE3_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE3 "model_WBS_inst___GUARANTEE3_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE3 "model_WBS_inst___GUARANTEE3_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE3_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE3;;
probErrorCutImp model_WBS_inst___GUARANTEE3_ftree;;
probErrorCut model_WBS_inst___GUARANTEE3_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE3_direct_ftree.gv" model_WBS_inst___GUARANTEE3_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE3_optimized_ftree.gv" model_WBS_inst___GUARANTEE3_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE4 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE4"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE4;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE4 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE4 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE4 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE4;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE4 "model_WBS_inst___GUARANTEE4_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE4 "model_WBS_inst___GUARANTEE4_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE4 "model_WBS_inst___GUARANTEE4_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE4_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE4;;
probErrorCutImp model_WBS_inst___GUARANTEE4_ftree;;
probErrorCut model_WBS_inst___GUARANTEE4_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE4_direct_ftree.gv" model_WBS_inst___GUARANTEE4_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE4_optimized_ftree.gv" model_WBS_inst___GUARANTEE4_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE5 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE5"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE5;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE5 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE5 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE5 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE5;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE5 "model_WBS_inst___GUARANTEE5_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE5 "model_WBS_inst___GUARANTEE5_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE5 "model_WBS_inst___GUARANTEE5_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE5_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE5;;
probErrorCutImp model_WBS_inst___GUARANTEE5_ftree;;
probErrorCut model_WBS_inst___GUARANTEE5_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE5_direct_ftree.gv" model_WBS_inst___GUARANTEE5_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE5_optimized_ftree.gv" model_WBS_inst___GUARANTEE5_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE6 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE6"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE6;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE6 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE6 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE6 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE6;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE6 "model_WBS_inst___GUARANTEE6_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE6 "model_WBS_inst___GUARANTEE6_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE6 "model_WBS_inst___GUARANTEE6_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE6_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE6;;
probErrorCutImp model_WBS_inst___GUARANTEE6_ftree;;
probErrorCut model_WBS_inst___GUARANTEE6_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE6_direct_ftree.gv" model_WBS_inst___GUARANTEE6_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE6_optimized_ftree.gv" model_WBS_inst___GUARANTEE6_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE7 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE7"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE7;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE7 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE7 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE7 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE7;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE7 "model_WBS_inst___GUARANTEE7_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE7 "model_WBS_inst___GUARANTEE7_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE7 "model_WBS_inst___GUARANTEE7_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE7_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE7;;
probErrorCutImp model_WBS_inst___GUARANTEE7_ftree;;
probErrorCut model_WBS_inst___GUARANTEE7_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE7_direct_ftree.gv" model_WBS_inst___GUARANTEE7_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE7_optimized_ftree.gv" model_WBS_inst___GUARANTEE7_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE8 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE8"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE8;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE8 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE8 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE8 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE8;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE8 "model_WBS_inst___GUARANTEE8_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE8 "model_WBS_inst___GUARANTEE8_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE8 "model_WBS_inst___GUARANTEE8_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE8_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE8;;
probErrorCutImp model_WBS_inst___GUARANTEE8_ftree;;
probErrorCut model_WBS_inst___GUARANTEE8_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE8_direct_ftree.gv" model_WBS_inst___GUARANTEE8_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE8_optimized_ftree.gv" model_WBS_inst___GUARANTEE8_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE9 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE9"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE9;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE9 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE9 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE9 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE9;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE9 "model_WBS_inst___GUARANTEE9_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE9 "model_WBS_inst___GUARANTEE9_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE9 "model_WBS_inst___GUARANTEE9_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE9_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE9;;
probErrorCutImp model_WBS_inst___GUARANTEE9_ftree;;
probErrorCut model_WBS_inst___GUARANTEE9_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE9_direct_ftree.gv" model_WBS_inst___GUARANTEE9_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE9_optimized_ftree.gv" model_WBS_inst___GUARANTEE9_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE10 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE10"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE10;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE10 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE10 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE10 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE10;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE10 "model_WBS_inst___GUARANTEE10_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE10 "model_WBS_inst___GUARANTEE10_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE10 "model_WBS_inst___GUARANTEE10_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE10_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE10;;
probErrorCutImp model_WBS_inst___GUARANTEE10_ftree;;
probErrorCut model_WBS_inst___GUARANTEE10_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE10_direct_ftree.gv" model_WBS_inst___GUARANTEE10_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE10_optimized_ftree.gv" model_WBS_inst___GUARANTEE10_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE11 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE11"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE11;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE11 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE11 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE11 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE11;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE11 "model_WBS_inst___GUARANTEE11_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE11 "model_WBS_inst___GUARANTEE11_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE11 "model_WBS_inst___GUARANTEE11_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE11_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE11;;
probErrorCutImp model_WBS_inst___GUARANTEE11_ftree;;
probErrorCut model_WBS_inst___GUARANTEE11_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE11_direct_ftree.gv" model_WBS_inst___GUARANTEE11_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE11_optimized_ftree.gv" model_WBS_inst___GUARANTEE11_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE12 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE12"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE12;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE12 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE12 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE12 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE12;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE12 "model_WBS_inst___GUARANTEE12_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE12 "model_WBS_inst___GUARANTEE12_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE12 "model_WBS_inst___GUARANTEE12_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE12_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE12;;
probErrorCutImp model_WBS_inst___GUARANTEE12_ftree;;
probErrorCut model_WBS_inst___GUARANTEE12_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE12_direct_ftree.gv" model_WBS_inst___GUARANTEE12_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE12_optimized_ftree.gv" model_WBS_inst___GUARANTEE12_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE13 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE13"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE13;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE13 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE13 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE13 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE13;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE13 "model_WBS_inst___GUARANTEE13_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE13 "model_WBS_inst___GUARANTEE13_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE13 "model_WBS_inst___GUARANTEE13_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE13_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE13;;
probErrorCutImp model_WBS_inst___GUARANTEE13_ftree;;
probErrorCut model_WBS_inst___GUARANTEE13_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE13_direct_ftree.gv" model_WBS_inst___GUARANTEE13_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE13_optimized_ftree.gv" model_WBS_inst___GUARANTEE13_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE14 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE14"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE14;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE14 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE14 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE14 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE14;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE14 "model_WBS_inst___GUARANTEE14_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE14 "model_WBS_inst___GUARANTEE14_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE14 "model_WBS_inst___GUARANTEE14_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE14_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE14;;
probErrorCutImp model_WBS_inst___GUARANTEE14_ftree;;
probErrorCut model_WBS_inst___GUARANTEE14_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE14_direct_ftree.gv" model_WBS_inst___GUARANTEE14_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE14_optimized_ftree.gv" model_WBS_inst___GUARANTEE14_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE15 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE15"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE15;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE15 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE15 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE15 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE15;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE15 "model_WBS_inst___GUARANTEE15_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE15 "model_WBS_inst___GUARANTEE15_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE15 "model_WBS_inst___GUARANTEE15_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE15_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE15;;
probErrorCutImp model_WBS_inst___GUARANTEE15_ftree;;
probErrorCut model_WBS_inst___GUARANTEE15_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE15_direct_ftree.gv" model_WBS_inst___GUARANTEE15_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE15_optimized_ftree.gv" model_WBS_inst___GUARANTEE15_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE16 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE16"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE16;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE16 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE16 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE16 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE16;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE16 "model_WBS_inst___GUARANTEE16_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE16 "model_WBS_inst___GUARANTEE16_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE16 "model_WBS_inst___GUARANTEE16_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE16_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE16;;
probErrorCutImp model_WBS_inst___GUARANTEE16_ftree;;
probErrorCut model_WBS_inst___GUARANTEE16_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE16_direct_ftree.gv" model_WBS_inst___GUARANTEE16_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE16_optimized_ftree.gv" model_WBS_inst___GUARANTEE16_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE17 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE17"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE17;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE17 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE17 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE17 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE17;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE17 "model_WBS_inst___GUARANTEE17_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE17 "model_WBS_inst___GUARANTEE17_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE17 "model_WBS_inst___GUARANTEE17_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE17_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE17;;
probErrorCutImp model_WBS_inst___GUARANTEE17_ftree;;
probErrorCut model_WBS_inst___GUARANTEE17_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE17_direct_ftree.gv" model_WBS_inst___GUARANTEE17_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE17_optimized_ftree.gv" model_WBS_inst___GUARANTEE17_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE18 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE18"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE18;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE18 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE18 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE18 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE18;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE18 "model_WBS_inst___GUARANTEE18_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE18 "model_WBS_inst___GUARANTEE18_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE18 "model_WBS_inst___GUARANTEE18_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE18_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE18;;
probErrorCutImp model_WBS_inst___GUARANTEE18_ftree;;
probErrorCut model_WBS_inst___GUARANTEE18_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE18_direct_ftree.gv" model_WBS_inst___GUARANTEE18_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE18_optimized_ftree.gv" model_WBS_inst___GUARANTEE18_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE19 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE19"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE19;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE19 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE19 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE19 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE19;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE19 "model_WBS_inst___GUARANTEE19_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE19 "model_WBS_inst___GUARANTEE19_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE19 "model_WBS_inst___GUARANTEE19_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE19_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE19;;
probErrorCutImp model_WBS_inst___GUARANTEE19_ftree;;
probErrorCut model_WBS_inst___GUARANTEE19_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE19_direct_ftree.gv" model_WBS_inst___GUARANTEE19_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE19_optimized_ftree.gv" model_WBS_inst___GUARANTEE19_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE20 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE20"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE20;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE20 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE20 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE20 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE20;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE20 "model_WBS_inst___GUARANTEE20_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE20 "model_WBS_inst___GUARANTEE20_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE20 "model_WBS_inst___GUARANTEE20_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE20_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE20;;
probErrorCutImp model_WBS_inst___GUARANTEE20_ftree;;
probErrorCut model_WBS_inst___GUARANTEE20_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE20_direct_ftree.gv" model_WBS_inst___GUARANTEE20_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE20_optimized_ftree.gv" model_WBS_inst___GUARANTEE20_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE21 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE21"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE21;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE21 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE21 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE21 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE21;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE21 "model_WBS_inst___GUARANTEE21_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE21 "model_WBS_inst___GUARANTEE21_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE21 "model_WBS_inst___GUARANTEE21_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE21_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE21;;
probErrorCutImp model_WBS_inst___GUARANTEE21_ftree;;
probErrorCut model_WBS_inst___GUARANTEE21_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE21_direct_ftree.gv" model_WBS_inst___GUARANTEE21_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE21_optimized_ftree.gv" model_WBS_inst___GUARANTEE21_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE22 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE22"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE22;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE22 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE22 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE22 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE22;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE22 "model_WBS_inst___GUARANTEE22_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE22 "model_WBS_inst___GUARANTEE22_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE22 "model_WBS_inst___GUARANTEE22_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE22_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE22;;
probErrorCutImp model_WBS_inst___GUARANTEE22_ftree;;
probErrorCut model_WBS_inst___GUARANTEE22_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE22_direct_ftree.gv" model_WBS_inst___GUARANTEE22_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE22_optimized_ftree.gv" model_WBS_inst___GUARANTEE22_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE23 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE23"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE23;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE23 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE23 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE23 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE23;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE23 "model_WBS_inst___GUARANTEE23_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE23 "model_WBS_inst___GUARANTEE23_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE23 "model_WBS_inst___GUARANTEE23_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE23_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE23;;
probErrorCutImp model_WBS_inst___GUARANTEE23_ftree;;
probErrorCut model_WBS_inst___GUARANTEE23_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE23_direct_ftree.gv" model_WBS_inst___GUARANTEE23_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE23_optimized_ftree.gv" model_WBS_inst___GUARANTEE23_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE24 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE24"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE24;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE24 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE24 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE24 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE24;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE24 "model_WBS_inst___GUARANTEE24_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE24 "model_WBS_inst___GUARANTEE24_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE24 "model_WBS_inst___GUARANTEE24_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE24_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE24;;
probErrorCutImp model_WBS_inst___GUARANTEE24_ftree;;
probErrorCut model_WBS_inst___GUARANTEE24_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE24_direct_ftree.gv" model_WBS_inst___GUARANTEE24_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE24_optimized_ftree.gv" model_WBS_inst___GUARANTEE24_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE25 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE25"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE25;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE25 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE25 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE25 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE25;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE25 "model_WBS_inst___GUARANTEE25_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE25 "model_WBS_inst___GUARANTEE25_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE25 "model_WBS_inst___GUARANTEE25_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE25_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE25;;
probErrorCutImp model_WBS_inst___GUARANTEE25_ftree;;
probErrorCut model_WBS_inst___GUARANTEE25_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE25_direct_ftree.gv" model_WBS_inst___GUARANTEE25_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE25_optimized_ftree.gv" model_WBS_inst___GUARANTEE25_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE26 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE26"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE26;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE26 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE26 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE26 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE26;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE26 "model_WBS_inst___GUARANTEE26_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE26 "model_WBS_inst___GUARANTEE26_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE26 "model_WBS_inst___GUARANTEE26_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE26_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE26;;
probErrorCutImp model_WBS_inst___GUARANTEE26_ftree;;
probErrorCut model_WBS_inst___GUARANTEE26_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE26_direct_ftree.gv" model_WBS_inst___GUARANTEE26_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE26_optimized_ftree.gv" model_WBS_inst___GUARANTEE26_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE27 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE27"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE27;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE27 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE27 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE27 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE27;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE27 "model_WBS_inst___GUARANTEE27_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE27 "model_WBS_inst___GUARANTEE27_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE27 "model_WBS_inst___GUARANTEE27_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE27_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE27;;
probErrorCutImp model_WBS_inst___GUARANTEE27_ftree;;
probErrorCut model_WBS_inst___GUARANTEE27_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE27_direct_ftree.gv" model_WBS_inst___GUARANTEE27_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE27_optimized_ftree.gv" model_WBS_inst___GUARANTEE27_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_WBS_inst___GUARANTEE28 = 
{instances = model_WBS_inst___GUARANTEE0.instances;
connections=model_WBS_inst___GUARANTEE0.connections;
top_fault = ("WBS_inst", F["WBS_inst___GUARANTEE28"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_WBS_inst___GUARANTEE28;;
checkModel_cnameInstanceIsDefinedInLibrary model_WBS_inst___GUARANTEE28 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_WBS_inst___GUARANTEE28 comp_library;;
checkModel_validConnections model_WBS_inst___GUARANTEE28 comp_library;;
checkModel_inputFlowUnique model_WBS_inst___GUARANTEE28;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_WBS_inst___GUARANTEE28 "model_WBS_inst___GUARANTEE28_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE28 "model_WBS_inst___GUARANTEE28_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_WBS_inst___GUARANTEE28 "model_WBS_inst___GUARANTEE28_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_WBS_inst___GUARANTEE28_ftree = model_to_ftree comp_library model_WBS_inst___GUARANTEE28;;
probErrorCutImp model_WBS_inst___GUARANTEE28_ftree;;
probErrorCut model_WBS_inst___GUARANTEE28_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE28_direct_ftree.gv" model_WBS_inst___GUARANTEE28_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_WBS_inst___GUARANTEE28_optimized_ftree.gv" model_WBS_inst___GUARANTEE28_ftree ;;

