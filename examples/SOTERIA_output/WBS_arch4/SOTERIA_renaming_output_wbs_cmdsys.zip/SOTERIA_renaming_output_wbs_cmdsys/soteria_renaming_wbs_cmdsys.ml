#use "top.ml";;
(* ----- COMPONENT LIBRARY ----- *)

let comp_library = 
  [
{name = "w1_w5_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"; "fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"; "fault__independently__active__brake_command_facility__brake_command_facility__fault_1"; "fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"; "fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"; "fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["w1_w5_cmd_sys___GUARANTEE0"; "w1_w5_cmd_sys___GUARANTEE1"; "w1_w5_cmd_sys___GUARANTEE2"];
formulas = [
(["w1_w5_cmd_sys___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]]); 
(["w1_w5_cmd_sys___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"]]); 
(["w1_w5_cmd_sys___GUARANTEE2"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"]])]
}; 

{name = "w2_w6_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"; "fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"; "fault__independently__active__brake_command_facility__brake_command_facility__fault_1"; "fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"; "fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"; "fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["w2_w6_cmd_sys___GUARANTEE1"; "w2_w6_cmd_sys___GUARANTEE2"; "w2_w6_cmd_sys___GUARANTEE0"];
formulas = [
(["w2_w6_cmd_sys___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"]]); 
(["w2_w6_cmd_sys___GUARANTEE2"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"]]); 
(["w2_w6_cmd_sys___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]])]
}; 

{name = "w3_w7_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"; "fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"; "fault__independently__active__brake_command_facility__brake_command_facility__fault_1"; "fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"; "fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"; "fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["w3_w7_cmd_sys___GUARANTEE1"; "w3_w7_cmd_sys___GUARANTEE2"; "w3_w7_cmd_sys___GUARANTEE0"];
formulas = [
(["w3_w7_cmd_sys___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"]]); 
(["w3_w7_cmd_sys___GUARANTEE2"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"]]); 
(["w3_w7_cmd_sys___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]])]
}; 

{name = "w4_w8_cmd_sys";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"; "fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"; "fault__independently__active__brake_command_facility__brake_command_facility__fault_1"; "fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"; "fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"; "fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"];
event_info = [(9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0); (9.0E-6, 1.0)];
output_flows = ["w4_w8_cmd_sys___GUARANTEE0"; "w4_w8_cmd_sys___GUARANTEE1"; "w4_w8_cmd_sys___GUARANTEE2"];
formulas = [
(["w4_w8_cmd_sys___GUARANTEE0"; "contract violation"],
Or[F["fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]]); 
(["w4_w8_cmd_sys___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"]]); 
(["w4_w8_cmd_sys___GUARANTEE2"; "contract violation"],
Or[F["fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"]; 
F["fault__independently__active__brake_command_facility__brake_command_facility__fault_1"]; 
F["fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"]])]
}; 

{name = "CommandSystem";
faults = ["contract violation"];
input_flows = ["w4_w8_cmd_sys___GUARANTEE0"; "w2_w6_cmd_sys___GUARANTEE1"; "w1_w5_cmd_sys___GUARANTEE0"; "w2_w6_cmd_sys___GUARANTEE2"; "w1_w5_cmd_sys___GUARANTEE1"; "w2_w6_cmd_sys___GUARANTEE0"; "w1_w5_cmd_sys___GUARANTEE2"; "w4_w8_cmd_sys___GUARANTEE1"; "w4_w8_cmd_sys___GUARANTEE2"; "w3_w7_cmd_sys___GUARANTEE1"; "w3_w7_cmd_sys___GUARANTEE2"; "w3_w7_cmd_sys___GUARANTEE0"];
basic_events = [];
event_info = [];
output_flows = ["CommandSystem___GUARANTEE10"; "CommandSystem___GUARANTEE11"; "CommandSystem___GUARANTEE0"; "CommandSystem___GUARANTEE2"; "CommandSystem___GUARANTEE1"; "CommandSystem___GUARANTEE4"; "CommandSystem___GUARANTEE3"; "CommandSystem___GUARANTEE6"; "CommandSystem___GUARANTEE5"; "CommandSystem___GUARANTEE8"; "CommandSystem___GUARANTEE7"; "CommandSystem___GUARANTEE9"];
formulas = [
(["CommandSystem___GUARANTEE10"; "contract violation"],
F["w3_w7_cmd_sys___GUARANTEE2"; "contract violation"]); 
(["CommandSystem___GUARANTEE11"; "contract violation"],
F["w4_w8_cmd_sys___GUARANTEE2"; "contract violation"]); 
(["CommandSystem___GUARANTEE0"; "contract violation"],
F["w1_w5_cmd_sys___GUARANTEE0"; "contract violation"]); 
(["CommandSystem___GUARANTEE2"; "contract violation"],
F["w3_w7_cmd_sys___GUARANTEE0"; "contract violation"]); 
(["CommandSystem___GUARANTEE1"; "contract violation"],
F["w2_w6_cmd_sys___GUARANTEE0"; "contract violation"]); 
(["CommandSystem___GUARANTEE4"; "contract violation"],
F["w1_w5_cmd_sys___GUARANTEE1"; "contract violation"]); 
(["CommandSystem___GUARANTEE3"; "contract violation"],
F["w4_w8_cmd_sys___GUARANTEE0"; "contract violation"]); 
(["CommandSystem___GUARANTEE6"; "contract violation"],
F["w3_w7_cmd_sys___GUARANTEE1"; "contract violation"]); 
(["CommandSystem___GUARANTEE5"; "contract violation"],
F["w2_w6_cmd_sys___GUARANTEE1"; "contract violation"]); 
(["CommandSystem___GUARANTEE8"; "contract violation"],
F["w1_w5_cmd_sys___GUARANTEE2"; "contract violation"]); 
(["CommandSystem___GUARANTEE7"; "contract violation"],
F["w4_w8_cmd_sys___GUARANTEE1"; "contract violation"]); 
(["CommandSystem___GUARANTEE9"; "contract violation"],
F["w2_w6_cmd_sys___GUARANTEE2"; "contract violation"])]
}];;

(* ----- CHECK LIBRARY ----- *)
checkLibrary_componentUnique comp_library;;
checkLibrary_nonEmptyFaults comp_library;;
checkLibrary_disjointInputFlowsandBasicEvents comp_library;;
checkLibrary_listsAreConsistentLengths comp_library;;
checkLibrary_allOutputFaultsHaveFormulas comp_library;;
checkLibrary_formulasMakeSense comp_library;;


(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE0 = 
{instances = 
[makeInstance "w1_w5_cmd_sys" "w1_w5_cmd_sys"();
makeInstance "w2_w6_cmd_sys" "w2_w6_cmd_sys"();
makeInstance "w3_w7_cmd_sys" "w3_w7_cmd_sys"();
makeInstance "w4_w8_cmd_sys" "w4_w8_cmd_sys"();
makeInstance "CommandSystem" "CommandSystem"();
];
connections = 
[(("CommandSystem", "w4_w8_cmd_sys___GUARANTEE0"),("w4_w8_cmd_sys", "w4_w8_cmd_sys___GUARANTEE0")); (("CommandSystem", "w2_w6_cmd_sys___GUARANTEE1"),("w2_w6_cmd_sys", "w2_w6_cmd_sys___GUARANTEE1")); (("CommandSystem", "w1_w5_cmd_sys___GUARANTEE0"),("w1_w5_cmd_sys", "w1_w5_cmd_sys___GUARANTEE0")); (("CommandSystem", "w2_w6_cmd_sys___GUARANTEE2"),("w2_w6_cmd_sys", "w2_w6_cmd_sys___GUARANTEE2")); (("CommandSystem", "w1_w5_cmd_sys___GUARANTEE1"),("w1_w5_cmd_sys", "w1_w5_cmd_sys___GUARANTEE1")); (("CommandSystem", "w2_w6_cmd_sys___GUARANTEE0"),("w2_w6_cmd_sys", "w2_w6_cmd_sys___GUARANTEE0")); (("CommandSystem", "w1_w5_cmd_sys___GUARANTEE2"),("w1_w5_cmd_sys", "w1_w5_cmd_sys___GUARANTEE2")); (("CommandSystem", "w4_w8_cmd_sys___GUARANTEE1"),("w4_w8_cmd_sys", "w4_w8_cmd_sys___GUARANTEE1")); (("CommandSystem", "w4_w8_cmd_sys___GUARANTEE2"),("w4_w8_cmd_sys", "w4_w8_cmd_sys___GUARANTEE2")); (("CommandSystem", "w3_w7_cmd_sys___GUARANTEE1"),("w3_w7_cmd_sys", "w3_w7_cmd_sys___GUARANTEE1")); (("CommandSystem", "w3_w7_cmd_sys___GUARANTEE2"),("w3_w7_cmd_sys", "w3_w7_cmd_sys___GUARANTEE2")); (("CommandSystem", "w3_w7_cmd_sys___GUARANTEE0"),("w3_w7_cmd_sys", "w3_w7_cmd_sys___GUARANTEE0")); ];
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE0"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE0;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE0 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE0 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE0 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE0;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE0 "model_CommandSystem___GUARANTEE0_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE0 "model_CommandSystem___GUARANTEE0_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE0 "model_CommandSystem___GUARANTEE0_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE0_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE0;;
probErrorCutImp model_CommandSystem___GUARANTEE0_ftree;;
probErrorCut model_CommandSystem___GUARANTEE0_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE0_direct_ftree.gv" model_CommandSystem___GUARANTEE0_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE0_optimized_ftree.gv" model_CommandSystem___GUARANTEE0_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE1 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE1"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE1;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE1 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE1 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE1 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE1;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE1 "model_CommandSystem___GUARANTEE1_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE1 "model_CommandSystem___GUARANTEE1_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE1 "model_CommandSystem___GUARANTEE1_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE1_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE1;;
probErrorCutImp model_CommandSystem___GUARANTEE1_ftree;;
probErrorCut model_CommandSystem___GUARANTEE1_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE1_direct_ftree.gv" model_CommandSystem___GUARANTEE1_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE1_optimized_ftree.gv" model_CommandSystem___GUARANTEE1_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE2 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE2"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE2;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE2 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE2 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE2 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE2;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE2 "model_CommandSystem___GUARANTEE2_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE2 "model_CommandSystem___GUARANTEE2_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE2 "model_CommandSystem___GUARANTEE2_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE2_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE2;;
probErrorCutImp model_CommandSystem___GUARANTEE2_ftree;;
probErrorCut model_CommandSystem___GUARANTEE2_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE2_direct_ftree.gv" model_CommandSystem___GUARANTEE2_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE2_optimized_ftree.gv" model_CommandSystem___GUARANTEE2_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE3 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE3"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE3;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE3 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE3 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE3 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE3;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE3 "model_CommandSystem___GUARANTEE3_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE3 "model_CommandSystem___GUARANTEE3_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE3 "model_CommandSystem___GUARANTEE3_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE3_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE3;;
probErrorCutImp model_CommandSystem___GUARANTEE3_ftree;;
probErrorCut model_CommandSystem___GUARANTEE3_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE3_direct_ftree.gv" model_CommandSystem___GUARANTEE3_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE3_optimized_ftree.gv" model_CommandSystem___GUARANTEE3_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE4 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE4"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE4;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE4 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE4 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE4 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE4;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE4 "model_CommandSystem___GUARANTEE4_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE4 "model_CommandSystem___GUARANTEE4_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE4 "model_CommandSystem___GUARANTEE4_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE4_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE4;;
probErrorCutImp model_CommandSystem___GUARANTEE4_ftree;;
probErrorCut model_CommandSystem___GUARANTEE4_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE4_direct_ftree.gv" model_CommandSystem___GUARANTEE4_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE4_optimized_ftree.gv" model_CommandSystem___GUARANTEE4_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE5 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE5"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE5;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE5 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE5 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE5 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE5;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE5 "model_CommandSystem___GUARANTEE5_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE5 "model_CommandSystem___GUARANTEE5_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE5 "model_CommandSystem___GUARANTEE5_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE5_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE5;;
probErrorCutImp model_CommandSystem___GUARANTEE5_ftree;;
probErrorCut model_CommandSystem___GUARANTEE5_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE5_direct_ftree.gv" model_CommandSystem___GUARANTEE5_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE5_optimized_ftree.gv" model_CommandSystem___GUARANTEE5_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE6 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE6"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE6;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE6 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE6 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE6 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE6;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE6 "model_CommandSystem___GUARANTEE6_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE6 "model_CommandSystem___GUARANTEE6_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE6 "model_CommandSystem___GUARANTEE6_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE6_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE6;;
probErrorCutImp model_CommandSystem___GUARANTEE6_ftree;;
probErrorCut model_CommandSystem___GUARANTEE6_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE6_direct_ftree.gv" model_CommandSystem___GUARANTEE6_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE6_optimized_ftree.gv" model_CommandSystem___GUARANTEE6_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE7 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE7"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE7;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE7 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE7 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE7 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE7;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE7 "model_CommandSystem___GUARANTEE7_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE7 "model_CommandSystem___GUARANTEE7_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE7 "model_CommandSystem___GUARANTEE7_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE7_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE7;;
probErrorCutImp model_CommandSystem___GUARANTEE7_ftree;;
probErrorCut model_CommandSystem___GUARANTEE7_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE7_direct_ftree.gv" model_CommandSystem___GUARANTEE7_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE7_optimized_ftree.gv" model_CommandSystem___GUARANTEE7_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE8 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE8"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE8;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE8 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE8 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE8 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE8;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE8 "model_CommandSystem___GUARANTEE8_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE8 "model_CommandSystem___GUARANTEE8_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE8 "model_CommandSystem___GUARANTEE8_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE8_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE8;;
probErrorCutImp model_CommandSystem___GUARANTEE8_ftree;;
probErrorCut model_CommandSystem___GUARANTEE8_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE8_direct_ftree.gv" model_CommandSystem___GUARANTEE8_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE8_optimized_ftree.gv" model_CommandSystem___GUARANTEE8_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE9 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE9"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE9;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE9 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE9 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE9 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE9;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE9 "model_CommandSystem___GUARANTEE9_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE9 "model_CommandSystem___GUARANTEE9_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE9 "model_CommandSystem___GUARANTEE9_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE9_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE9;;
probErrorCutImp model_CommandSystem___GUARANTEE9_ftree;;
probErrorCut model_CommandSystem___GUARANTEE9_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE9_direct_ftree.gv" model_CommandSystem___GUARANTEE9_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE9_optimized_ftree.gv" model_CommandSystem___GUARANTEE9_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE10 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE10"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE10;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE10 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE10 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE10 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE10;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE10 "model_CommandSystem___GUARANTEE10_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE10 "model_CommandSystem___GUARANTEE10_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE10 "model_CommandSystem___GUARANTEE10_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE10_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE10;;
probErrorCutImp model_CommandSystem___GUARANTEE10_ftree;;
probErrorCut model_CommandSystem___GUARANTEE10_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE10_direct_ftree.gv" model_CommandSystem___GUARANTEE10_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE10_optimized_ftree.gv" model_CommandSystem___GUARANTEE10_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_CommandSystem___GUARANTEE11 = 
{instances = model_CommandSystem___GUARANTEE0.instances;
connections=model_CommandSystem___GUARANTEE0.connections;
top_fault = ("CommandSystem", F["CommandSystem___GUARANTEE11"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_CommandSystem___GUARANTEE11;;
checkModel_cnameInstanceIsDefinedInLibrary model_CommandSystem___GUARANTEE11 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_CommandSystem___GUARANTEE11 comp_library;;
checkModel_validConnections model_CommandSystem___GUARANTEE11 comp_library;;
checkModel_inputFlowUnique model_CommandSystem___GUARANTEE11;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_CommandSystem___GUARANTEE11 "model_CommandSystem___GUARANTEE11_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE11 "model_CommandSystem___GUARANTEE11_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_CommandSystem___GUARANTEE11 "model_CommandSystem___GUARANTEE11_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_CommandSystem___GUARANTEE11_ftree = model_to_ftree comp_library model_CommandSystem___GUARANTEE11;;
probErrorCutImp model_CommandSystem___GUARANTEE11_ftree;;
probErrorCut model_CommandSystem___GUARANTEE11_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_CommandSystem___GUARANTEE11_direct_ftree.gv" model_CommandSystem___GUARANTEE11_ftree ;;
dot_gen_show_tree_file "model_CommandSystem___GUARANTEE11_optimized_ftree.gv" model_CommandSystem___GUARANTEE11_ftree ;;

