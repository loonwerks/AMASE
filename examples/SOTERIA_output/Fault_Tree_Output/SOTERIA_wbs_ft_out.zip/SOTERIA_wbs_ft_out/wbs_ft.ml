#use "top.ml";;
let fault__independently__active__mv8__mv8__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv8__mv8__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__wheel_sensor3__wheel_sensor3__fault_2 = 
  Leaf
    (("WBS_inst","fault__independently__active__wheel_sensor3__wheel_sensor3__fault_2"),5.0E-6, 1.0);;
let fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
  Leaf
    (("w1_w5_cmd_sys","fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
  Leaf
    (("channel1","fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let fault__independently__active__wheel_sensor5__wheel_sensor5__fault_2 = 
  Leaf
    (("WBS_inst","fault__independently__active__wheel_sensor5__wheel_sensor5__fault_2"),5.0E-6, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_pair_2_6__switch_gate_brake_as_cmd_pair_2_6__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_pair_2_6__switch_gate_brake_as_cmd_pair_2_6__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__brake_actuator__brake_actuator__fault_2 = 
  Leaf
    (("wheel_brake1","fault__independently__active__brake_actuator__brake_actuator__fault_2"),3.3E-6, 1.0);;
let fault__independently__active__mv7__mv7__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv7__mv7__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
  Leaf
    (("wheel_brake1","fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2 = 
  Leaf
    (("wheel_brake1","fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2"),3.3E-5, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_pair_3_7__switch_gate_brake_as_cmd_pair_3_7__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_pair_3_7__switch_gate_brake_as_cmd_pair_3_7__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__wheel_sensor1__wheel_sensor1__fault_2 = 
  Leaf
    (("WBS_inst","fault__independently__active__wheel_sensor1__wheel_sensor1__fault_2"),5.0E-6, 1.0);;
let fault__independently__active__wheel_sensor6__wheel_sensor6__fault_2 = 
  Leaf
    (("WBS_inst","fault__independently__active__wheel_sensor6__wheel_sensor6__fault_2"),5.0E-6, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__selector_valve__selector_valve__fault_2 = 
  Leaf
    (("phys_sys","fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let fault__independently__active__wheel_sensor8__wheel_sensor8__fault_2 = 
  Leaf
    (("WBS_inst","fault__independently__active__wheel_sensor8__wheel_sensor8__fault_2"),5.0E-6, 1.0);;
let fault__independently__active__selector_valve__selector_valve__fault_1 = 
  Leaf
    (("phys_sys","fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let fault__independently__active__wheel_sensor4__wheel_sensor4__fault_2 = 
  Leaf
    (("WBS_inst","fault__independently__active__wheel_sensor4__wheel_sensor4__fault_2"),5.0E-6, 1.0);;
let fault__independently__active__mv3__mv3__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv3__mv3__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_pair_4_8__switch_gate_brake_as_cmd_pair_4_8__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_pair_4_8__switch_gate_brake_as_cmd_pair_4_8__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__mv2__mv2__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv2__mv2__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_pair_1_5__switch_gate_brake_as_cmd_pair_1_5__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_pair_1_5__switch_gate_brake_as_cmd_pair_1_5__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
  Leaf
    (("w1_w5_cmd_sys","fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let fault__independently__active__mv1__mv1__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv1__mv1__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2 = 
  Leaf
    (("wheel_brake1","fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2"),3.3E-5, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
  Leaf
    (("wheel_brake1","fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1 = 
  Leaf
    (("w1_w5_cmd_sys","fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"),9.0E-6, 1.0);;
let fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
  Leaf
    (("w1_w5_cmd_sys","fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let fault__independently__active__mv6__mv6__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv6__mv6__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__accumulator__accumulator__fault_2 = 
  Leaf
    (("phys_sys","fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let fault__independently__active__shutoff_valve__shutoff_valve__fault_2 = 
  Leaf
    (("phys_sys","fault__independently__active__shutoff_valve__shutoff_valve__fault_2"),5.0E-6, 1.0);;
let fault__independently__active__mv5__mv5__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv5__mv5__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
  Leaf
    (("w1_w5_cmd_sys","fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1 = 
  Leaf
    (("phys_sys","fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1"),3.0E-5, 1.0);;
let fault__independently__active__mv4__mv4__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv4__mv4__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__wheel_sensor7__wheel_sensor7__fault_2 = 
  Leaf
    (("WBS_inst","fault__independently__active__wheel_sensor7__wheel_sensor7__fault_2"),5.0E-6, 1.0);;
let fault__independently__active__wheel_sensor2__wheel_sensor2__fault_2 = 
  Leaf
    (("WBS_inst","fault__independently__active__wheel_sensor2__wheel_sensor2__fault_2"),5.0E-6, 1.0);;
let fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2 = 
  Leaf
    (("bscu","fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2"),1.3E-5, 1.0);;
let fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
  Leaf
    (("w1_w5_cmd_sys","fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let w3_w7_cmd_sys___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1;
    fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
    fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE0 = 
  SUM [
    w3_w7_cmd_sys___GUARANTEE0_0    ];;
let command_sys___GUARANTEE2_0 = 
  SUM [
    w3_w7_cmd_sys___GUARANTEE0    ];;
let command_sys___GUARANTEE2 = 
  SUM [
    command_sys___GUARANTEE2_0    ];;
let channel2___GUARANTEE2_0 = 
  SUM [
    command_sys___GUARANTEE2    ];;
let channel2___GUARANTEE2 = 
  SUM [
    channel2___GUARANTEE2_0    ];;
let w4_w8_cmd_sys___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1;
    fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
    fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE0 = 
  SUM [
    w4_w8_cmd_sys___GUARANTEE0_0    ];;
let command_sys___GUARANTEE3_0 = 
  SUM [
    w4_w8_cmd_sys___GUARANTEE0    ];;
let command_sys___GUARANTEE3 = 
  SUM [
    command_sys___GUARANTEE3_0    ];;
let channel2___GUARANTEE3_0 = 
  SUM [
    command_sys___GUARANTEE3    ];;
let channel2___GUARANTEE3 = 
  SUM [
    channel2___GUARANTEE3_0    ];;
let wheel_brake4___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake4___GUARANTEE0 = 
  SUM [
    wheel_brake4___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE3_0 = 
  SUM [
    fault__independently__active__mv4__mv4__fault_4    ];;
let normal_sys___GUARANTEE3 = 
  SUM [
    normal_sys___GUARANTEE3_0    ];;
let alt_sys___GUARANTEE3_0 = 
  SUM [
    fault__independently__active__mv4__mv4__fault_4    ];;
let alt_sys___GUARANTEE3 = 
  SUM [
    alt_sys___GUARANTEE3_0    ];;
let phys_sys___GUARANTEE18_7 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake4___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE3;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let w1_w5_cmd_sys___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1;
    fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
    fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE0 = 
  SUM [
    w1_w5_cmd_sys___GUARANTEE0_0    ];;
let command_sys___GUARANTEE0_0 = 
  SUM [
    w1_w5_cmd_sys___GUARANTEE0    ];;
let command_sys___GUARANTEE0 = 
  SUM [
    command_sys___GUARANTEE0_0    ];;
let channel2___GUARANTEE0_0 = 
  SUM [
    command_sys___GUARANTEE0    ];;
let channel2___GUARANTEE0 = 
  SUM [
    channel2___GUARANTEE0_0    ];;
let w2_w6_cmd_sys___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1;
    fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
    fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE0 = 
  SUM [
    w2_w6_cmd_sys___GUARANTEE0_0    ];;
let command_sys___GUARANTEE1_0 = 
  SUM [
    w2_w6_cmd_sys___GUARANTEE0    ];;
let command_sys___GUARANTEE1 = 
  SUM [
    command_sys___GUARANTEE1_0    ];;
let channel2___GUARANTEE1_0 = 
  SUM [
    command_sys___GUARANTEE1    ];;
let channel2___GUARANTEE1 = 
  SUM [
    channel2___GUARANTEE1_0    ];;
let w3_w7_cmd_sys___GUARANTEE2_0 = 
  SUM [
    fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
    fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
    fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE2 = 
  SUM [
    w3_w7_cmd_sys___GUARANTEE2_0    ];;
let command_sys___GUARANTEE10_0 = 
  SUM [
    w3_w7_cmd_sys___GUARANTEE2    ];;
let command_sys___GUARANTEE10 = 
  SUM [
    command_sys___GUARANTEE10_0    ];;
let channel2___GUARANTEE10_0 = 
  SUM [
    command_sys___GUARANTEE10    ];;
let channel2___GUARANTEE10 = 
  SUM [
    channel2___GUARANTEE10_0    ];;
let w3_w7_cmd_sys___GUARANTEE1_0 = 
  SUM [
    fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
    fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
    fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE1 = 
  SUM [
    w3_w7_cmd_sys___GUARANTEE1_0    ];;
let command_sys___GUARANTEE6_0 = 
  SUM [
    w3_w7_cmd_sys___GUARANTEE1    ];;
let command_sys___GUARANTEE6 = 
  SUM [
    command_sys___GUARANTEE6_0    ];;
let channel2___GUARANTEE6_0 = 
  SUM [
    command_sys___GUARANTEE6    ];;
let channel2___GUARANTEE6 = 
  SUM [
    channel2___GUARANTEE6_0    ];;
let w4_w8_cmd_sys___GUARANTEE1_0 = 
  SUM [
    fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
    fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
    fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE1 = 
  SUM [
    w4_w8_cmd_sys___GUARANTEE1_0    ];;
let command_sys___GUARANTEE7_0 = 
  SUM [
    w4_w8_cmd_sys___GUARANTEE1    ];;
let command_sys___GUARANTEE7 = 
  SUM [
    command_sys___GUARANTEE7_0    ];;
let channel2___GUARANTEE7_0 = 
  SUM [
    command_sys___GUARANTEE7    ];;
let channel2___GUARANTEE7 = 
  SUM [
    channel2___GUARANTEE7_0    ];;
let w1_w5_cmd_sys___GUARANTEE1_0 = 
  SUM [
    fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
    fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
    fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE1 = 
  SUM [
    w1_w5_cmd_sys___GUARANTEE1_0    ];;
let command_sys___GUARANTEE4_0 = 
  SUM [
    w1_w5_cmd_sys___GUARANTEE1    ];;
let command_sys___GUARANTEE4 = 
  SUM [
    command_sys___GUARANTEE4_0    ];;
let channel2___GUARANTEE4_0 = 
  SUM [
    command_sys___GUARANTEE4    ];;
let channel2___GUARANTEE4 = 
  SUM [
    channel2___GUARANTEE4_0    ];;
let w2_w6_cmd_sys___GUARANTEE1_0 = 
  SUM [
    fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
    fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
    fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE1 = 
  SUM [
    w2_w6_cmd_sys___GUARANTEE1_0    ];;
let command_sys___GUARANTEE5_0 = 
  SUM [
    w2_w6_cmd_sys___GUARANTEE1    ];;
let command_sys___GUARANTEE5 = 
  SUM [
    command_sys___GUARANTEE5_0    ];;
let channel2___GUARANTEE5_0 = 
  SUM [
    command_sys___GUARANTEE5    ];;
let channel2___GUARANTEE5 = 
  SUM [
    channel2___GUARANTEE5_0    ];;
let alt_sys___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__mv1__mv1__fault_4    ];;
let alt_sys___GUARANTEE0 = 
  SUM [
    alt_sys___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__mv1__mv1__fault_4    ];;
let normal_sys___GUARANTEE0 = 
  SUM [
    normal_sys___GUARANTEE0_0    ];;
let wheel_brake1___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake1___GUARANTEE0 = 
  SUM [
    wheel_brake1___GUARANTEE0_0    ];;
let phys_sys___GUARANTEE18_1 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0;
    normal_sys___GUARANTEE0;
    wheel_brake1___GUARANTEE0    ];;
let wheel_brake2___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake2___GUARANTEE0 = 
  SUM [
    wheel_brake2___GUARANTEE0_0    ];;
let alt_sys___GUARANTEE1_0 = 
  SUM [
    fault__independently__active__mv2__mv2__fault_4    ];;
let alt_sys___GUARANTEE1 = 
  SUM [
    alt_sys___GUARANTEE1_0    ];;
let normal_sys___GUARANTEE1_0 = 
  SUM [
    fault__independently__active__mv2__mv2__fault_4    ];;
let normal_sys___GUARANTEE1 = 
  SUM [
    normal_sys___GUARANTEE1_0    ];;
let phys_sys___GUARANTEE18_2 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    wheel_brake2___GUARANTEE0;
    alt_sys___GUARANTEE1;
    normal_sys___GUARANTEE1    ];;
let channel1___GUARANTEE3_0 = 
  SUM [
    command_sys___GUARANTEE3    ];;
let channel1___GUARANTEE3 = 
  SUM [
    channel1___GUARANTEE3_0    ];;
let bscu___GUARANTEE3_0 = 
  SUM [
    channel1___GUARANTEE3;
    channel2___GUARANTEE3;
    fault__independently__active__switch_gate_brake_as_cmd_pair_4_8__switch_gate_brake_as_cmd_pair_4_8__fault_2    ];;
let wheel_brake5___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake5___GUARANTEE0 = 
  SUM [
    wheel_brake5___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE4_0 = 
  SUM [
    fault__independently__active__mv5__mv5__fault_4    ];;
let normal_sys___GUARANTEE4 = 
  SUM [
    normal_sys___GUARANTEE4_0    ];;
let phys_sys___GUARANTEE18_0 = 
  SUM [
    wheel_brake5___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE4;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0    ];;
let wheel_brake8___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake8___GUARANTEE0 = 
  SUM [
    wheel_brake8___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE7_0 = 
  SUM [
    fault__independently__active__mv8__mv8__fault_4    ];;
let normal_sys___GUARANTEE7 = 
  SUM [
    normal_sys___GUARANTEE7_0    ];;
let phys_sys___GUARANTEE18_5 = 
  SUM [
    wheel_brake8___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE7;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let w4_w8_cmd_sys___GUARANTEE2_0 = 
  SUM [
    fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
    fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
    fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE2 = 
  SUM [
    w4_w8_cmd_sys___GUARANTEE2_0    ];;
let command_sys___GUARANTEE11_0 = 
  SUM [
    w4_w8_cmd_sys___GUARANTEE2    ];;
let command_sys___GUARANTEE11 = 
  SUM [
    command_sys___GUARANTEE11_0    ];;
let channel2___GUARANTEE11_0 = 
  SUM [
    command_sys___GUARANTEE11    ];;
let channel2___GUARANTEE11 = 
  SUM [
    channel2___GUARANTEE11_0    ];;
let wheel_brake7___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake7___GUARANTEE0 = 
  SUM [
    wheel_brake7___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE6_0 = 
  SUM [
    fault__independently__active__mv7__mv7__fault_4    ];;
let normal_sys___GUARANTEE6 = 
  SUM [
    normal_sys___GUARANTEE6_0    ];;
let alt_sys___GUARANTEE2_0 = 
  SUM [
    fault__independently__active__mv3__mv3__fault_4    ];;
let alt_sys___GUARANTEE2 = 
  SUM [
    alt_sys___GUARANTEE2_0    ];;
let phys_sys___GUARANTEE18_6 = 
  SUM [
    wheel_brake7___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE6;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let channel2___GUARANTEE12_0 = 
  SUM [
    fault__independently__active__monitor_sys__monitor_sys__fault_1    ];;
let channel2___GUARANTEE12 = 
  SUM [
    channel2___GUARANTEE12_0    ];;
let wheel_brake6___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake6___GUARANTEE0 = 
  SUM [
    wheel_brake6___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE5_0 = 
  SUM [
    fault__independently__active__mv6__mv6__fault_4    ];;
let normal_sys___GUARANTEE5 = 
  SUM [
    normal_sys___GUARANTEE5_0    ];;
let phys_sys___GUARANTEE18_3 = 
  SUM [
    wheel_brake6___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    normal_sys___GUARANTEE5;
    alt_sys___GUARANTEE1    ];;
let wheel_brake3___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake3___GUARANTEE0 = 
  SUM [
    wheel_brake3___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE2_0 = 
  SUM [
    fault__independently__active__mv3__mv3__fault_4    ];;
let normal_sys___GUARANTEE2 = 
  SUM [
    normal_sys___GUARANTEE2_0    ];;
let phys_sys___GUARANTEE18_4 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake3___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let channel1___GUARANTEE12_0 = 
  SUM [
    fault__independently__active__monitor_sys__monitor_sys__fault_1    ];;
let channel1___GUARANTEE12 = 
  SUM [
    channel1___GUARANTEE12_0    ];;
let w2_w6_cmd_sys___GUARANTEE2_0 = 
  SUM [
    fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
    fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
    fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE2 = 
  SUM [
    w2_w6_cmd_sys___GUARANTEE2_0    ];;
let command_sys___GUARANTEE9_0 = 
  SUM [
    w2_w6_cmd_sys___GUARANTEE2    ];;
let command_sys___GUARANTEE9 = 
  SUM [
    command_sys___GUARANTEE9_0    ];;
let channel2___GUARANTEE9_0 = 
  SUM [
    command_sys___GUARANTEE9    ];;
let channel2___GUARANTEE9 = 
  SUM [
    channel2___GUARANTEE9_0    ];;
let channel1___GUARANTEE9_0 = 
  SUM [
    command_sys___GUARANTEE9    ];;
let channel1___GUARANTEE9 = 
  SUM [
    channel1___GUARANTEE9_0    ];;
let bscu___GUARANTEE9_0 = 
  SUM [
    channel1___GUARANTEE12;
    channel2___GUARANTEE9;
    channel2___GUARANTEE12;
    channel1___GUARANTEE9;
    fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2    ];;
let bscu___GUARANTEE9 = 
  SUM [
    bscu___GUARANTEE9_0    ];;
let w1_w5_cmd_sys___GUARANTEE2_0 = 
  SUM [
    fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
    fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
    fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE2 = 
  SUM [
    w1_w5_cmd_sys___GUARANTEE2_0    ];;
let command_sys___GUARANTEE8_0 = 
  SUM [
    w1_w5_cmd_sys___GUARANTEE2    ];;
let command_sys___GUARANTEE8 = 
  SUM [
    command_sys___GUARANTEE8_0    ];;
let channel2___GUARANTEE8_0 = 
  SUM [
    command_sys___GUARANTEE8    ];;
let channel2___GUARANTEE8 = 
  SUM [
    channel2___GUARANTEE8_0    ];;
let channel1___GUARANTEE8_0 = 
  SUM [
    command_sys___GUARANTEE8    ];;
let channel1___GUARANTEE8 = 
  SUM [
    channel1___GUARANTEE8_0    ];;
let bscu___GUARANTEE8_0 = 
  SUM [
    fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2;
    channel1___GUARANTEE12;
    channel2___GUARANTEE8;
    channel1___GUARANTEE8;
    channel2___GUARANTEE12    ];;
let bscu___GUARANTEE8 = 
  SUM [
    bscu___GUARANTEE8_0    ];;
let channel1___GUARANTEE7_0 = 
  SUM [
    command_sys___GUARANTEE7    ];;
let channel1___GUARANTEE7 = 
  SUM [
    channel1___GUARANTEE7_0    ];;
let bscu___GUARANTEE7_0 = 
  SUM [
    channel1___GUARANTEE12;
    fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2;
    channel2___GUARANTEE7;
    channel1___GUARANTEE7;
    channel2___GUARANTEE12    ];;
let bscu___GUARANTEE7 = 
  SUM [
    bscu___GUARANTEE7_0    ];;
let channel1___GUARANTEE6_0 = 
  SUM [
    command_sys___GUARANTEE6    ];;
let channel1___GUARANTEE6 = 
  SUM [
    channel1___GUARANTEE6_0    ];;
let bscu___GUARANTEE6_0 = 
  SUM [
    channel1___GUARANTEE12;
    channel1___GUARANTEE6;
    channel2___GUARANTEE6;
    fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2;
    channel2___GUARANTEE12    ];;
let bscu___GUARANTEE6 = 
  SUM [
    bscu___GUARANTEE6_0    ];;
let channel1___GUARANTEE5_0 = 
  SUM [
    command_sys___GUARANTEE5    ];;
let channel1___GUARANTEE5 = 
  SUM [
    channel1___GUARANTEE5_0    ];;
let bscu___GUARANTEE5_0 = 
  SUM [
    channel1___GUARANTEE12;
    channel1___GUARANTEE5;
    fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2;
    channel2___GUARANTEE5;
    channel2___GUARANTEE12    ];;
let bscu___GUARANTEE5 = 
  SUM [
    bscu___GUARANTEE5_0    ];;
let channel1___GUARANTEE4_0 = 
  SUM [
    command_sys___GUARANTEE4    ];;
let channel1___GUARANTEE4 = 
  SUM [
    channel1___GUARANTEE4_0    ];;
let bscu___GUARANTEE4_0 = 
  SUM [
    channel1___GUARANTEE4;
    channel1___GUARANTEE12;
    channel2___GUARANTEE4;
    fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2;
    channel2___GUARANTEE12    ];;
let bscu___GUARANTEE4 = 
  SUM [
    bscu___GUARANTEE4_0    ];;
let bscu___GUARANTEE3 = 
  SUM [
    bscu___GUARANTEE3_0    ];;
let channel1___GUARANTEE2_0 = 
  SUM [
    command_sys___GUARANTEE2    ];;
let channel1___GUARANTEE2 = 
  SUM [
    channel1___GUARANTEE2_0    ];;
let bscu___GUARANTEE2_0 = 
  SUM [
    channel2___GUARANTEE2;
    fault__independently__active__switch_gate_brake_as_cmd_pair_3_7__switch_gate_brake_as_cmd_pair_3_7__fault_2;
    channel1___GUARANTEE2    ];;
let bscu___GUARANTEE2 = 
  SUM [
    bscu___GUARANTEE2_0    ];;
let channel1___GUARANTEE1_0 = 
  SUM [
    command_sys___GUARANTEE1    ];;
let channel1___GUARANTEE1 = 
  SUM [
    channel1___GUARANTEE1_0    ];;
let bscu___GUARANTEE1_0 = 
  SUM [
    channel2___GUARANTEE1;
    channel1___GUARANTEE1;
    fault__independently__active__switch_gate_brake_as_cmd_pair_2_6__switch_gate_brake_as_cmd_pair_2_6__fault_2    ];;
let bscu___GUARANTEE1 = 
  SUM [
    bscu___GUARANTEE1_0    ];;
let channel1___GUARANTEE10_0 = 
  SUM [
    command_sys___GUARANTEE10    ];;
let channel1___GUARANTEE10 = 
  SUM [
    channel1___GUARANTEE10_0    ];;
let bscu___GUARANTEE10_0 = 
  SUM [
    channel1___GUARANTEE12;
    channel2___GUARANTEE10;
    fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2;
    channel2___GUARANTEE12;
    channel1___GUARANTEE10    ];;
let bscu___GUARANTEE10 = 
  SUM [
    bscu___GUARANTEE10_0    ];;
let channel1___GUARANTEE0_0 = 
  SUM [
    command_sys___GUARANTEE0    ];;
let channel1___GUARANTEE0 = 
  SUM [
    channel1___GUARANTEE0_0    ];;
let bscu___GUARANTEE0_0 = 
  SUM [
    channel2___GUARANTEE0;
    channel1___GUARANTEE0;
    fault__independently__active__switch_gate_brake_as_cmd_pair_1_5__switch_gate_brake_as_cmd_pair_1_5__fault_2    ];;
let bscu___GUARANTEE0 = 
  SUM [
    bscu___GUARANTEE0_0    ];;
let channel1___GUARANTEE11_0 = 
  SUM [
    command_sys___GUARANTEE11    ];;
let channel1___GUARANTEE11 = 
  SUM [
    channel1___GUARANTEE11_0    ];;
let bscu___GUARANTEE11_0 = 
  SUM [
    channel1___GUARANTEE12;
    fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2;
    channel2___GUARANTEE11;
    channel2___GUARANTEE12;
    channel1___GUARANTEE11    ];;
let bscu___GUARANTEE11 = 
  SUM [
    bscu___GUARANTEE11_0    ];;
let ctrl_sys___GUARANTEE4_0 = 
  SUM [
    bscu___GUARANTEE9;
    bscu___GUARANTEE8;
    bscu___GUARANTEE7;
    bscu___GUARANTEE6;
    bscu___GUARANTEE5;
    bscu___GUARANTEE4;
    bscu___GUARANTEE3;
    bscu___GUARANTEE2;
    bscu___GUARANTEE1;
    bscu___GUARANTEE10;
    bscu___GUARANTEE0;
    bscu___GUARANTEE11    ];;
let phys_sys___GUARANTEE9_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0;
    normal_sys___GUARANTEE0;
    wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE9 = 
  SUM [
    phys_sys___GUARANTEE9_0    ];;
let wBS_inst___GUARANTEE13_0 = 
  SUM [
    phys_sys___GUARANTEE9    ];;
let phys_sys___GUARANTEE4_0 = 
  SUM [
    wheel_brake5___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE4;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE13_0 = 
  SUM [
    wheel_brake5___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE4;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE13 = 
  SUM [
    phys_sys___GUARANTEE13_0    ];;
let wBS_inst___GUARANTEE4_5 = 
  SUM [
    phys_sys___GUARANTEE13    ];;
let phys_sys___GUARANTEE12_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake4___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE3;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE12 = 
  SUM [
    phys_sys___GUARANTEE12_0    ];;
let wBS_inst___GUARANTEE4_6 = 
  SUM [
    phys_sys___GUARANTEE12    ];;
let phys_sys___GUARANTEE11_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake3___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE11 = 
  SUM [
    phys_sys___GUARANTEE11_0    ];;
let wBS_inst___GUARANTEE4_7 = 
  SUM [
    phys_sys___GUARANTEE11    ];;
let phys_sys___GUARANTEE10_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    wheel_brake2___GUARANTEE0;
    alt_sys___GUARANTEE1;
    normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE10 = 
  SUM [
    phys_sys___GUARANTEE10_0    ];;
let wBS_inst___GUARANTEE4_8 = 
  SUM [
    phys_sys___GUARANTEE10    ];;
let phys_sys___GUARANTEE16_0 = 
  SUM [
    wheel_brake8___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE7;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE16 = 
  SUM [
    phys_sys___GUARANTEE16_0    ];;
let wBS_inst___GUARANTEE4_1 = 
  SUM [
    phys_sys___GUARANTEE16    ];;
let wBS_inst___GUARANTEE4_2 = 
  SUM [
    phys_sys___GUARANTEE9    ];;
let phys_sys___GUARANTEE15_0 = 
  SUM [
    wheel_brake7___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE6;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE15 = 
  SUM [
    phys_sys___GUARANTEE15_0    ];;
let wBS_inst___GUARANTEE4_3 = 
  SUM [
    phys_sys___GUARANTEE15    ];;
let phys_sys___GUARANTEE14_0 = 
  SUM [
    wheel_brake6___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    normal_sys___GUARANTEE5;
    alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE14 = 
  SUM [
    phys_sys___GUARANTEE14_0    ];;
let wBS_inst___GUARANTEE4_4 = 
  SUM [
    phys_sys___GUARANTEE14    ];;
let phys_sys___GUARANTEE18 = 
  PRO [
    phys_sys___GUARANTEE18_7;
    phys_sys___GUARANTEE18_1;
    phys_sys___GUARANTEE18_2;
    phys_sys___GUARANTEE18_0;
    phys_sys___GUARANTEE18_5;
    phys_sys___GUARANTEE18_6;
    phys_sys___GUARANTEE18_3;
    phys_sys___GUARANTEE18_4    ];;
let wBS_inst___GUARANTEE3_0 = 
  SUM [
    phys_sys___GUARANTEE18    ];;
let phys_sys___GUARANTEE17_2 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    wheel_brake2___GUARANTEE0;
    alt_sys___GUARANTEE1;
    normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_3 = 
  SUM [
    wheel_brake6___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    normal_sys___GUARANTEE5;
    alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_0 = 
  SUM [
    wheel_brake5___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE4;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_1 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0;
    normal_sys___GUARANTEE0;
    wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_6 = 
  SUM [
    wheel_brake7___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE6;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE17_7 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake4___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE3;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE17_4 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake3___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE17_5 = 
  SUM [
    wheel_brake8___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE7;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE17 = 
  PRO [
    phys_sys___GUARANTEE17_2;
    phys_sys___GUARANTEE17_3;
    phys_sys___GUARANTEE17_0;
    phys_sys___GUARANTEE17_1;
    phys_sys___GUARANTEE17_6;
    phys_sys___GUARANTEE17_7;
    phys_sys___GUARANTEE17_4;
    phys_sys___GUARANTEE17_5    ];;
let wBS_inst___GUARANTEE3_1 = 
  SUM [
    phys_sys___GUARANTEE17    ];;
let ctrl_sys___GUARANTEE12_0 = 
  SUM [
    bscu___GUARANTEE10    ];;
let phys_sys___GUARANTEE4 = 
  SUM [
    phys_sys___GUARANTEE4_0    ];;
let wBS_inst___GUARANTEE25_0 = 
  SUM [
    phys_sys___GUARANTEE4    ];;
let ctrl_sys___GUARANTEE13_0 = 
  SUM [
    bscu___GUARANTEE11    ];;
let ctrl_sys___GUARANTEE13 = 
  SUM [
    ctrl_sys___GUARANTEE13_0    ];;
let wBS_inst___GUARANTEE12_0 = 
  SUM [
    ctrl_sys___GUARANTEE13;
    phys_sys___GUARANTEE16;
    fault__independently__active__wheel_sensor8__wheel_sensor8__fault_2    ];;
let phys_sys___GUARANTEE5_0 = 
  SUM [
    wheel_brake6___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    normal_sys___GUARANTEE5;
    alt_sys___GUARANTEE1    ];;
let ctrl_sys___GUARANTEE5_0 = 
  SUM [
    bscu___GUARANTEE9;
    bscu___GUARANTEE8;
    bscu___GUARANTEE7;
    bscu___GUARANTEE6;
    bscu___GUARANTEE5;
    bscu___GUARANTEE4;
    bscu___GUARANTEE3;
    bscu___GUARANTEE2;
    bscu___GUARANTEE1;
    bscu___GUARANTEE10;
    bscu___GUARANTEE0;
    bscu___GUARANTEE11    ];;
let ctrl_sys___GUARANTEE6_0 = 
  SUM [
    bscu___GUARANTEE4    ];;
let ctrl_sys___GUARANTEE6 = 
  SUM [
    ctrl_sys___GUARANTEE6_0    ];;
let wBS_inst___GUARANTEE5_0 = 
  SUM [
    ctrl_sys___GUARANTEE6;
    fault__independently__active__wheel_sensor1__wheel_sensor1__fault_2;
    phys_sys___GUARANTEE9    ];;
let wBS_inst___GUARANTEE4_0 = 
  SUM [
    phys_sys___GUARANTEE18    ];;
let phys_sys___GUARANTEE3_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake4___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE3;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE3 = 
  SUM [
    phys_sys___GUARANTEE3_0    ];;
let wBS_inst___GUARANTEE24_0 = 
  SUM [
    phys_sys___GUARANTEE3    ];;
let ctrl_sys___GUARANTEE11_0 = 
  SUM [
    bscu___GUARANTEE9    ];;
let ctrl_sys___GUARANTEE11 = 
  SUM [
    ctrl_sys___GUARANTEE11_0    ];;
let ctrl_sys___GUARANTEE12 = 
  SUM [
    ctrl_sys___GUARANTEE12_0    ];;
let ctrl_sys___GUARANTEE10_0 = 
  SUM [
    bscu___GUARANTEE8    ];;
let ctrl_sys___GUARANTEE10 = 
  SUM [
    ctrl_sys___GUARANTEE10_0    ];;
let ctrl_sys___GUARANTEE2_0 = 
  SUM [
    bscu___GUARANTEE2    ];;
let wBS_inst___GUARANTEE15_0 = 
  SUM [
    phys_sys___GUARANTEE11    ];;
let phys_sys___GUARANTEE2_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake3___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let ctrl_sys___GUARANTEE7_0 = 
  SUM [
    bscu___GUARANTEE5    ];;
let ctrl_sys___GUARANTEE7 = 
  SUM [
    ctrl_sys___GUARANTEE7_0    ];;
let wBS_inst___GUARANTEE6_0 = 
  SUM [
    ctrl_sys___GUARANTEE7;
    phys_sys___GUARANTEE10;
    fault__independently__active__wheel_sensor2__wheel_sensor2__fault_2    ];;
let phys_sys___GUARANTEE6_0 = 
  SUM [
    wheel_brake7___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE6;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE6 = 
  SUM [
    phys_sys___GUARANTEE6_0    ];;
let wBS_inst___GUARANTEE27_0 = 
  SUM [
    phys_sys___GUARANTEE6    ];;
let ctrl_sys___GUARANTEE3_0 = 
  SUM [
    bscu___GUARANTEE3    ];;
let wBS_inst___GUARANTEE14_0 = 
  SUM [
    phys_sys___GUARANTEE10    ];;
let ctrl_sys___GUARANTEE8_0 = 
  SUM [
    bscu___GUARANTEE6    ];;
let ctrl_sys___GUARANTEE8 = 
  SUM [
    ctrl_sys___GUARANTEE8_0    ];;
let wBS_inst___GUARANTEE7_0 = 
  SUM [
    ctrl_sys___GUARANTEE8;
    phys_sys___GUARANTEE11;
    fault__independently__active__wheel_sensor3__wheel_sensor3__fault_2    ];;
let wBS_inst___GUARANTEE5 = 
  SUM [
    wBS_inst___GUARANTEE5_0    ];;
let wBS_inst___GUARANTEE4 = 
  PRO [
    wBS_inst___GUARANTEE4_0;
    wBS_inst___GUARANTEE4_5;
    wBS_inst___GUARANTEE4_6;
    wBS_inst___GUARANTEE4_7;
    wBS_inst___GUARANTEE4_8;
    wBS_inst___GUARANTEE4_1;
    wBS_inst___GUARANTEE4_2;
    wBS_inst___GUARANTEE4_3;
    wBS_inst___GUARANTEE4_4    ];;
let wBS_inst___GUARANTEE3_6 = 
  SUM [
    phys_sys___GUARANTEE13    ];;
let wBS_inst___GUARANTEE3_7 = 
  SUM [
    phys_sys___GUARANTEE12    ];;
let wBS_inst___GUARANTEE3_8 = 
  SUM [
    phys_sys___GUARANTEE11    ];;
let wBS_inst___GUARANTEE3_9 = 
  SUM [
    phys_sys___GUARANTEE10    ];;
let wBS_inst___GUARANTEE3_2 = 
  SUM [
    phys_sys___GUARANTEE16    ];;
let wBS_inst___GUARANTEE3_3 = 
  SUM [
    phys_sys___GUARANTEE9    ];;
let wBS_inst___GUARANTEE3_4 = 
  SUM [
    phys_sys___GUARANTEE15    ];;
let wBS_inst___GUARANTEE3_5 = 
  SUM [
    phys_sys___GUARANTEE14    ];;
let wBS_inst___GUARANTEE3 = 
  PRO [
    wBS_inst___GUARANTEE3_0;
    wBS_inst___GUARANTEE3_1;
    wBS_inst___GUARANTEE3_6;
    wBS_inst___GUARANTEE3_7;
    wBS_inst___GUARANTEE3_8;
    wBS_inst___GUARANTEE3_9;
    wBS_inst___GUARANTEE3_2;
    wBS_inst___GUARANTEE3_3;
    wBS_inst___GUARANTEE3_4;
    wBS_inst___GUARANTEE3_5    ];;
let phys_sys___GUARANTEE7_0 = 
  SUM [
    wheel_brake8___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE7;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE7 = 
  SUM [
    phys_sys___GUARANTEE7_0    ];;
let phys_sys___GUARANTEE2 = 
  SUM [
    phys_sys___GUARANTEE2_0    ];;
let wBS_inst___GUARANTEE2_0 = 
  SUM [
    phys_sys___GUARANTEE6;
    phys_sys___GUARANTEE7;
    phys_sys___GUARANTEE2;
    phys_sys___GUARANTEE3    ];;
let wBS_inst___GUARANTEE2 = 
  SUM [
    wBS_inst___GUARANTEE2_0    ];;
let phys_sys___GUARANTEE5 = 
  SUM [
    phys_sys___GUARANTEE5_0    ];;
let phys_sys___GUARANTEE1_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    wheel_brake2___GUARANTEE0;
    alt_sys___GUARANTEE1;
    normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE1 = 
  SUM [
    phys_sys___GUARANTEE1_0    ];;
let phys_sys___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0;
    normal_sys___GUARANTEE0;
    wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE0 = 
  SUM [
    phys_sys___GUARANTEE0_0    ];;
let wBS_inst___GUARANTEE1_0 = 
  SUM [
    phys_sys___GUARANTEE5;
    phys_sys___GUARANTEE1;
    phys_sys___GUARANTEE4;
    phys_sys___GUARANTEE0    ];;
let wBS_inst___GUARANTEE1 = 
  SUM [
    wBS_inst___GUARANTEE1_0    ];;
let wBS_inst___GUARANTEE0_1 = 
  SUM [
    phys_sys___GUARANTEE1    ];;
let wBS_inst___GUARANTEE0_2 = 
  SUM [
    phys_sys___GUARANTEE0    ];;
let wBS_inst___GUARANTEE0_3 = 
  SUM [
    phys_sys___GUARANTEE7    ];;
let wBS_inst___GUARANTEE0_4 = 
  SUM [
    phys_sys___GUARANTEE6    ];;
let wBS_inst___GUARANTEE0_0 = 
  SUM [
    phys_sys___GUARANTEE2    ];;
let wBS_inst___GUARANTEE0_5 = 
  SUM [
    phys_sys___GUARANTEE5    ];;
let wBS_inst___GUARANTEE0_6 = 
  SUM [
    phys_sys___GUARANTEE4    ];;
let wBS_inst___GUARANTEE0_7 = 
  SUM [
    phys_sys___GUARANTEE3    ];;
let wBS_inst___GUARANTEE0 = 
  PRO [
    wBS_inst___GUARANTEE0_1;
    wBS_inst___GUARANTEE0_2;
    wBS_inst___GUARANTEE0_3;
    wBS_inst___GUARANTEE0_4;
    wBS_inst___GUARANTEE0_0;
    wBS_inst___GUARANTEE0_5;
    wBS_inst___GUARANTEE0_6;
    wBS_inst___GUARANTEE0_7    ];;
let wBS_inst___GUARANTEE26_0 = 
  SUM [
    phys_sys___GUARANTEE5    ];;
let wBS_inst___GUARANTEE9_0 = 
  SUM [
    phys_sys___GUARANTEE13;
    ctrl_sys___GUARANTEE10;
    fault__independently__active__wheel_sensor5__wheel_sensor5__fault_2    ];;
let wBS_inst___GUARANTEE9 = 
  SUM [
    wBS_inst___GUARANTEE9_0    ];;
let ctrl_sys___GUARANTEE9_0 = 
  SUM [
    bscu___GUARANTEE7    ];;
let ctrl_sys___GUARANTEE9 = 
  SUM [
    ctrl_sys___GUARANTEE9_0    ];;
let wBS_inst___GUARANTEE8_0 = 
  SUM [
    ctrl_sys___GUARANTEE9;
    phys_sys___GUARANTEE12;
    fault__independently__active__wheel_sensor4__wheel_sensor4__fault_2    ];;
let wBS_inst___GUARANTEE8 = 
  SUM [
    wBS_inst___GUARANTEE8_0    ];;
let wBS_inst___GUARANTEE7 = 
  SUM [
    wBS_inst___GUARANTEE7_0    ];;
let wBS_inst___GUARANTEE6 = 
  SUM [
    wBS_inst___GUARANTEE6_0    ];;
let phys_sys___GUARANTEE8_0 = 
  SUM [
    fault__independently__active__shutoff_valve__shutoff_valve__fault_2;
    fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1    ];;
let phys_sys___GUARANTEE8 = 
  SUM [
    phys_sys___GUARANTEE8_0    ];;
let wBS_inst___GUARANTEE17_0 = 
  SUM [
    phys_sys___GUARANTEE13    ];;
let ctrl_sys___GUARANTEE0_0 = 
  SUM [
    bscu___GUARANTEE0    ];;
let wBS_inst___GUARANTEE21_0 = 
  SUM [
    phys_sys___GUARANTEE0    ];;
let ctrl_sys___GUARANTEE1_0 = 
  SUM [
    bscu___GUARANTEE1    ];;
let wBS_inst___GUARANTEE16_0 = 
  SUM [
    phys_sys___GUARANTEE12    ];;
let wBS_inst___GUARANTEE28_0 = 
  SUM [
    phys_sys___GUARANTEE7    ];;
let wBS_inst___GUARANTEE20_0 = 
  SUM [
    phys_sys___GUARANTEE16    ];;
let wBS_inst___GUARANTEE16 = 
  SUM [
    wBS_inst___GUARANTEE16_0    ];;
let wBS_inst___GUARANTEE15 = 
  SUM [
    wBS_inst___GUARANTEE15_0    ];;
let wBS_inst___GUARANTEE14 = 
  SUM [
    wBS_inst___GUARANTEE14_0    ];;
let wBS_inst___GUARANTEE13 = 
  SUM [
    wBS_inst___GUARANTEE13_0    ];;
let wBS_inst___GUARANTEE19_0 = 
  SUM [
    phys_sys___GUARANTEE15    ];;
let wBS_inst___GUARANTEE19 = 
  SUM [
    wBS_inst___GUARANTEE19_0    ];;
let wBS_inst___GUARANTEE18_0 = 
  SUM [
    phys_sys___GUARANTEE14    ];;
let wBS_inst___GUARANTEE18 = 
  SUM [
    wBS_inst___GUARANTEE18_0    ];;
let wBS_inst___GUARANTEE17 = 
  SUM [
    wBS_inst___GUARANTEE17_0    ];;
let wBS_inst___GUARANTEE12 = 
  SUM [
    wBS_inst___GUARANTEE12_0    ];;
let wBS_inst___GUARANTEE11_0 = 
  SUM [
    ctrl_sys___GUARANTEE12;
    phys_sys___GUARANTEE15;
    fault__independently__active__wheel_sensor7__wheel_sensor7__fault_2    ];;
let wBS_inst___GUARANTEE11 = 
  SUM [
    wBS_inst___GUARANTEE11_0    ];;
let wBS_inst___GUARANTEE10_0 = 
  SUM [
    ctrl_sys___GUARANTEE11;
    fault__independently__active__wheel_sensor6__wheel_sensor6__fault_2;
    phys_sys___GUARANTEE14    ];;
let wBS_inst___GUARANTEE10 = 
  SUM [
    wBS_inst___GUARANTEE10_0    ];;
let wBS_inst___GUARANTEE27 = 
  SUM [
    wBS_inst___GUARANTEE27_0    ];;
let wBS_inst___GUARANTEE26 = 
  SUM [
    wBS_inst___GUARANTEE26_0    ];;
let wBS_inst___GUARANTEE25 = 
  SUM [
    wBS_inst___GUARANTEE25_0    ];;
let wBS_inst___GUARANTEE24 = 
  SUM [
    wBS_inst___GUARANTEE24_0    ];;
let ctrl_sys___GUARANTEE5 = 
  SUM [
    ctrl_sys___GUARANTEE5_0    ];;
let ctrl_sys___GUARANTEE4 = 
  SUM [
    ctrl_sys___GUARANTEE4_0    ];;
let ctrl_sys___GUARANTEE3 = 
  SUM [
    ctrl_sys___GUARANTEE3_0    ];;
let wBS_inst___GUARANTEE28 = 
  SUM [
    wBS_inst___GUARANTEE28_0    ];;
let ctrl_sys___GUARANTEE2 = 
  SUM [
    ctrl_sys___GUARANTEE2_0    ];;
let wBS_inst___GUARANTEE23_0 = 
  SUM [
    phys_sys___GUARANTEE2    ];;
let wBS_inst___GUARANTEE23 = 
  SUM [
    wBS_inst___GUARANTEE23_0    ];;
let wBS_inst___GUARANTEE22_0 = 
  SUM [
    phys_sys___GUARANTEE1    ];;
let wBS_inst___GUARANTEE22 = 
  SUM [
    wBS_inst___GUARANTEE22_0    ];;
let wBS_inst___GUARANTEE21 = 
  SUM [
    wBS_inst___GUARANTEE21_0    ];;
let wBS_inst___GUARANTEE20 = 
  SUM [
    wBS_inst___GUARANTEE20_0    ];;
let ctrl_sys___GUARANTEE1 = 
  SUM [
    ctrl_sys___GUARANTEE1_0    ];;
let ctrl_sys___GUARANTEE0 = 
  SUM [
    ctrl_sys___GUARANTEE0_0    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE16;;
probErrorCut wBS_inst___GUARANTEE16;;
probErrorCutImp wBS_inst___GUARANTEE16;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE16_direct_ftree.gv" wBS_inst___GUARANTEE16 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE16_optimized_ftree.gv" wBS_inst___GUARANTEE16 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE15;;
probErrorCut wBS_inst___GUARANTEE15;;
probErrorCutImp wBS_inst___GUARANTEE15;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE15_direct_ftree.gv" wBS_inst___GUARANTEE15 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE15_optimized_ftree.gv" wBS_inst___GUARANTEE15 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE14;;
probErrorCut wBS_inst___GUARANTEE14;;
probErrorCutImp wBS_inst___GUARANTEE14;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE14_direct_ftree.gv" wBS_inst___GUARANTEE14 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE14_optimized_ftree.gv" wBS_inst___GUARANTEE14 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE13;;
probErrorCut wBS_inst___GUARANTEE13;;
probErrorCutImp wBS_inst___GUARANTEE13;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE13_direct_ftree.gv" wBS_inst___GUARANTEE13 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE13_optimized_ftree.gv" wBS_inst___GUARANTEE13 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE19;;
probErrorCut wBS_inst___GUARANTEE19;;
probErrorCutImp wBS_inst___GUARANTEE19;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE19_direct_ftree.gv" wBS_inst___GUARANTEE19 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE19_optimized_ftree.gv" wBS_inst___GUARANTEE19 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE18;;
probErrorCut wBS_inst___GUARANTEE18;;
probErrorCutImp wBS_inst___GUARANTEE18;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE18_direct_ftree.gv" wBS_inst___GUARANTEE18 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE18_optimized_ftree.gv" wBS_inst___GUARANTEE18 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE17;;
probErrorCut wBS_inst___GUARANTEE17;;
probErrorCutImp wBS_inst___GUARANTEE17;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE17_direct_ftree.gv" wBS_inst___GUARANTEE17 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE17_optimized_ftree.gv" wBS_inst___GUARANTEE17 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE12;;
probErrorCut wBS_inst___GUARANTEE12;;
probErrorCutImp wBS_inst___GUARANTEE12;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE12_direct_ftree.gv" wBS_inst___GUARANTEE12 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE12_optimized_ftree.gv" wBS_inst___GUARANTEE12 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE11;;
probErrorCut wBS_inst___GUARANTEE11;;
probErrorCutImp wBS_inst___GUARANTEE11;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE11_direct_ftree.gv" wBS_inst___GUARANTEE11 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE11_optimized_ftree.gv" wBS_inst___GUARANTEE11 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE10;;
probErrorCut wBS_inst___GUARANTEE10;;
probErrorCutImp wBS_inst___GUARANTEE10;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE10_direct_ftree.gv" wBS_inst___GUARANTEE10 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE10_optimized_ftree.gv" wBS_inst___GUARANTEE10 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE27;;
probErrorCut wBS_inst___GUARANTEE27;;
probErrorCutImp wBS_inst___GUARANTEE27;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE27_direct_ftree.gv" wBS_inst___GUARANTEE27 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE27_optimized_ftree.gv" wBS_inst___GUARANTEE27 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE26;;
probErrorCut wBS_inst___GUARANTEE26;;
probErrorCutImp wBS_inst___GUARANTEE26;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE26_direct_ftree.gv" wBS_inst___GUARANTEE26 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE26_optimized_ftree.gv" wBS_inst___GUARANTEE26 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE25;;
probErrorCut wBS_inst___GUARANTEE25;;
probErrorCutImp wBS_inst___GUARANTEE25;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE25_direct_ftree.gv" wBS_inst___GUARANTEE25 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE25_optimized_ftree.gv" wBS_inst___GUARANTEE25 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE24;;
probErrorCut wBS_inst___GUARANTEE24;;
probErrorCutImp wBS_inst___GUARANTEE24;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE24_direct_ftree.gv" wBS_inst___GUARANTEE24 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE24_optimized_ftree.gv" wBS_inst___GUARANTEE24 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE28;;
probErrorCut wBS_inst___GUARANTEE28;;
probErrorCutImp wBS_inst___GUARANTEE28;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE28_direct_ftree.gv" wBS_inst___GUARANTEE28 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE28_optimized_ftree.gv" wBS_inst___GUARANTEE28 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE5;;
probErrorCut wBS_inst___GUARANTEE5;;
probErrorCutImp wBS_inst___GUARANTEE5;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE5_direct_ftree.gv" wBS_inst___GUARANTEE5 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE5_optimized_ftree.gv" wBS_inst___GUARANTEE5 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE4;;
probErrorCut wBS_inst___GUARANTEE4;;
probErrorCutImp wBS_inst___GUARANTEE4;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE4_direct_ftree.gv" wBS_inst___GUARANTEE4 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE4_optimized_ftree.gv" wBS_inst___GUARANTEE4 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE3;;
probErrorCut wBS_inst___GUARANTEE3;;
probErrorCutImp wBS_inst___GUARANTEE3;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE3_direct_ftree.gv" wBS_inst___GUARANTEE3 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE3_optimized_ftree.gv" wBS_inst___GUARANTEE3 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE2;;
probErrorCut wBS_inst___GUARANTEE2;;
probErrorCutImp wBS_inst___GUARANTEE2;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE2_direct_ftree.gv" wBS_inst___GUARANTEE2 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE2_optimized_ftree.gv" wBS_inst___GUARANTEE2 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE1;;
probErrorCut wBS_inst___GUARANTEE1;;
probErrorCutImp wBS_inst___GUARANTEE1;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE1_direct_ftree.gv" wBS_inst___GUARANTEE1 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE1_optimized_ftree.gv" wBS_inst___GUARANTEE1 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE23;;
probErrorCut wBS_inst___GUARANTEE23;;
probErrorCutImp wBS_inst___GUARANTEE23;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE23_direct_ftree.gv" wBS_inst___GUARANTEE23 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE23_optimized_ftree.gv" wBS_inst___GUARANTEE23 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE0;;
probErrorCut wBS_inst___GUARANTEE0;;
probErrorCutImp wBS_inst___GUARANTEE0;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE0_direct_ftree.gv" wBS_inst___GUARANTEE0 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE0_optimized_ftree.gv" wBS_inst___GUARANTEE0 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE22;;
probErrorCut wBS_inst___GUARANTEE22;;
probErrorCutImp wBS_inst___GUARANTEE22;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE22_direct_ftree.gv" wBS_inst___GUARANTEE22 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE22_optimized_ftree.gv" wBS_inst___GUARANTEE22 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE21;;
probErrorCut wBS_inst___GUARANTEE21;;
probErrorCutImp wBS_inst___GUARANTEE21;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE21_direct_ftree.gv" wBS_inst___GUARANTEE21 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE21_optimized_ftree.gv" wBS_inst___GUARANTEE21 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE20;;
probErrorCut wBS_inst___GUARANTEE20;;
probErrorCutImp wBS_inst___GUARANTEE20;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE20_direct_ftree.gv" wBS_inst___GUARANTEE20 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE20_optimized_ftree.gv" wBS_inst___GUARANTEE20 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE9;;
probErrorCut wBS_inst___GUARANTEE9;;
probErrorCutImp wBS_inst___GUARANTEE9;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE9_direct_ftree.gv" wBS_inst___GUARANTEE9 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE9_optimized_ftree.gv" wBS_inst___GUARANTEE9 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE8;;
probErrorCut wBS_inst___GUARANTEE8;;
probErrorCutImp wBS_inst___GUARANTEE8;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE8_direct_ftree.gv" wBS_inst___GUARANTEE8 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE8_optimized_ftree.gv" wBS_inst___GUARANTEE8 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE7;;
probErrorCut wBS_inst___GUARANTEE7;;
probErrorCutImp wBS_inst___GUARANTEE7;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE7_direct_ftree.gv" wBS_inst___GUARANTEE7 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE7_optimized_ftree.gv" wBS_inst___GUARANTEE7 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE6;;
probErrorCut wBS_inst___GUARANTEE6;;
probErrorCutImp wBS_inst___GUARANTEE6;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE6_direct_ftree.gv" wBS_inst___GUARANTEE6 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE6_optimized_ftree.gv" wBS_inst___GUARANTEE6 ;;

