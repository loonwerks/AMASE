#use "top.ml";;
let fault__independently__active__mv3__mv3__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv3__mv3__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__mv8__mv8__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv8__mv8__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__mv2__mv2__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv2__mv2__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__mv1__mv1__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv1__mv1__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2 = 
  Leaf
    (("wheel_brake1","fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2"),3.3E-5, 1.0);;
let fault__independently__active__brake_actuator__brake_actuator__fault_2 = 
  Leaf
    (("wheel_brake1","fault__independently__active__brake_actuator__brake_actuator__fault_2"),3.3E-6, 1.0);;
let fault__independently__active__mv7__mv7__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv7__mv7__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
  Leaf
    (("wheel_brake1","fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
  Leaf
    (("wheel_brake1","fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let fault__independently__active__mv6__mv6__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv6__mv6__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2 = 
  Leaf
    (("wheel_brake1","fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2"),3.3E-5, 1.0);;
let fault__independently__active__accumulator__accumulator__fault_2 = 
  Leaf
    (("PhysicalSystem_inst","fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let fault__independently__active__shutoff_valve__shutoff_valve__fault_2 = 
  Leaf
    (("PhysicalSystem_inst","fault__independently__active__shutoff_valve__shutoff_valve__fault_2"),5.0E-6, 1.0);;
let fault__independently__active__mv5__mv5__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv5__mv5__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__selector_valve__selector_valve__fault_2 = 
  Leaf
    (("PhysicalSystem_inst","fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1 = 
  Leaf
    (("PhysicalSystem_inst","fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1"),3.0E-5, 1.0);;
let fault__independently__active__mv4__mv4__fault_4 = 
  Leaf
    (("normal_sys","fault__independently__active__mv4__mv4__fault_4"),3.25E-6, 1.0);;
let fault__independently__active__selector_valve__selector_valve__fault_1 = 
  Leaf
    (("PhysicalSystem_inst","fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let wheel_brake7___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake7___GUARANTEE0 = 
  SUM [
    wheel_brake7___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE6_0 = 
  SUM [
    fault__independently__active__mv7__mv7__fault_4    ];;
let normal_sys___GUARANTEE6 = 
  SUM [
    normal_sys___GUARANTEE6_0    ];;
let alt_sys___GUARANTEE2_0 = 
  SUM [
    fault__independently__active__mv3__mv3__fault_4    ];;
let alt_sys___GUARANTEE2 = 
  SUM [
    alt_sys___GUARANTEE2_0    ];;
let physicalSystem_inst___GUARANTEE6_0 = 
  SUM [
    wheel_brake7___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE6;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let wheel_brake5___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake5___GUARANTEE0 = 
  SUM [
    wheel_brake5___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE4_0 = 
  SUM [
    fault__independently__active__mv5__mv5__fault_4    ];;
let normal_sys___GUARANTEE4 = 
  SUM [
    normal_sys___GUARANTEE4_0    ];;
let alt_sys___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__mv1__mv1__fault_4    ];;
let alt_sys___GUARANTEE0 = 
  SUM [
    alt_sys___GUARANTEE0_0    ];;
let physicalSystem_inst___GUARANTEE4_0 = 
  SUM [
    wheel_brake5___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE4;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0    ];;
let wheel_brake3___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake3___GUARANTEE0 = 
  SUM [
    wheel_brake3___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE2_0 = 
  SUM [
    fault__independently__active__mv3__mv3__fault_4    ];;
let normal_sys___GUARANTEE2 = 
  SUM [
    normal_sys___GUARANTEE2_0    ];;
let physicalSystem_inst___GUARANTEE2_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake3___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let normal_sys___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__mv1__mv1__fault_4    ];;
let normal_sys___GUARANTEE0 = 
  SUM [
    normal_sys___GUARANTEE0_0    ];;
let wheel_brake1___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake1___GUARANTEE0 = 
  SUM [
    wheel_brake1___GUARANTEE0_0    ];;
let physicalSystem_inst___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0;
    normal_sys___GUARANTEE0;
    wheel_brake1___GUARANTEE0    ];;
let wheel_brake2___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake2___GUARANTEE0 = 
  SUM [
    wheel_brake2___GUARANTEE0_0    ];;
let alt_sys___GUARANTEE1_0 = 
  SUM [
    fault__independently__active__mv2__mv2__fault_4    ];;
let alt_sys___GUARANTEE1 = 
  SUM [
    alt_sys___GUARANTEE1_0    ];;
let normal_sys___GUARANTEE1_0 = 
  SUM [
    fault__independently__active__mv2__mv2__fault_4    ];;
let normal_sys___GUARANTEE1 = 
  SUM [
    normal_sys___GUARANTEE1_0    ];;
let physicalSystem_inst___GUARANTEE10_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    wheel_brake2___GUARANTEE0;
    alt_sys___GUARANTEE1;
    normal_sys___GUARANTEE1    ];;
let wheel_brake4___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake4___GUARANTEE0 = 
  SUM [
    wheel_brake4___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE3_0 = 
  SUM [
    fault__independently__active__mv4__mv4__fault_4    ];;
let normal_sys___GUARANTEE3 = 
  SUM [
    normal_sys___GUARANTEE3_0    ];;
let alt_sys___GUARANTEE3_0 = 
  SUM [
    fault__independently__active__mv4__mv4__fault_4    ];;
let alt_sys___GUARANTEE3 = 
  SUM [
    alt_sys___GUARANTEE3_0    ];;
let physicalSystem_inst___GUARANTEE12_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake4___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE3;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let wheel_brake6___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake6___GUARANTEE0 = 
  SUM [
    wheel_brake6___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE5_0 = 
  SUM [
    fault__independently__active__mv6__mv6__fault_4    ];;
let normal_sys___GUARANTEE5 = 
  SUM [
    normal_sys___GUARANTEE5_0    ];;
let physicalSystem_inst___GUARANTEE14_0 = 
  SUM [
    wheel_brake6___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    normal_sys___GUARANTEE5;
    alt_sys___GUARANTEE1    ];;
let wheel_brake8___GUARANTEE0_0 = 
  SUM [
    fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
    fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
    fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_2;
    fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_2;
    fault__independently__active__brake_actuator__brake_actuator__fault_2    ];;
let wheel_brake8___GUARANTEE0 = 
  SUM [
    wheel_brake8___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE7_0 = 
  SUM [
    fault__independently__active__mv8__mv8__fault_4    ];;
let normal_sys___GUARANTEE7 = 
  SUM [
    normal_sys___GUARANTEE7_0    ];;
let physicalSystem_inst___GUARANTEE16_0 = 
  SUM [
    wheel_brake8___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE7;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let physicalSystem_inst___GUARANTEE18_1 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0;
    normal_sys___GUARANTEE0;
    wheel_brake1___GUARANTEE0    ];;
let physicalSystem_inst___GUARANTEE18_0 = 
  SUM [
    wheel_brake5___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE4;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0    ];;
let physicalSystem_inst___GUARANTEE18_3 = 
  SUM [
    wheel_brake6___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    normal_sys___GUARANTEE5;
    alt_sys___GUARANTEE1    ];;
let physicalSystem_inst___GUARANTEE18_2 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    wheel_brake2___GUARANTEE0;
    alt_sys___GUARANTEE1;
    normal_sys___GUARANTEE1    ];;
let physicalSystem_inst___GUARANTEE18_5 = 
  SUM [
    wheel_brake8___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE7;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let physicalSystem_inst___GUARANTEE18_4 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake3___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let physicalSystem_inst___GUARANTEE18_7 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake4___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE3;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let physicalSystem_inst___GUARANTEE18_6 = 
  SUM [
    wheel_brake7___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE6;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let physicalSystem_inst___GUARANTEE8_0 = 
  SUM [
    fault__independently__active__shutoff_valve__shutoff_valve__fault_2;
    fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1    ];;
let physicalSystem_inst___GUARANTEE5_0 = 
  SUM [
    wheel_brake6___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    normal_sys___GUARANTEE5;
    alt_sys___GUARANTEE1    ];;
let physicalSystem_inst___GUARANTEE3_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake4___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE3;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let physicalSystem_inst___GUARANTEE1_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    wheel_brake2___GUARANTEE0;
    alt_sys___GUARANTEE1;
    normal_sys___GUARANTEE1    ];;
let physicalSystem_inst___GUARANTEE11_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake3___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let physicalSystem_inst___GUARANTEE13_0 = 
  SUM [
    wheel_brake5___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE4;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0    ];;
let physicalSystem_inst___GUARANTEE15_0 = 
  SUM [
    wheel_brake7___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE6;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let physicalSystem_inst___GUARANTEE17_0 = 
  SUM [
    wheel_brake5___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE4;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0    ];;
let physicalSystem_inst___GUARANTEE5 = 
  SUM [
    physicalSystem_inst___GUARANTEE5_0    ];;
let physicalSystem_inst___GUARANTEE4 = 
  SUM [
    physicalSystem_inst___GUARANTEE4_0    ];;
let physicalSystem_inst___GUARANTEE7_0 = 
  SUM [
    wheel_brake8___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE7;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let physicalSystem_inst___GUARANTEE7 = 
  SUM [
    physicalSystem_inst___GUARANTEE7_0    ];;
let physicalSystem_inst___GUARANTEE6 = 
  SUM [
    physicalSystem_inst___GUARANTEE6_0    ];;
let physicalSystem_inst___GUARANTEE1 = 
  SUM [
    physicalSystem_inst___GUARANTEE1_0    ];;
let physicalSystem_inst___GUARANTEE0 = 
  SUM [
    physicalSystem_inst___GUARANTEE0_0    ];;
let physicalSystem_inst___GUARANTEE3 = 
  SUM [
    physicalSystem_inst___GUARANTEE3_0    ];;
let physicalSystem_inst___GUARANTEE2 = 
  SUM [
    physicalSystem_inst___GUARANTEE2_0    ];;
let physicalSystem_inst___GUARANTEE17_2 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    wheel_brake2___GUARANTEE0;
    alt_sys___GUARANTEE1;
    normal_sys___GUARANTEE1    ];;
let physicalSystem_inst___GUARANTEE17_1 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0;
    normal_sys___GUARANTEE0;
    wheel_brake1___GUARANTEE0    ];;
let physicalSystem_inst___GUARANTEE17_4 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake3___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let physicalSystem_inst___GUARANTEE17_3 = 
  SUM [
    wheel_brake6___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    normal_sys___GUARANTEE5;
    alt_sys___GUARANTEE1    ];;
let physicalSystem_inst___GUARANTEE17_6 = 
  SUM [
    wheel_brake7___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE6;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE2    ];;
let physicalSystem_inst___GUARANTEE17_5 = 
  SUM [
    wheel_brake8___GUARANTEE0;
    fault__independently__active__accumulator__accumulator__fault_2;
    normal_sys___GUARANTEE7;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let physicalSystem_inst___GUARANTEE17_7 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    wheel_brake4___GUARANTEE0;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    normal_sys___GUARANTEE3;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE3    ];;
let physicalSystem_inst___GUARANTEE10 = 
  SUM [
    physicalSystem_inst___GUARANTEE10_0    ];;
let physicalSystem_inst___GUARANTEE16 = 
  SUM [
    physicalSystem_inst___GUARANTEE16_0    ];;
let physicalSystem_inst___GUARANTEE15 = 
  SUM [
    physicalSystem_inst___GUARANTEE15_0    ];;
let physicalSystem_inst___GUARANTEE18 = 
  PRO [
    physicalSystem_inst___GUARANTEE18_1;
    physicalSystem_inst___GUARANTEE18_0;
    physicalSystem_inst___GUARANTEE18_3;
    physicalSystem_inst___GUARANTEE18_2;
    physicalSystem_inst___GUARANTEE18_5;
    physicalSystem_inst___GUARANTEE18_4;
    physicalSystem_inst___GUARANTEE18_7;
    physicalSystem_inst___GUARANTEE18_6    ];;
let physicalSystem_inst___GUARANTEE17 = 
  PRO [
    physicalSystem_inst___GUARANTEE17_0;
    physicalSystem_inst___GUARANTEE17_2;
    physicalSystem_inst___GUARANTEE17_1;
    physicalSystem_inst___GUARANTEE17_4;
    physicalSystem_inst___GUARANTEE17_3;
    physicalSystem_inst___GUARANTEE17_6;
    physicalSystem_inst___GUARANTEE17_5;
    physicalSystem_inst___GUARANTEE17_7    ];;
let physicalSystem_inst___GUARANTEE9_0 = 
  SUM [
    fault__independently__active__accumulator__accumulator__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_2;
    fault__independently__active__selector_valve__selector_valve__fault_1;
    alt_sys___GUARANTEE0;
    normal_sys___GUARANTEE0;
    wheel_brake1___GUARANTEE0    ];;
let physicalSystem_inst___GUARANTEE9 = 
  SUM [
    physicalSystem_inst___GUARANTEE9_0    ];;
let physicalSystem_inst___GUARANTEE12 = 
  SUM [
    physicalSystem_inst___GUARANTEE12_0    ];;
let physicalSystem_inst___GUARANTEE8 = 
  SUM [
    physicalSystem_inst___GUARANTEE8_0    ];;
let physicalSystem_inst___GUARANTEE11 = 
  SUM [
    physicalSystem_inst___GUARANTEE11_0    ];;
let physicalSystem_inst___GUARANTEE14 = 
  SUM [
    physicalSystem_inst___GUARANTEE14_0    ];;
let physicalSystem_inst___GUARANTEE13 = 
  SUM [
    physicalSystem_inst___GUARANTEE13_0    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE5;;
probErrorCut physicalSystem_inst___GUARANTEE5;;
probErrorCutImp physicalSystem_inst___GUARANTEE5;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE5_direct_ftree.gv" physicalSystem_inst___GUARANTEE5 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE5_optimized_ftree.gv" physicalSystem_inst___GUARANTEE5 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE4;;
probErrorCut physicalSystem_inst___GUARANTEE4;;
probErrorCutImp physicalSystem_inst___GUARANTEE4;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE4_direct_ftree.gv" physicalSystem_inst___GUARANTEE4 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE4_optimized_ftree.gv" physicalSystem_inst___GUARANTEE4 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE7;;
probErrorCut physicalSystem_inst___GUARANTEE7;;
probErrorCutImp physicalSystem_inst___GUARANTEE7;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE7_direct_ftree.gv" physicalSystem_inst___GUARANTEE7 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE7_optimized_ftree.gv" physicalSystem_inst___GUARANTEE7 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE6;;
probErrorCut physicalSystem_inst___GUARANTEE6;;
probErrorCutImp physicalSystem_inst___GUARANTEE6;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE6_direct_ftree.gv" physicalSystem_inst___GUARANTEE6 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE6_optimized_ftree.gv" physicalSystem_inst___GUARANTEE6 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE1;;
probErrorCut physicalSystem_inst___GUARANTEE1;;
probErrorCutImp physicalSystem_inst___GUARANTEE1;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE1_direct_ftree.gv" physicalSystem_inst___GUARANTEE1 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE1_optimized_ftree.gv" physicalSystem_inst___GUARANTEE1 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE0;;
probErrorCut physicalSystem_inst___GUARANTEE0;;
probErrorCutImp physicalSystem_inst___GUARANTEE0;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE0_direct_ftree.gv" physicalSystem_inst___GUARANTEE0 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE0_optimized_ftree.gv" physicalSystem_inst___GUARANTEE0 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE3;;
probErrorCut physicalSystem_inst___GUARANTEE3;;
probErrorCutImp physicalSystem_inst___GUARANTEE3;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE3_direct_ftree.gv" physicalSystem_inst___GUARANTEE3 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE3_optimized_ftree.gv" physicalSystem_inst___GUARANTEE3 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE2;;
probErrorCut physicalSystem_inst___GUARANTEE2;;
probErrorCutImp physicalSystem_inst___GUARANTEE2;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE2_direct_ftree.gv" physicalSystem_inst___GUARANTEE2 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE2_optimized_ftree.gv" physicalSystem_inst___GUARANTEE2 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE10;;
probErrorCut physicalSystem_inst___GUARANTEE10;;
probErrorCutImp physicalSystem_inst___GUARANTEE10;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE10_direct_ftree.gv" physicalSystem_inst___GUARANTEE10 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE10_optimized_ftree.gv" physicalSystem_inst___GUARANTEE10 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE16;;
probErrorCut physicalSystem_inst___GUARANTEE16;;
probErrorCutImp physicalSystem_inst___GUARANTEE16;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE16_direct_ftree.gv" physicalSystem_inst___GUARANTEE16 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE16_optimized_ftree.gv" physicalSystem_inst___GUARANTEE16 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE15;;
probErrorCut physicalSystem_inst___GUARANTEE15;;
probErrorCutImp physicalSystem_inst___GUARANTEE15;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE15_direct_ftree.gv" physicalSystem_inst___GUARANTEE15 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE15_optimized_ftree.gv" physicalSystem_inst___GUARANTEE15 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE18;;
probErrorCut physicalSystem_inst___GUARANTEE18;;
probErrorCutImp physicalSystem_inst___GUARANTEE18;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE18_direct_ftree.gv" physicalSystem_inst___GUARANTEE18 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE18_optimized_ftree.gv" physicalSystem_inst___GUARANTEE18 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE17;;
probErrorCut physicalSystem_inst___GUARANTEE17;;
probErrorCutImp physicalSystem_inst___GUARANTEE17;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE17_direct_ftree.gv" physicalSystem_inst___GUARANTEE17 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE17_optimized_ftree.gv" physicalSystem_inst___GUARANTEE17 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE9;;
probErrorCut physicalSystem_inst___GUARANTEE9;;
probErrorCutImp physicalSystem_inst___GUARANTEE9;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE9_direct_ftree.gv" physicalSystem_inst___GUARANTEE9 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE9_optimized_ftree.gv" physicalSystem_inst___GUARANTEE9 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE12;;
probErrorCut physicalSystem_inst___GUARANTEE12;;
probErrorCutImp physicalSystem_inst___GUARANTEE12;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE12_direct_ftree.gv" physicalSystem_inst___GUARANTEE12 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE12_optimized_ftree.gv" physicalSystem_inst___GUARANTEE12 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE8;;
probErrorCut physicalSystem_inst___GUARANTEE8;;
probErrorCutImp physicalSystem_inst___GUARANTEE8;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE8_direct_ftree.gv" physicalSystem_inst___GUARANTEE8 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE8_optimized_ftree.gv" physicalSystem_inst___GUARANTEE8 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE11;;
probErrorCut physicalSystem_inst___GUARANTEE11;;
probErrorCutImp physicalSystem_inst___GUARANTEE11;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE11_direct_ftree.gv" physicalSystem_inst___GUARANTEE11 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE11_optimized_ftree.gv" physicalSystem_inst___GUARANTEE11 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE14;;
probErrorCut physicalSystem_inst___GUARANTEE14;;
probErrorCutImp physicalSystem_inst___GUARANTEE14;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE14_direct_ftree.gv" physicalSystem_inst___GUARANTEE14 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE14_optimized_ftree.gv" physicalSystem_inst___GUARANTEE14 ;;

(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets physicalSystem_inst___GUARANTEE13;;
probErrorCut physicalSystem_inst___GUARANTEE13;;
probErrorCutImp physicalSystem_inst___GUARANTEE13;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE13_direct_ftree.gv" physicalSystem_inst___GUARANTEE13 ;;
dot_gen_show_tree_file ~rend:"pdf" "physicalSystem_inst___GUARANTEE13_optimized_ftree.gv" physicalSystem_inst___GUARANTEE13 ;;

