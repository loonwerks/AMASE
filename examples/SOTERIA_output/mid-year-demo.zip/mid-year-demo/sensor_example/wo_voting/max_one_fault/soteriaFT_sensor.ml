#use "top.ml";;
let reactor_Pressure_Ctrl_fault__independently__active__Pressure_Sensor2__Pressure_Sensor2__fault_1 = 
Leaf
    (("Reactor_Pressure_Ctrl","reactor_Pressure_Ctrl_fault__independently__active__Pressure_Sensor2__Pressure_Sensor2__fault_1"),1.0E-6, 1.0);;
let reactor_Radiation_Ctrl_fault__independently__active__Radiation_Sensor3__Radiation_Sensor3__fault_2 = 
Leaf
    (("Reactor_Radiation_Ctrl","reactor_Radiation_Ctrl_fault__independently__active__Radiation_Sensor3__Radiation_Sensor3__fault_2"),1.0E-6, 1.0);;
let reactor_Pressure_Ctrl_fault__independently__active__Pressure_Sensor1__Pressure_Sensor1__fault_1 = 
Leaf
    (("Reactor_Pressure_Ctrl","reactor_Pressure_Ctrl_fault__independently__active__Pressure_Sensor1__Pressure_Sensor1__fault_1"),1.0E-6, 1.0);;
let reactor_Pressure_Ctrl_fault__independently__active__Pressure_Sensor3__Pressure_Sensor3__fault_1 = 
Leaf
    (("Reactor_Pressure_Ctrl","reactor_Pressure_Ctrl_fault__independently__active__Pressure_Sensor3__Pressure_Sensor3__fault_1"),1.0E-6, 1.0);;
let reactor_Radiation_Ctrl_fault__independently__active__Radiation_Sensor2__Radiation_Sensor2__fault_2 = 
Leaf
    (("Reactor_Radiation_Ctrl","reactor_Radiation_Ctrl_fault__independently__active__Radiation_Sensor2__Radiation_Sensor2__fault_2"),1.0E-6, 1.0);;
let reactor_Temp_Ctrl_fault__independently__active__Temp_Sensor3__Temp_Sensor3__fault_1 = 
Leaf
    (("Reactor_Temp_Ctrl","reactor_Temp_Ctrl_fault__independently__active__Temp_Sensor3__Temp_Sensor3__fault_1"),1.0E-5, 1.0);;
let reactor_Temp_Ctrl_fault__independently__active__Temp_Sensor2__Temp_Sensor2__fault_1 = 
Leaf
    (("Reactor_Temp_Ctrl","reactor_Temp_Ctrl_fault__independently__active__Temp_Sensor2__Temp_Sensor2__fault_1"),1.0E-5, 1.0);;
let reactor_Temp_Ctrl_fault__independently__active__Temp_Sensor1__Temp_Sensor1__fault_1 = 
Leaf
    (("Reactor_Temp_Ctrl","reactor_Temp_Ctrl_fault__independently__active__Temp_Sensor1__Temp_Sensor1__fault_1"),1.0E-5, 1.0);;
let reactor_Radiation_Ctrl_fault__independently__active__Radiation_Sensor1__Radiation_Sensor1__fault_2 = 
Leaf
    (("Reactor_Radiation_Ctrl","reactor_Radiation_Ctrl_fault__independently__active__Radiation_Sensor1__Radiation_Sensor1__fault_2"),1.0E-6, 1.0);;
let reactor_Pressure_Ctrl___GUARANTEE0_0 = 
PRO [
reactor_Pressure_Ctrl_fault__independently__active__Pressure_Sensor2__Pressure_Sensor2__fault_1;
reactor_Pressure_Ctrl_fault__independently__active__Pressure_Sensor1__Pressure_Sensor1__fault_1;
reactor_Pressure_Ctrl_fault__independently__active__Pressure_Sensor3__Pressure_Sensor3__fault_1    ];;
let reactor_Pressure_Ctrl___GUARANTEE0 = 
PRO [
reactor_Pressure_Ctrl___GUARANTEE0_0    ];;
let reactor_Ctrl_No_Voting___GUARANTEE0_2 = 
PRO [
reactor_Pressure_Ctrl___GUARANTEE0    ];;
let reactor_Temp_Ctrl___GUARANTEE0_0 = 
PRO [
reactor_Temp_Ctrl_fault__independently__active__Temp_Sensor2__Temp_Sensor2__fault_1    ];;
let reactor_Temp_Ctrl___GUARANTEE0_2 = 
PRO [
reactor_Temp_Ctrl_fault__independently__active__Temp_Sensor3__Temp_Sensor3__fault_1    ];;
let reactor_Temp_Ctrl___GUARANTEE0_1 = 
PRO [
reactor_Temp_Ctrl_fault__independently__active__Temp_Sensor1__Temp_Sensor1__fault_1    ];;
let reactor_Temp_Ctrl___GUARANTEE0 = 
SUM [
reactor_Temp_Ctrl___GUARANTEE0_0;
reactor_Temp_Ctrl___GUARANTEE0_2;
reactor_Temp_Ctrl___GUARANTEE0_1    ];;
let reactor_Ctrl_No_Voting___GUARANTEE0_0 = 
PRO [
reactor_Temp_Ctrl___GUARANTEE0    ];;
let reactor_Radiation_Ctrl___GUARANTEE0_2 = 
PRO [
reactor_Radiation_Ctrl_fault__independently__active__Radiation_Sensor2__Radiation_Sensor2__fault_2    ];;
let reactor_Radiation_Ctrl___GUARANTEE0_0 = 
PRO [
reactor_Radiation_Ctrl_fault__independently__active__Radiation_Sensor1__Radiation_Sensor1__fault_2    ];;
let reactor_Radiation_Ctrl___GUARANTEE0_1 = 
PRO [
reactor_Radiation_Ctrl_fault__independently__active__Radiation_Sensor3__Radiation_Sensor3__fault_2    ];;
let reactor_Radiation_Ctrl___GUARANTEE0 = 
SUM [
reactor_Radiation_Ctrl___GUARANTEE0_2;
reactor_Radiation_Ctrl___GUARANTEE0_0;
reactor_Radiation_Ctrl___GUARANTEE0_1    ];;
let reactor_Ctrl_No_Voting___GUARANTEE0_1 = 
PRO [
reactor_Radiation_Ctrl___GUARANTEE0    ];;
let reactor_Ctrl_No_Voting___GUARANTEE0 = 
SUM [
reactor_Ctrl_No_Voting___GUARANTEE0_2;
reactor_Ctrl_No_Voting___GUARANTEE0_0;
reactor_Ctrl_No_Voting___GUARANTEE0_1    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets reactor_Ctrl_No_Voting___GUARANTEE0;;
probErrorCut reactor_Ctrl_No_Voting___GUARANTEE0;;
probErrorCutImp reactor_Ctrl_No_Voting___GUARANTEE0;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "reactor_Ctrl_No_Voting___GUARANTEE0_direct_ftree.gv" reactor_Ctrl_No_Voting___GUARANTEE0 ;;
dot_gen_show_tree_file ~rend:"pdf" "reactor_Ctrl_No_Voting___GUARANTEE0_optimized_ftree.gv" reactor_Ctrl_No_Voting___GUARANTEE0 ;;

