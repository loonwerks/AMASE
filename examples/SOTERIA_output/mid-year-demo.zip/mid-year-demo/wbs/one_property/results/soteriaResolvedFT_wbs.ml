#use "top.ml";;
let w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2"),1.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1"),0.01, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let alt_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let wBS_inst___GUARANTEE0 = 
SUM [
w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1;
wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2;
normal_sys_fault__independently__active__mv1__mv1__fault_2;
wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4;
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1;
wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1;
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1;
w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1;
alt_sys_fault__independently__active__mv1__mv1__fault_2    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE0;;
probErrorCut wBS_inst___GUARANTEE0;;
probErrorCutImp wBS_inst___GUARANTEE0;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE0_direct_ftree.gv" wBS_inst___GUARANTEE0 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE0_optimized_ftree.gv" wBS_inst___GUARANTEE0 ;;

