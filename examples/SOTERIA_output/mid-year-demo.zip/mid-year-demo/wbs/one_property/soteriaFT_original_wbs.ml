#use "top.ml";;
let wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_3_7__switch_gate_brake_as_cmd_pair_3_7__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_3_7__switch_gate_brake_as_cmd_pair_3_7__fault_2"),1.3E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv2__mv2__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv2__mv2__fault_2"),3.25E-6, 1.0);;
let wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2"),1.3E-5, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let normal_sys_fault__independently__active__mv4__mv4__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv4__mv4__fault_2"),3.25E-6, 1.0);;
let wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"),9.0E-6, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let alt_sys_fault__independently__active__mv2__mv2__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv2__mv2__fault_2"),3.25E-6, 1.0);;
let wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let normal_sys_fault__independently__active__mv5__mv5__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv5__mv5__fault_2"),3.25E-6, 1.0);;
let wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let alt_sys_fault__independently__active__mv3__mv3__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv3__mv3__fault_2"),3.25E-6, 1.0);;
let normal_sys_fault__independently__active__mv6__mv6__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv6__mv6__fault_2"),3.25E-6, 1.0);;
let wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv7__mv7__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv7__mv7__fault_2"),3.25E-6, 1.0);;
let wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let alt_sys_fault__independently__active__mv4__mv4__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv4__mv4__fault_2"),3.25E-6, 1.0);;
let normal_sys_fault__independently__active__mv8__mv8__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv8__mv8__fault_2"),3.25E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2"),1.3E-5, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2"),1.3E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let phys_sys_fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1"),3.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_2_6__switch_gate_brake_as_cmd_pair_2_6__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_2_6__switch_gate_brake_as_cmd_pair_2_6__fault_2"),1.3E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_4_8__switch_gate_brake_as_cmd_pair_4_8__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_4_8__switch_gate_brake_as_cmd_pair_4_8__fault_2"),1.3E-5, 1.0);;
let wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2"),1.3E-5, 1.0);;
let phys_sys_fault__independently__active__shutoff_valve__shutoff_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__shutoff_valve__shutoff_valve__fault_2"),5.0E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_1_5__switch_gate_brake_as_cmd_pair_1_5__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_1_5__switch_gate_brake_as_cmd_pair_1_5__fault_2"),1.3E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2"),1.3E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let normal_sys_fault__independently__active__mv3__mv3__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv3__mv3__fault_2"),3.25E-6, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1"),0.01, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let alt_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"),9.0E-6, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2"),1.3E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"),9.0E-6, 1.0);;
let wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1"),9.0E-6, 1.0);;
let wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2"),1.3E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2"),1.3E-5, 1.0);;
let wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake6___GUARANTEE0_4 = 
PRO [
wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4    ];;
let wheel_brake6___GUARANTEE0_3 = 
PRO [
wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4    ];;
let wheel_brake6___GUARANTEE0_2 = 
PRO [
wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1    ];;
let wheel_brake6___GUARANTEE0_1 = 
PRO [
wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1    ];;
let wheel_brake6___GUARANTEE0_0 = 
PRO [
wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4    ];;
let wheel_brake6___GUARANTEE0 = 
SUM [
wheel_brake6___GUARANTEE0_4;
wheel_brake6___GUARANTEE0_3;
wheel_brake6___GUARANTEE0_2;
wheel_brake6___GUARANTEE0_1;
wheel_brake6___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE7_0 = 
PRO [
normal_sys_fault__independently__active__mv8__mv8__fault_2    ];;
let normal_sys___GUARANTEE7 = 
PRO [
normal_sys___GUARANTEE7_0    ];;
let normal_sys___GUARANTEE3_0 = 
PRO [
normal_sys_fault__independently__active__mv4__mv4__fault_2    ];;
let normal_sys___GUARANTEE3 = 
PRO [
normal_sys___GUARANTEE3_0    ];;
let normal_sys___GUARANTEE4_0 = 
PRO [
normal_sys_fault__independently__active__mv5__mv5__fault_2    ];;
let normal_sys___GUARANTEE4 = 
PRO [
normal_sys___GUARANTEE4_0    ];;
let alt_sys___GUARANTEE2_0 = 
PRO [
alt_sys_fault__independently__active__mv3__mv3__fault_2    ];;
let alt_sys___GUARANTEE2 = 
PRO [
alt_sys___GUARANTEE2_0    ];;
let wheel_brake2___GUARANTEE0_3 = 
PRO [
wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4    ];;
let wheel_brake2___GUARANTEE0_4 = 
PRO [
wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4    ];;
let wheel_brake2___GUARANTEE0_0 = 
PRO [
wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4    ];;
let wheel_brake2___GUARANTEE0_1 = 
PRO [
wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1    ];;
let wheel_brake2___GUARANTEE0_2 = 
PRO [
wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1    ];;
let wheel_brake2___GUARANTEE0 = 
SUM [
wheel_brake2___GUARANTEE0_3;
wheel_brake2___GUARANTEE0_4;
wheel_brake2___GUARANTEE0_0;
wheel_brake2___GUARANTEE0_1;
wheel_brake2___GUARANTEE0_2    ];;
let normal_sys___GUARANTEE0_0 = 
PRO [
normal_sys_fault__independently__active__mv1__mv1__fault_2    ];;
let normal_sys___GUARANTEE0 = 
PRO [
normal_sys___GUARANTEE0_0    ];;
let phys_sys___GUARANTEE17_620 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let w3_w7_cmd_sys___GUARANTEE0_2 = 
PRO [
w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE0_1 = 
PRO [
w3_w7_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE0_0 = 
PRO [
w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE0 = 
SUM [
w3_w7_cmd_sys___GUARANTEE0_2;
w3_w7_cmd_sys___GUARANTEE0_1;
w3_w7_cmd_sys___GUARANTEE0_0    ];;
let command_sys___GUARANTEE2_0 = 
PRO [
w3_w7_cmd_sys___GUARANTEE0    ];;
let command_sys___GUARANTEE2 = 
PRO [
command_sys___GUARANTEE2_0    ];;
let channel2___GUARANTEE2_0 = 
PRO [
command_sys___GUARANTEE2    ];;
let channel2___GUARANTEE2 = 
PRO [
channel2___GUARANTEE2_0    ];;
let wheel_brake8___GUARANTEE0_4 = 
PRO [
wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4    ];;
let wheel_brake8___GUARANTEE0_3 = 
PRO [
wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4    ];;
let wheel_brake8___GUARANTEE0_2 = 
PRO [
wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1    ];;
let wheel_brake8___GUARANTEE0_1 = 
PRO [
wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1    ];;
let wheel_brake8___GUARANTEE0_0 = 
PRO [
wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4    ];;
let wheel_brake8___GUARANTEE0 = 
SUM [
wheel_brake8___GUARANTEE0_4;
wheel_brake8___GUARANTEE0_3;
wheel_brake8___GUARANTEE0_2;
wheel_brake8___GUARANTEE0_1;
wheel_brake8___GUARANTEE0_0    ];;
let wheel_brake3___GUARANTEE0_4 = 
PRO [
wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4    ];;
let wheel_brake3___GUARANTEE0_2 = 
PRO [
wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1    ];;
let wheel_brake3___GUARANTEE0_3 = 
PRO [
wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4    ];;
let wheel_brake3___GUARANTEE0_0 = 
PRO [
wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4    ];;
let wheel_brake3___GUARANTEE0_1 = 
PRO [
wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1    ];;
let wheel_brake3___GUARANTEE0 = 
SUM [
wheel_brake3___GUARANTEE0_4;
wheel_brake3___GUARANTEE0_2;
wheel_brake3___GUARANTEE0_3;
wheel_brake3___GUARANTEE0_0;
wheel_brake3___GUARANTEE0_1    ];;
let normal_sys___GUARANTEE6_0 = 
PRO [
normal_sys_fault__independently__active__mv7__mv7__fault_2    ];;
let normal_sys___GUARANTEE6 = 
PRO [
normal_sys___GUARANTEE6_0    ];;
let wheel_brake4___GUARANTEE0_0 = 
PRO [
wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4    ];;
let wheel_brake4___GUARANTEE0_4 = 
PRO [
wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4    ];;
let wheel_brake4___GUARANTEE0_3 = 
PRO [
wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4    ];;
let wheel_brake4___GUARANTEE0_2 = 
PRO [
wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1    ];;
let wheel_brake4___GUARANTEE0_1 = 
PRO [
wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1    ];;
let wheel_brake4___GUARANTEE0 = 
SUM [
wheel_brake4___GUARANTEE0_0;
wheel_brake4___GUARANTEE0_4;
wheel_brake4___GUARANTEE0_3;
wheel_brake4___GUARANTEE0_2;
wheel_brake4___GUARANTEE0_1    ];;
let normal_sys___GUARANTEE1_0 = 
PRO [
normal_sys_fault__independently__active__mv2__mv2__fault_2    ];;
let normal_sys___GUARANTEE1 = 
PRO [
normal_sys___GUARANTEE1_0    ];;
let phys_sys___GUARANTEE17_621 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let w4_w8_cmd_sys___GUARANTEE0_2 = 
PRO [
w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE0_0 = 
PRO [
w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE0_1 = 
PRO [
w4_w8_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE0 = 
SUM [
w4_w8_cmd_sys___GUARANTEE0_2;
w4_w8_cmd_sys___GUARANTEE0_0;
w4_w8_cmd_sys___GUARANTEE0_1    ];;
let command_sys___GUARANTEE3_0 = 
PRO [
w4_w8_cmd_sys___GUARANTEE0    ];;
let command_sys___GUARANTEE3 = 
PRO [
command_sys___GUARANTEE3_0    ];;
let channel2___GUARANTEE3_0 = 
PRO [
command_sys___GUARANTEE3    ];;
let channel2___GUARANTEE3 = 
PRO [
channel2___GUARANTEE3_0    ];;
let normal_sys___GUARANTEE2_0 = 
PRO [
normal_sys_fault__independently__active__mv3__mv3__fault_2    ];;
let normal_sys___GUARANTEE2 = 
PRO [
normal_sys___GUARANTEE2_0    ];;
let alt_sys___GUARANTEE0_0 = 
PRO [
alt_sys_fault__independently__active__mv1__mv1__fault_2    ];;
let alt_sys___GUARANTEE0 = 
PRO [
alt_sys___GUARANTEE0_0    ];;
let phys_sys___GUARANTEE17_622 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let w1_w5_cmd_sys___GUARANTEE0_2 = 
PRO [
w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE0_0 = 
PRO [
w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE0_1 = 
PRO [
w1_w5_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE0 = 
SUM [
w1_w5_cmd_sys___GUARANTEE0_2;
w1_w5_cmd_sys___GUARANTEE0_0;
w1_w5_cmd_sys___GUARANTEE0_1    ];;
let command_sys___GUARANTEE0_0 = 
PRO [
w1_w5_cmd_sys___GUARANTEE0    ];;
let command_sys___GUARANTEE0 = 
PRO [
command_sys___GUARANTEE0_0    ];;
let channel2___GUARANTEE0_0 = 
PRO [
command_sys___GUARANTEE0    ];;
let channel2___GUARANTEE0 = 
PRO [
channel2___GUARANTEE0_0    ];;
let wheel_brake7___GUARANTEE0_1 = 
PRO [
wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1    ];;
let wheel_brake7___GUARANTEE0_0 = 
PRO [
wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4    ];;
let wheel_brake7___GUARANTEE0_3 = 
PRO [
wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4    ];;
let wheel_brake7___GUARANTEE0_2 = 
PRO [
wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1    ];;
let wheel_brake7___GUARANTEE0_4 = 
PRO [
wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4    ];;
let wheel_brake7___GUARANTEE0 = 
SUM [
wheel_brake7___GUARANTEE0_1;
wheel_brake7___GUARANTEE0_0;
wheel_brake7___GUARANTEE0_3;
wheel_brake7___GUARANTEE0_2;
wheel_brake7___GUARANTEE0_4    ];;
let wheel_brake5___GUARANTEE0_3 = 
PRO [
wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4    ];;
let wheel_brake5___GUARANTEE0_2 = 
PRO [
wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1    ];;
let wheel_brake5___GUARANTEE0_4 = 
PRO [
wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4    ];;
let wheel_brake5___GUARANTEE0_1 = 
PRO [
wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1    ];;
let wheel_brake5___GUARANTEE0_0 = 
PRO [
wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4    ];;
let wheel_brake5___GUARANTEE0 = 
SUM [
wheel_brake5___GUARANTEE0_3;
wheel_brake5___GUARANTEE0_2;
wheel_brake5___GUARANTEE0_4;
wheel_brake5___GUARANTEE0_1;
wheel_brake5___GUARANTEE0_0    ];;
let normal_sys___GUARANTEE5_0 = 
PRO [
normal_sys_fault__independently__active__mv6__mv6__fault_2    ];;
let normal_sys___GUARANTEE5 = 
PRO [
normal_sys___GUARANTEE5_0    ];;
let phys_sys___GUARANTEE17_623 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let w2_w6_cmd_sys___GUARANTEE0_1 = 
PRO [
w2_w6_cmd_sys_fault__independently__active__alternate_command_calculator__alternate_command_calculator__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE0_0 = 
PRO [
w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE0_2 = 
PRO [
w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE0 = 
SUM [
w2_w6_cmd_sys___GUARANTEE0_1;
w2_w6_cmd_sys___GUARANTEE0_0;
w2_w6_cmd_sys___GUARANTEE0_2    ];;
let command_sys___GUARANTEE1_0 = 
PRO [
w2_w6_cmd_sys___GUARANTEE0    ];;
let command_sys___GUARANTEE1 = 
PRO [
command_sys___GUARANTEE1_0    ];;
let channel2___GUARANTEE1_0 = 
PRO [
command_sys___GUARANTEE1    ];;
let channel2___GUARANTEE1 = 
PRO [
channel2___GUARANTEE1_0    ];;
let w3_w7_cmd_sys___GUARANTEE2_2 = 
PRO [
w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE2_0 = 
PRO [
w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE2_1 = 
PRO [
w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE2 = 
SUM [
w3_w7_cmd_sys___GUARANTEE2_2;
w3_w7_cmd_sys___GUARANTEE2_0;
w3_w7_cmd_sys___GUARANTEE2_1    ];;
let command_sys___GUARANTEE10_0 = 
PRO [
w3_w7_cmd_sys___GUARANTEE2    ];;
let command_sys___GUARANTEE10 = 
PRO [
command_sys___GUARANTEE10_0    ];;
let channel2___GUARANTEE10_0 = 
PRO [
command_sys___GUARANTEE10    ];;
let channel2___GUARANTEE10 = 
PRO [
channel2___GUARANTEE10_0    ];;
let w3_w7_cmd_sys___GUARANTEE1_0 = 
PRO [
w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE1_1 = 
PRO [
w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE1_2 = 
PRO [
w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1    ];;
let w3_w7_cmd_sys___GUARANTEE1 = 
SUM [
w3_w7_cmd_sys___GUARANTEE1_0;
w3_w7_cmd_sys___GUARANTEE1_1;
w3_w7_cmd_sys___GUARANTEE1_2    ];;
let command_sys___GUARANTEE6_0 = 
PRO [
w3_w7_cmd_sys___GUARANTEE1    ];;
let command_sys___GUARANTEE6 = 
PRO [
command_sys___GUARANTEE6_0    ];;
let channel2___GUARANTEE6_0 = 
PRO [
command_sys___GUARANTEE6    ];;
let channel2___GUARANTEE6 = 
PRO [
channel2___GUARANTEE6_0    ];;
let w4_w8_cmd_sys___GUARANTEE1_1 = 
PRO [
w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE1_2 = 
PRO [
w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE1_0 = 
PRO [
w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE1 = 
SUM [
w4_w8_cmd_sys___GUARANTEE1_1;
w4_w8_cmd_sys___GUARANTEE1_2;
w4_w8_cmd_sys___GUARANTEE1_0    ];;
let command_sys___GUARANTEE7_0 = 
PRO [
w4_w8_cmd_sys___GUARANTEE1    ];;
let command_sys___GUARANTEE7 = 
PRO [
command_sys___GUARANTEE7_0    ];;
let channel2___GUARANTEE7_0 = 
PRO [
command_sys___GUARANTEE7    ];;
let channel2___GUARANTEE7 = 
PRO [
channel2___GUARANTEE7_0    ];;
let w1_w5_cmd_sys___GUARANTEE1_1 = 
PRO [
w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE1_2 = 
PRO [
w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE1_0 = 
PRO [
w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE1 = 
SUM [
w1_w5_cmd_sys___GUARANTEE1_1;
w1_w5_cmd_sys___GUARANTEE1_2;
w1_w5_cmd_sys___GUARANTEE1_0    ];;
let command_sys___GUARANTEE4_0 = 
PRO [
w1_w5_cmd_sys___GUARANTEE1    ];;
let command_sys___GUARANTEE4 = 
PRO [
command_sys___GUARANTEE4_0    ];;
let channel2___GUARANTEE4_0 = 
PRO [
command_sys___GUARANTEE4    ];;
let channel2___GUARANTEE4 = 
PRO [
channel2___GUARANTEE4_0    ];;
let w2_w6_cmd_sys___GUARANTEE1_0 = 
PRO [
w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE1_2 = 
PRO [
w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE1_1 = 
PRO [
w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE1 = 
SUM [
w2_w6_cmd_sys___GUARANTEE1_0;
w2_w6_cmd_sys___GUARANTEE1_2;
w2_w6_cmd_sys___GUARANTEE1_1    ];;
let command_sys___GUARANTEE5_0 = 
PRO [
w2_w6_cmd_sys___GUARANTEE1    ];;
let command_sys___GUARANTEE5 = 
PRO [
command_sys___GUARANTEE5_0    ];;
let channel2___GUARANTEE5_0 = 
PRO [
command_sys___GUARANTEE5    ];;
let channel2___GUARANTEE5 = 
PRO [
channel2___GUARANTEE5_0    ];;
let bscu___GUARANTEE3_2 = 
PRO [
channel2___GUARANTEE3    ];;
let channel1___GUARANTEE3_0 = 
PRO [
command_sys___GUARANTEE3    ];;
let channel1___GUARANTEE3 = 
PRO [
channel1___GUARANTEE3_0    ];;
let bscu___GUARANTEE3_0 = 
PRO [
channel1___GUARANTEE3    ];;
let bscu___GUARANTEE3_1 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_4_8__switch_gate_brake_as_cmd_pair_4_8__fault_2    ];;
let phys_sys___GUARANTEE17_624 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let w4_w8_cmd_sys___GUARANTEE2_2 = 
PRO [
w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE2_0 = 
PRO [
w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE2_1 = 
PRO [
w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1    ];;
let w4_w8_cmd_sys___GUARANTEE2 = 
SUM [
w4_w8_cmd_sys___GUARANTEE2_2;
w4_w8_cmd_sys___GUARANTEE2_0;
w4_w8_cmd_sys___GUARANTEE2_1    ];;
let command_sys___GUARANTEE11_0 = 
PRO [
w4_w8_cmd_sys___GUARANTEE2    ];;
let command_sys___GUARANTEE11 = 
PRO [
command_sys___GUARANTEE11_0    ];;
let channel2___GUARANTEE11_0 = 
PRO [
command_sys___GUARANTEE11    ];;
let channel2___GUARANTEE11 = 
PRO [
channel2___GUARANTEE11_0    ];;
let alt_sys___GUARANTEE3_0 = 
PRO [
alt_sys_fault__independently__active__mv4__mv4__fault_2    ];;
let alt_sys___GUARANTEE3 = 
PRO [
alt_sys___GUARANTEE3_0    ];;
let phys_sys___GUARANTEE17_625 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0    ];;
let channel2___GUARANTEE12_0 = 
PRO [
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1    ];;
let channel2___GUARANTEE12 = 
PRO [
channel2___GUARANTEE12_0    ];;
let phys_sys___GUARANTEE17_626 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_627 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let w1_w5_cmd_sys___GUARANTEE2_0 = 
PRO [
w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE2_1 = 
PRO [
w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE2_2 = 
PRO [
w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w1_w5_cmd_sys___GUARANTEE2 = 
SUM [
w1_w5_cmd_sys___GUARANTEE2_0;
w1_w5_cmd_sys___GUARANTEE2_1;
w1_w5_cmd_sys___GUARANTEE2_2    ];;
let command_sys___GUARANTEE8_0 = 
PRO [
w1_w5_cmd_sys___GUARANTEE2    ];;
let command_sys___GUARANTEE8 = 
PRO [
command_sys___GUARANTEE8_0    ];;
let channel2___GUARANTEE8_0 = 
PRO [
command_sys___GUARANTEE8    ];;
let channel2___GUARANTEE8 = 
PRO [
channel2___GUARANTEE8_0    ];;
let w2_w6_cmd_sys___GUARANTEE2_1 = 
PRO [
w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE2_0 = 
PRO [
w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE2_2 = 
PRO [
w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1    ];;
let w2_w6_cmd_sys___GUARANTEE2 = 
SUM [
w2_w6_cmd_sys___GUARANTEE2_1;
w2_w6_cmd_sys___GUARANTEE2_0;
w2_w6_cmd_sys___GUARANTEE2_2    ];;
let command_sys___GUARANTEE9_0 = 
PRO [
w2_w6_cmd_sys___GUARANTEE2    ];;
let command_sys___GUARANTEE9 = 
PRO [
command_sys___GUARANTEE9_0    ];;
let channel2___GUARANTEE9_0 = 
PRO [
command_sys___GUARANTEE9    ];;
let channel2___GUARANTEE9 = 
PRO [
channel2___GUARANTEE9_0    ];;
let phys_sys___GUARANTEE17_400 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let wheel_brake1___GUARANTEE0_0 = 
PRO [
wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4    ];;
let wheel_brake1___GUARANTEE0_1 = 
PRO [
wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1    ];;
let wheel_brake1___GUARANTEE0_4 = 
PRO [
wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4    ];;
let wheel_brake1___GUARANTEE0_2 = 
PRO [
wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1    ];;
let wheel_brake1___GUARANTEE0_3 = 
PRO [
wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4    ];;
let wheel_brake1___GUARANTEE0 = 
SUM [
wheel_brake1___GUARANTEE0_0;
wheel_brake1___GUARANTEE0_1;
wheel_brake1___GUARANTEE0_4;
wheel_brake1___GUARANTEE0_2;
wheel_brake1___GUARANTEE0_3    ];;
let phys_sys___GUARANTEE17_401 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_402 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_403 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_408 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_409 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_404 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_405 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_406 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_407 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_411 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_412 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_413 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_414 = 
PRO [
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_410 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let channel1___GUARANTEE11_0 = 
PRO [
command_sys___GUARANTEE11    ];;
let channel1___GUARANTEE11 = 
PRO [
channel1___GUARANTEE11_0    ];;
let bscu___GUARANTEE11_0 = 
PRO [
channel1___GUARANTEE11    ];;
let bscu___GUARANTEE11_2 = 
PRO [
channel2___GUARANTEE12    ];;
let bscu___GUARANTEE11_1 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2    ];;
let channel1___GUARANTEE12_0 = 
PRO [
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1    ];;
let channel1___GUARANTEE12 = 
PRO [
channel1___GUARANTEE12_0    ];;
let bscu___GUARANTEE11_4 = 
PRO [
channel1___GUARANTEE12    ];;
let bscu___GUARANTEE11_3 = 
PRO [
channel2___GUARANTEE11    ];;
let bscu___GUARANTEE11 = 
SUM [
bscu___GUARANTEE11_0;
bscu___GUARANTEE11_2;
bscu___GUARANTEE11_1;
bscu___GUARANTEE11_4;
bscu___GUARANTEE11_3    ];;
let ctrl_sys___GUARANTEE13_0 = 
PRO [
bscu___GUARANTEE11    ];;
let alt_sys___GUARANTEE1_0 = 
PRO [
alt_sys_fault__independently__active__mv2__mv2__fault_2    ];;
let alt_sys___GUARANTEE1 = 
PRO [
alt_sys___GUARANTEE1_0    ];;
let phys_sys___GUARANTEE17_419 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_415 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_416 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_417 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_418 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let channel1___GUARANTEE7_0 = 
PRO [
command_sys___GUARANTEE7    ];;
let bscu___GUARANTEE5_0 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2    ];;
let channel1___GUARANTEE5_0 = 
PRO [
command_sys___GUARANTEE5    ];;
let channel1___GUARANTEE5 = 
PRO [
channel1___GUARANTEE5_0    ];;
let bscu___GUARANTEE5_1 = 
PRO [
channel1___GUARANTEE5    ];;
let phys_sys___GUARANTEE12_5 = 
PRO [
normal_sys___GUARANTEE3    ];;
let bscu___GUARANTEE5_4 = 
PRO [
channel2___GUARANTEE5    ];;
let bscu___GUARANTEE5_2 = 
PRO [
channel2___GUARANTEE12    ];;
let bscu___GUARANTEE5_3 = 
PRO [
channel1___GUARANTEE12    ];;
let bscu___GUARANTEE10_1 = 
PRO [
channel2___GUARANTEE10    ];;
let channel1___GUARANTEE10_0 = 
PRO [
command_sys___GUARANTEE10    ];;
let channel1___GUARANTEE10 = 
PRO [
channel1___GUARANTEE10_0    ];;
let bscu___GUARANTEE10_0 = 
PRO [
channel1___GUARANTEE10    ];;
let bscu___GUARANTEE10_3 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2    ];;
let bscu___GUARANTEE10_2 = 
PRO [
channel2___GUARANTEE12    ];;
let bscu___GUARANTEE10_4 = 
PRO [
channel1___GUARANTEE12    ];;
let bscu___GUARANTEE10 = 
SUM [
bscu___GUARANTEE10_1;
bscu___GUARANTEE10_0;
bscu___GUARANTEE10_3;
bscu___GUARANTEE10_2;
bscu___GUARANTEE10_4    ];;
let channel1___GUARANTEE7 = 
PRO [
channel1___GUARANTEE7_0    ];;
let channel1___GUARANTEE8_0 = 
PRO [
command_sys___GUARANTEE8    ];;
let channel1___GUARANTEE8 = 
PRO [
channel1___GUARANTEE8_0    ];;
let channel1___GUARANTEE9_0 = 
PRO [
command_sys___GUARANTEE9    ];;
let channel1___GUARANTEE9 = 
PRO [
channel1___GUARANTEE9_0    ];;
let channel1___GUARANTEE4_0 = 
PRO [
command_sys___GUARANTEE4    ];;
let channel1___GUARANTEE4 = 
PRO [
channel1___GUARANTEE4_0    ];;
let phys_sys___GUARANTEE17_600 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_601 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let channel1___GUARANTEE6_0 = 
PRO [
command_sys___GUARANTEE6    ];;
let channel1___GUARANTEE6 = 
PRO [
channel1___GUARANTEE6_0    ];;
let channel1___GUARANTEE0_0 = 
PRO [
command_sys___GUARANTEE0    ];;
let channel1___GUARANTEE0 = 
PRO [
channel1___GUARANTEE0_0    ];;
let channel1___GUARANTEE1_0 = 
PRO [
command_sys___GUARANTEE1    ];;
let channel1___GUARANTEE1 = 
PRO [
channel1___GUARANTEE1_0    ];;
let channel1___GUARANTEE2_0 = 
PRO [
command_sys___GUARANTEE2    ];;
let channel1___GUARANTEE2 = 
PRO [
channel1___GUARANTEE2_0    ];;
let phys_sys___GUARANTEE17_606 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_607 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_608 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_609 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_602 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_603 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_604 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_605 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_610 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_611 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_612 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_617 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_618 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_619 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_613 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_614 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_615 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_616 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE10_1 = 
PRO [
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE10_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE10_0 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE10_5 = 
PRO [
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE10_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE10_4 = 
PRO [
wheel_brake2___GUARANTEE0    ];;
let phys_sys___GUARANTEE1_5 = 
PRO [
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE1_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE1_4 = 
PRO [
wheel_brake2___GUARANTEE0    ];;
let bscu___GUARANTEE1_0 = 
PRO [
channel1___GUARANTEE1    ];;
let bscu___GUARANTEE1_1 = 
PRO [
channel2___GUARANTEE1    ];;
let bscu___GUARANTEE1_2 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_2_6__switch_gate_brake_as_cmd_pair_2_6__fault_2    ];;
let bscu___GUARANTEE1 = 
SUM [
bscu___GUARANTEE1_0;
bscu___GUARANTEE1_1;
bscu___GUARANTEE1_2    ];;
let ctrl_sys___GUARANTEE1_0 = 
PRO [
bscu___GUARANTEE1    ];;
let phys_sys___GUARANTEE1_1 = 
PRO [
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE1_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE1_0 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let bscu___GUARANTEE3 = 
SUM [
bscu___GUARANTEE3_2;
bscu___GUARANTEE3_0;
bscu___GUARANTEE3_1    ];;
let ctrl_sys___GUARANTEE5_11 = 
PRO [
bscu___GUARANTEE3    ];;
let bscu___GUARANTEE2_0 = 
PRO [
channel1___GUARANTEE2    ];;
let bscu___GUARANTEE2_1 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_3_7__switch_gate_brake_as_cmd_pair_3_7__fault_2    ];;
let bscu___GUARANTEE2_2 = 
PRO [
channel2___GUARANTEE2    ];;
let bscu___GUARANTEE2 = 
SUM [
bscu___GUARANTEE2_0;
bscu___GUARANTEE2_1;
bscu___GUARANTEE2_2    ];;
let ctrl_sys___GUARANTEE5_10 = 
PRO [
bscu___GUARANTEE2    ];;
let phys_sys___GUARANTEE9_5 = 
PRO [
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE9_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE9_4 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE9_1 = 
PRO [
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE9_2 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE9_0 = 
PRO [
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE9 = 
SUM [
phys_sys___GUARANTEE9_5;
phys_sys___GUARANTEE9_3;
phys_sys___GUARANTEE9_4;
phys_sys___GUARANTEE9_1;
phys_sys___GUARANTEE9_2;
phys_sys___GUARANTEE9_0    ];;
let wBS_inst___GUARANTEE0_1 = 
PRO [
phys_sys___GUARANTEE9    ];;
let wBS_inst___GUARANTEE0_2 = 
PRO [
wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1    ];;
let bscu___GUARANTEE4_1 = 
PRO [
channel1___GUARANTEE4    ];;
let bscu___GUARANTEE4_2 = 
PRO [
channel2___GUARANTEE12    ];;
let bscu___GUARANTEE4_0 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2    ];;
let bscu___GUARANTEE4_3 = 
PRO [
channel2___GUARANTEE4    ];;
let bscu___GUARANTEE4_4 = 
PRO [
channel1___GUARANTEE12    ];;
let bscu___GUARANTEE4 = 
SUM [
bscu___GUARANTEE4_1;
bscu___GUARANTEE4_2;
bscu___GUARANTEE4_0;
bscu___GUARANTEE4_3;
bscu___GUARANTEE4_4    ];;
let ctrl_sys___GUARANTEE6_0 = 
PRO [
bscu___GUARANTEE4    ];;
let ctrl_sys___GUARANTEE6 = 
PRO [
ctrl_sys___GUARANTEE6_0    ];;
let wBS_inst___GUARANTEE0_0 = 
PRO [
ctrl_sys___GUARANTEE6    ];;
let bscu___GUARANTEE9_4 = 
PRO [
channel1___GUARANTEE12    ];;
let bscu___GUARANTEE9_2 = 
PRO [
channel2___GUARANTEE9    ];;
let bscu___GUARANTEE9_3 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2    ];;
let bscu___GUARANTEE9_0 = 
PRO [
channel1___GUARANTEE9    ];;
let bscu___GUARANTEE9_1 = 
PRO [
channel2___GUARANTEE12    ];;
let bscu___GUARANTEE9 = 
SUM [
bscu___GUARANTEE9_4;
bscu___GUARANTEE9_2;
bscu___GUARANTEE9_3;
bscu___GUARANTEE9_0;
bscu___GUARANTEE9_1    ];;
let ctrl_sys___GUARANTEE11_0 = 
PRO [
bscu___GUARANTEE9    ];;
let phys_sys___GUARANTEE17_90 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_93 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_94 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_91 = 
PRO [
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_92 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_97 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_98 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_95 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_96 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE5_1 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE5_2 = 
PRO [
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_99 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE5_0 = 
PRO [
wheel_brake6___GUARANTEE0    ];;
let bscu___GUARANTEE6_0 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2    ];;
let bscu___GUARANTEE6_3 = 
PRO [
channel2___GUARANTEE6    ];;
let bscu___GUARANTEE6_4 = 
PRO [
channel1___GUARANTEE12    ];;
let bscu___GUARANTEE6_1 = 
PRO [
channel1___GUARANTEE6    ];;
let bscu___GUARANTEE6_2 = 
PRO [
channel2___GUARANTEE12    ];;
let bscu___GUARANTEE6 = 
SUM [
bscu___GUARANTEE6_0;
bscu___GUARANTEE6_3;
bscu___GUARANTEE6_4;
bscu___GUARANTEE6_1;
bscu___GUARANTEE6_2    ];;
let ctrl_sys___GUARANTEE5_3 = 
PRO [
bscu___GUARANTEE6    ];;
let ctrl_sys___GUARANTEE5_2 = 
PRO [
bscu___GUARANTEE11    ];;
let ctrl_sys___GUARANTEE5_1 = 
PRO [
bscu___GUARANTEE9    ];;
let bscu___GUARANTEE8_3 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2    ];;
let bscu___GUARANTEE8_4 = 
PRO [
channel1___GUARANTEE12    ];;
let bscu___GUARANTEE8_1 = 
PRO [
channel2___GUARANTEE8    ];;
let bscu___GUARANTEE8_2 = 
PRO [
channel2___GUARANTEE12    ];;
let bscu___GUARANTEE8_0 = 
PRO [
channel1___GUARANTEE8    ];;
let bscu___GUARANTEE8 = 
SUM [
bscu___GUARANTEE8_3;
bscu___GUARANTEE8_4;
bscu___GUARANTEE8_1;
bscu___GUARANTEE8_2;
bscu___GUARANTEE8_0    ];;
let ctrl_sys___GUARANTEE5_0 = 
PRO [
bscu___GUARANTEE8    ];;
let ctrl_sys___GUARANTEE5_7 = 
PRO [
bscu___GUARANTEE1    ];;
let bscu___GUARANTEE0_1 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_pair_1_5__switch_gate_brake_as_cmd_pair_1_5__fault_2    ];;
let bscu___GUARANTEE0_2 = 
PRO [
channel1___GUARANTEE0    ];;
let bscu___GUARANTEE0_0 = 
PRO [
channel2___GUARANTEE0    ];;
let bscu___GUARANTEE0 = 
SUM [
bscu___GUARANTEE0_1;
bscu___GUARANTEE0_2;
bscu___GUARANTEE0_0    ];;
let ctrl_sys___GUARANTEE5_6 = 
PRO [
bscu___GUARANTEE0    ];;
let ctrl_sys___GUARANTEE5_5 = 
PRO [
bscu___GUARANTEE10    ];;
let bscu___GUARANTEE7_4 = 
PRO [
bscu_fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2    ];;
let bscu___GUARANTEE7_2 = 
PRO [
channel2___GUARANTEE7    ];;
let bscu___GUARANTEE7_3 = 
PRO [
channel1___GUARANTEE12    ];;
let bscu___GUARANTEE7_0 = 
PRO [
channel1___GUARANTEE7    ];;
let bscu___GUARANTEE7_1 = 
PRO [
channel2___GUARANTEE12    ];;
let bscu___GUARANTEE7 = 
SUM [
bscu___GUARANTEE7_4;
bscu___GUARANTEE7_2;
bscu___GUARANTEE7_3;
bscu___GUARANTEE7_0;
bscu___GUARANTEE7_1    ];;
let ctrl_sys___GUARANTEE5_4 = 
PRO [
bscu___GUARANTEE7    ];;
let bscu___GUARANTEE5 = 
SUM [
bscu___GUARANTEE5_0;
bscu___GUARANTEE5_1;
bscu___GUARANTEE5_4;
bscu___GUARANTEE5_2;
bscu___GUARANTEE5_3    ];;
let ctrl_sys___GUARANTEE5_9 = 
PRO [
bscu___GUARANTEE5    ];;
let ctrl_sys___GUARANTEE5_8 = 
PRO [
bscu___GUARANTEE4    ];;
let phys_sys___GUARANTEE5_5 = 
PRO [
normal_sys___GUARANTEE5    ];;
let phys_sys___GUARANTEE5_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE5_4 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE16_0 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE17_268 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_269 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_264 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_265 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_266 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_267 = 
PRO [
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_71 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_72 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_70 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_75 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_76 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_73 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_74 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_79 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_77 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_78 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_271 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_272 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_273 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_274 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_270 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_279 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_275 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_276 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_277 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_278 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_82 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_83 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_80 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_81 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_86 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_87 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_84 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_85 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_88 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_89 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_282 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_283 = 
PRO [
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_284 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_285 = 
PRO [
wheel_brake5___GUARANTEE0;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_280 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_281 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_286 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_287 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_288 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_289 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_50 = 
PRO [
wheel_brake6___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_53 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_54 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_51 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_52 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE3_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE17_57 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE3_4 = 
PRO [
alt_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE17_58 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let ctrl_sys___GUARANTEE3_0 = 
PRO [
bscu___GUARANTEE3    ];;
let phys_sys___GUARANTEE3_1 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE17_55 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE3_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE17_56 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE3_0 = 
PRO [
wheel_brake4___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_59 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_293 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_294 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_295 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_296 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_290 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_291 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_292 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_297 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_298 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_299 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_60 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_61 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_64 = 
PRO [
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_65 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE3_5 = 
PRO [
normal_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE17_62 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_63 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_68 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_69 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_66 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_67 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_224 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_466 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_225 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_467 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_226 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_468 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_227 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_469 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_220 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_462 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_221 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_463 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_222 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_464 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_223 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_465 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE14_5 = 
PRO [
normal_sys___GUARANTEE5    ];;
let phys_sys___GUARANTEE14_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE14_4 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE17_228 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_229 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_470 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_471 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_230 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_472 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_235 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_477 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_236 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_478 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_237 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_479 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_238 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_231 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_473 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_232 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_474 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_233 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_475 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_234 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_476 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_239 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_480 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_481 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_240 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_482 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_241 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_483 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_246 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_488 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_247 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_489 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_248 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_249 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_242 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_484 = 
PRO [
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_243 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_485 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_244 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_486 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_245 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_487 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_491 = 
PRO [
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_250 = 
PRO [
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_492 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_251 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_493 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_252 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_494 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let ctrl_sys___GUARANTEE9_0 = 
PRO [
bscu___GUARANTEE7    ];;
let phys_sys___GUARANTEE17_490 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_257 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_499 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_258 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_259 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_253 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_495 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_254 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_496 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_255 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_497 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_256 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_498 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE12_0 = 
PRO [
wheel_brake4___GUARANTEE0    ];;
let phys_sys___GUARANTEE12_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE12_4 = 
PRO [
alt_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE12_1 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE12_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE17_260 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_261 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_262 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_263 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_422 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_423 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_424 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_425 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_420 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_421 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE16_3 = 
PRO [
alt_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE16_4 = 
PRO [
wheel_brake8___GUARANTEE0    ];;
let phys_sys___GUARANTEE16_1 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE16_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE17_426 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_427 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE16_5 = 
PRO [
normal_sys___GUARANTEE7    ];;
let phys_sys___GUARANTEE17_428 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_429 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_433 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_434 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_435 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_436 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_430 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_431 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_432 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_437 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_438 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_439 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_202 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_444 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_203 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_445 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_204 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_446 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_205 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_447 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_440 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_441 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_200 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_442 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_201 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_443 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_206 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_448 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_207 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_449 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_208 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_209 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE7_0 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let ctrl_sys___GUARANTEE7_0 = 
PRO [
bscu___GUARANTEE5    ];;
let phys_sys___GUARANTEE17_450 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_213 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_455 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_214 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_456 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_215 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_457 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_216 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_458 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_451 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_210 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_452 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_211 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_453 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_212 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_454 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE7_5 = 
PRO [
normal_sys___GUARANTEE7    ];;
let phys_sys___GUARANTEE7_3 = 
PRO [
alt_sys___GUARANTEE3    ];;
let phys_sys___GUARANTEE17_217 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_459 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE7_4 = 
PRO [
wheel_brake8___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_218 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE7_1 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE17_219 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE7_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE14_1 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE14_2 = 
PRO [
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE14_0 = 
PRO [
wheel_brake6___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_460 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_461 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_500 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_501 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_502 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_507 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_508 = 
PRO [
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_509 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_503 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_504 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_505 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_506 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_510 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_511 = 
PRO [
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_512 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_513 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let ctrl_sys___GUARANTEE12_0 = 
PRO [
bscu___GUARANTEE10    ];;
let phys_sys___GUARANTEE17_518 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_519 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_514 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_515 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_516 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_517 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_521 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_522 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_523 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_524 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_520 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_529 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_525 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_526 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_527 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_528 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_532 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_533 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_534 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_535 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_530 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_531 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_536 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_537 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_538 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_539 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE11_0 = 
PRO [
wheel_brake3___GUARANTEE0    ];;
let phys_sys___GUARANTEE11_1 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE11_4 = 
PRO [
alt_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE11_5 = 
PRO [
normal_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE11_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE11_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE13_2 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE13_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE13_0 = 
PRO [
wheel_brake5___GUARANTEE0    ];;
let phys_sys___GUARANTEE13_1 = 
PRO [
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE13_4 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE13_5 = 
PRO [
normal_sys___GUARANTEE4    ];;
let phys_sys___GUARANTEE13 = 
SUM [
phys_sys___GUARANTEE13_2;
phys_sys___GUARANTEE13_3;
phys_sys___GUARANTEE13_0;
phys_sys___GUARANTEE13_1;
phys_sys___GUARANTEE13_4;
phys_sys___GUARANTEE13_5    ];;
let phys_sys___GUARANTEE12 = 
SUM [
phys_sys___GUARANTEE12_0;
phys_sys___GUARANTEE12_3;
phys_sys___GUARANTEE12_4;
phys_sys___GUARANTEE12_1;
phys_sys___GUARANTEE12_2;
phys_sys___GUARANTEE12_5    ];;
let phys_sys___GUARANTEE11 = 
SUM [
phys_sys___GUARANTEE11_0;
phys_sys___GUARANTEE11_1;
phys_sys___GUARANTEE11_4;
phys_sys___GUARANTEE11_5;
phys_sys___GUARANTEE11_2;
phys_sys___GUARANTEE11_3    ];;
let phys_sys___GUARANTEE10 = 
SUM [
phys_sys___GUARANTEE10_1;
phys_sys___GUARANTEE10_2;
phys_sys___GUARANTEE10_0;
phys_sys___GUARANTEE10_5;
phys_sys___GUARANTEE10_3;
phys_sys___GUARANTEE10_4    ];;
let phys_sys___GUARANTEE17_31 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_32 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_30 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_35 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_36 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_33 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_34 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_39 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_37 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_38 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_42 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_43 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_40 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_41 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_46 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_47 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_44 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_45 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_48 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_49 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_10 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_13 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_14 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_11 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_12 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_17 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_18 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_15 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_16 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_19 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_20 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_21 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_24 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_25 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_22 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_23 = 
PRO [
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_28 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_29 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_26 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_27 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_187 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_188 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_189 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_194 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_195 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_196 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_197 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_190 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_191 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_192 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_193 = 
PRO [
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_198 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_199 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_8 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_9 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_2 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_3 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_0 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_1 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_6 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_7 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_4 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_5 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_147 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_389 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_148 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_149 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_143 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_385 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_144 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_386 = 
PRO [
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_145 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_387 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_146 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_388 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_150 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_392 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_151 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_393 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_152 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_394 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_153 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_395 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_390 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_391 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_158 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_159 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_154 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_396 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_155 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_397 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_156 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_398 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_157 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_399 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_161 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_162 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_163 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_164 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_160 = 
PRO [
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_169 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_165 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_166 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_167 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_168 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_172 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_173 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_174 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_175 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_170 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_171 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_176 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_177 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_178 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_179 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_183 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_184 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_185 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_186 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_180 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_181 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_182 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_103 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_345 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_587 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_104 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_346 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_588 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_105 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_347 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_589 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_106 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_348 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_341 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_583 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_100 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_342 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_584 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_101 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_343 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_585 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_102 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_344 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_586 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_107 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_349 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_108 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_109 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_590 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_591 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_350 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_592 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_351 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_593 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_114 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_356 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_598 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_115 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_357 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_599 = 
PRO [
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_116 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_358 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_117 = 
PRO [
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_359 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_110 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_352 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_594 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_111 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_353 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_595 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_112 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_354 = 
PRO [
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_596 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_113 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_355 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_597 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_118 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_119 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_360 = 
PRO [
wheel_brake6___GUARANTEE0;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_361 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_120 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_362 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_125 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_367 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_126 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_368 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_127 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_369 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_128 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_121 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_363 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_122 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_364 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_123 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_365 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_124 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_366 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_129 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_370 = 
PRO [
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_371 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_130 = 
PRO [
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_372 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_131 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_373 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_136 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_378 = 
PRO [
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_137 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_379 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_138 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_139 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_132 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_374 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_133 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_375 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_134 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_376 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_135 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_377 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_381 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_140 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_382 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_141 = 
PRO [
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_383 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_142 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_384 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_380 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_301 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_543 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_302 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_544 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_303 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_545 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_304 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_546 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_540 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_541 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_300 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_542 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_309 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE3;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_305 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_547 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_306 = 
PRO [
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_548 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
wheel_brake4___GUARANTEE0;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_307 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_549 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_308 = 
PRO [
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_312 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_554 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_313 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_555 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_314 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_556 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_315 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_557 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_550 = 
PRO [
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_551 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_310 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_552 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_311 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_553 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_316 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_558 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_317 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_559 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_318 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_319 = 
PRO [
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_560 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_323 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_565 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_324 = 
PRO [
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_566 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_325 = 
PRO [
wheel_brake5___GUARANTEE0;
alt_sys___GUARANTEE2;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_567 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_326 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_568 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_561 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_320 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_562 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_321 = 
PRO [
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_563 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_322 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_564 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_327 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_569 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_328 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_329 = 
PRO [
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_570 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_571 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_334 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_576 = 
PRO [
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_335 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake3___GUARANTEE0;
wheel_brake4___GUARANTEE0;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_577 = 
PRO [
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_336 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE5;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_578 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
alt_sys___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_337 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE17_579 = 
PRO [
wheel_brake6___GUARANTEE0;
normal_sys___GUARANTEE4;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_330 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_572 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_331 = 
PRO [
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_573 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake8___GUARANTEE0;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_332 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE3;
alt_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_574 = 
PRO [
wheel_brake5___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_333 = 
PRO [
wheel_brake8___GUARANTEE0;
normal_sys___GUARANTEE6;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_575 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
wheel_brake4___GUARANTEE0;
normal_sys___GUARANTEE4;
wheel_brake1___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_338 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE17_339 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE17_580 = 
PRO [
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE5;
alt_sys___GUARANTEE2;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17_581 = 
PRO [
wheel_brake7___GUARANTEE0;
wheel_brake5___GUARANTEE0;
wheel_brake3___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE3;
wheel_brake1___GUARANTEE0;
alt_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_340 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE7;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE3;
normal_sys___GUARANTEE4;
normal_sys___GUARANTEE0;
normal_sys___GUARANTEE1    ];;
let phys_sys___GUARANTEE17_582 = 
PRO [
wheel_brake6___GUARANTEE0;
wheel_brake7___GUARANTEE0;
normal_sys___GUARANTEE2;
normal_sys___GUARANTEE4;
wheel_brake2___GUARANTEE0;
alt_sys___GUARANTEE3;
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE17 = 
SUM [
phys_sys___GUARANTEE17_620;
phys_sys___GUARANTEE17_500;
phys_sys___GUARANTEE17_621;
phys_sys___GUARANTEE17_501;
phys_sys___GUARANTEE17_622;
phys_sys___GUARANTEE17_502;
phys_sys___GUARANTEE17_623;
phys_sys___GUARANTEE17_507;
phys_sys___GUARANTEE17_508;
phys_sys___GUARANTEE17_509;
phys_sys___GUARANTEE17_503;
phys_sys___GUARANTEE17_624;
phys_sys___GUARANTEE17_504;
phys_sys___GUARANTEE17_625;
phys_sys___GUARANTEE17_505;
phys_sys___GUARANTEE17_626;
phys_sys___GUARANTEE17_506;
phys_sys___GUARANTEE17_627;
phys_sys___GUARANTEE17_510;
phys_sys___GUARANTEE17_511;
phys_sys___GUARANTEE17_512;
phys_sys___GUARANTEE17_513;
phys_sys___GUARANTEE17_518;
phys_sys___GUARANTEE17_519;
phys_sys___GUARANTEE17_514;
phys_sys___GUARANTEE17_515;
phys_sys___GUARANTEE17_516;
phys_sys___GUARANTEE17_517;
phys_sys___GUARANTEE17_400;
phys_sys___GUARANTEE17_521;
phys_sys___GUARANTEE17_401;
phys_sys___GUARANTEE17_522;
phys_sys___GUARANTEE17_402;
phys_sys___GUARANTEE17_523;
phys_sys___GUARANTEE17_403;
phys_sys___GUARANTEE17_524;
phys_sys___GUARANTEE17_520;
phys_sys___GUARANTEE17_408;
phys_sys___GUARANTEE17_529;
phys_sys___GUARANTEE17_409;
phys_sys___GUARANTEE17_404;
phys_sys___GUARANTEE17_525;
phys_sys___GUARANTEE17_405;
phys_sys___GUARANTEE17_526;
phys_sys___GUARANTEE17_406;
phys_sys___GUARANTEE17_527;
phys_sys___GUARANTEE17_407;
phys_sys___GUARANTEE17_528;
phys_sys___GUARANTEE17_411;
phys_sys___GUARANTEE17_532;
phys_sys___GUARANTEE17_412;
phys_sys___GUARANTEE17_533;
phys_sys___GUARANTEE17_413;
phys_sys___GUARANTEE17_534;
phys_sys___GUARANTEE17_414;
phys_sys___GUARANTEE17_535;
phys_sys___GUARANTEE17_530;
phys_sys___GUARANTEE17_410;
phys_sys___GUARANTEE17_531;
phys_sys___GUARANTEE17_419;
phys_sys___GUARANTEE17_415;
phys_sys___GUARANTEE17_536;
phys_sys___GUARANTEE17_416;
phys_sys___GUARANTEE17_537;
phys_sys___GUARANTEE17_417;
phys_sys___GUARANTEE17_538;
phys_sys___GUARANTEE17_418;
phys_sys___GUARANTEE17_539;
phys_sys___GUARANTEE17_600;
phys_sys___GUARANTEE17_601;
phys_sys___GUARANTEE17_606;
phys_sys___GUARANTEE17_607;
phys_sys___GUARANTEE17_608;
phys_sys___GUARANTEE17_609;
phys_sys___GUARANTEE17_602;
phys_sys___GUARANTEE17_603;
phys_sys___GUARANTEE17_604;
phys_sys___GUARANTEE17_605;
phys_sys___GUARANTEE17_610;
phys_sys___GUARANTEE17_611;
phys_sys___GUARANTEE17_612;
phys_sys___GUARANTEE17_617;
phys_sys___GUARANTEE17_618;
phys_sys___GUARANTEE17_619;
phys_sys___GUARANTEE17_613;
phys_sys___GUARANTEE17_614;
phys_sys___GUARANTEE17_615;
phys_sys___GUARANTEE17_616;
phys_sys___GUARANTEE17_31;
phys_sys___GUARANTEE17_32;
phys_sys___GUARANTEE17_30;
phys_sys___GUARANTEE17_35;
phys_sys___GUARANTEE17_36;
phys_sys___GUARANTEE17_33;
phys_sys___GUARANTEE17_34;
phys_sys___GUARANTEE17_39;
phys_sys___GUARANTEE17_37;
phys_sys___GUARANTEE17_38;
phys_sys___GUARANTEE17_42;
phys_sys___GUARANTEE17_43;
phys_sys___GUARANTEE17_40;
phys_sys___GUARANTEE17_41;
phys_sys___GUARANTEE17_46;
phys_sys___GUARANTEE17_47;
phys_sys___GUARANTEE17_44;
phys_sys___GUARANTEE17_45;
phys_sys___GUARANTEE17_48;
phys_sys___GUARANTEE17_49;
phys_sys___GUARANTEE17_10;
phys_sys___GUARANTEE17_13;
phys_sys___GUARANTEE17_14;
phys_sys___GUARANTEE17_11;
phys_sys___GUARANTEE17_12;
phys_sys___GUARANTEE17_17;
phys_sys___GUARANTEE17_18;
phys_sys___GUARANTEE17_15;
phys_sys___GUARANTEE17_16;
phys_sys___GUARANTEE17_19;
phys_sys___GUARANTEE17_20;
phys_sys___GUARANTEE17_21;
phys_sys___GUARANTEE17_24;
phys_sys___GUARANTEE17_25;
phys_sys___GUARANTEE17_22;
phys_sys___GUARANTEE17_23;
phys_sys___GUARANTEE17_28;
phys_sys___GUARANTEE17_29;
phys_sys___GUARANTEE17_26;
phys_sys___GUARANTEE17_27;
phys_sys___GUARANTEE17_187;
phys_sys___GUARANTEE17_188;
phys_sys___GUARANTEE17_189;
phys_sys___GUARANTEE17_194;
phys_sys___GUARANTEE17_195;
phys_sys___GUARANTEE17_196;
phys_sys___GUARANTEE17_197;
phys_sys___GUARANTEE17_190;
phys_sys___GUARANTEE17_191;
phys_sys___GUARANTEE17_192;
phys_sys___GUARANTEE17_193;
phys_sys___GUARANTEE17_198;
phys_sys___GUARANTEE17_199;
phys_sys___GUARANTEE17_8;
phys_sys___GUARANTEE17_9;
phys_sys___GUARANTEE17_90;
phys_sys___GUARANTEE17_2;
phys_sys___GUARANTEE17_93;
phys_sys___GUARANTEE17_3;
phys_sys___GUARANTEE17_94;
phys_sys___GUARANTEE17_0;
phys_sys___GUARANTEE17_91;
phys_sys___GUARANTEE17_1;
phys_sys___GUARANTEE17_92;
phys_sys___GUARANTEE17_6;
phys_sys___GUARANTEE17_97;
phys_sys___GUARANTEE17_7;
phys_sys___GUARANTEE17_98;
phys_sys___GUARANTEE17_4;
phys_sys___GUARANTEE17_95;
phys_sys___GUARANTEE17_5;
phys_sys___GUARANTEE17_96;
phys_sys___GUARANTEE17_99;
phys_sys___GUARANTEE17_147;
phys_sys___GUARANTEE17_268;
phys_sys___GUARANTEE17_389;
phys_sys___GUARANTEE17_148;
phys_sys___GUARANTEE17_269;
phys_sys___GUARANTEE17_149;
phys_sys___GUARANTEE17_143;
phys_sys___GUARANTEE17_264;
phys_sys___GUARANTEE17_385;
phys_sys___GUARANTEE17_144;
phys_sys___GUARANTEE17_265;
phys_sys___GUARANTEE17_386;
phys_sys___GUARANTEE17_145;
phys_sys___GUARANTEE17_266;
phys_sys___GUARANTEE17_387;
phys_sys___GUARANTEE17_146;
phys_sys___GUARANTEE17_267;
phys_sys___GUARANTEE17_388;
phys_sys___GUARANTEE17_71;
phys_sys___GUARANTEE17_72;
phys_sys___GUARANTEE17_70;
phys_sys___GUARANTEE17_75;
phys_sys___GUARANTEE17_76;
phys_sys___GUARANTEE17_73;
phys_sys___GUARANTEE17_74;
phys_sys___GUARANTEE17_79;
phys_sys___GUARANTEE17_77;
phys_sys___GUARANTEE17_78;
phys_sys___GUARANTEE17_150;
phys_sys___GUARANTEE17_271;
phys_sys___GUARANTEE17_392;
phys_sys___GUARANTEE17_151;
phys_sys___GUARANTEE17_272;
phys_sys___GUARANTEE17_393;
phys_sys___GUARANTEE17_152;
phys_sys___GUARANTEE17_273;
phys_sys___GUARANTEE17_394;
phys_sys___GUARANTEE17_153;
phys_sys___GUARANTEE17_274;
phys_sys___GUARANTEE17_395;
phys_sys___GUARANTEE17_390;
phys_sys___GUARANTEE17_270;
phys_sys___GUARANTEE17_391;
phys_sys___GUARANTEE17_158;
phys_sys___GUARANTEE17_279;
phys_sys___GUARANTEE17_159;
phys_sys___GUARANTEE17_154;
phys_sys___GUARANTEE17_275;
phys_sys___GUARANTEE17_396;
phys_sys___GUARANTEE17_155;
phys_sys___GUARANTEE17_276;
phys_sys___GUARANTEE17_397;
phys_sys___GUARANTEE17_156;
phys_sys___GUARANTEE17_277;
phys_sys___GUARANTEE17_398;
phys_sys___GUARANTEE17_157;
phys_sys___GUARANTEE17_278;
phys_sys___GUARANTEE17_399;
phys_sys___GUARANTEE17_82;
phys_sys___GUARANTEE17_83;
phys_sys___GUARANTEE17_80;
phys_sys___GUARANTEE17_81;
phys_sys___GUARANTEE17_86;
phys_sys___GUARANTEE17_87;
phys_sys___GUARANTEE17_84;
phys_sys___GUARANTEE17_85;
phys_sys___GUARANTEE17_88;
phys_sys___GUARANTEE17_89;
phys_sys___GUARANTEE17_161;
phys_sys___GUARANTEE17_282;
phys_sys___GUARANTEE17_162;
phys_sys___GUARANTEE17_283;
phys_sys___GUARANTEE17_163;
phys_sys___GUARANTEE17_284;
phys_sys___GUARANTEE17_164;
phys_sys___GUARANTEE17_285;
phys_sys___GUARANTEE17_280;
phys_sys___GUARANTEE17_160;
phys_sys___GUARANTEE17_281;
phys_sys___GUARANTEE17_169;
phys_sys___GUARANTEE17_165;
phys_sys___GUARANTEE17_286;
phys_sys___GUARANTEE17_166;
phys_sys___GUARANTEE17_287;
phys_sys___GUARANTEE17_167;
phys_sys___GUARANTEE17_288;
phys_sys___GUARANTEE17_168;
phys_sys___GUARANTEE17_289;
phys_sys___GUARANTEE17_50;
phys_sys___GUARANTEE17_53;
phys_sys___GUARANTEE17_54;
phys_sys___GUARANTEE17_51;
phys_sys___GUARANTEE17_52;
phys_sys___GUARANTEE17_57;
phys_sys___GUARANTEE17_58;
phys_sys___GUARANTEE17_55;
phys_sys___GUARANTEE17_56;
phys_sys___GUARANTEE17_59;
phys_sys___GUARANTEE17_172;
phys_sys___GUARANTEE17_293;
phys_sys___GUARANTEE17_173;
phys_sys___GUARANTEE17_294;
phys_sys___GUARANTEE17_174;
phys_sys___GUARANTEE17_295;
phys_sys___GUARANTEE17_175;
phys_sys___GUARANTEE17_296;
phys_sys___GUARANTEE17_290;
phys_sys___GUARANTEE17_170;
phys_sys___GUARANTEE17_291;
phys_sys___GUARANTEE17_171;
phys_sys___GUARANTEE17_292;
phys_sys___GUARANTEE17_176;
phys_sys___GUARANTEE17_297;
phys_sys___GUARANTEE17_177;
phys_sys___GUARANTEE17_298;
phys_sys___GUARANTEE17_178;
phys_sys___GUARANTEE17_299;
phys_sys___GUARANTEE17_179;
phys_sys___GUARANTEE17_60;
phys_sys___GUARANTEE17_61;
phys_sys___GUARANTEE17_64;
phys_sys___GUARANTEE17_65;
phys_sys___GUARANTEE17_62;
phys_sys___GUARANTEE17_63;
phys_sys___GUARANTEE17_68;
phys_sys___GUARANTEE17_69;
phys_sys___GUARANTEE17_66;
phys_sys___GUARANTEE17_67;
phys_sys___GUARANTEE17_183;
phys_sys___GUARANTEE17_184;
phys_sys___GUARANTEE17_185;
phys_sys___GUARANTEE17_186;
phys_sys___GUARANTEE17_180;
phys_sys___GUARANTEE17_181;
phys_sys___GUARANTEE17_182;
phys_sys___GUARANTEE17_103;
phys_sys___GUARANTEE17_224;
phys_sys___GUARANTEE17_345;
phys_sys___GUARANTEE17_466;
phys_sys___GUARANTEE17_587;
phys_sys___GUARANTEE17_104;
phys_sys___GUARANTEE17_225;
phys_sys___GUARANTEE17_346;
phys_sys___GUARANTEE17_467;
phys_sys___GUARANTEE17_588;
phys_sys___GUARANTEE17_105;
phys_sys___GUARANTEE17_226;
phys_sys___GUARANTEE17_347;
phys_sys___GUARANTEE17_468;
phys_sys___GUARANTEE17_589;
phys_sys___GUARANTEE17_106;
phys_sys___GUARANTEE17_227;
phys_sys___GUARANTEE17_348;
phys_sys___GUARANTEE17_469;
phys_sys___GUARANTEE17_220;
phys_sys___GUARANTEE17_341;
phys_sys___GUARANTEE17_462;
phys_sys___GUARANTEE17_583;
phys_sys___GUARANTEE17_100;
phys_sys___GUARANTEE17_221;
phys_sys___GUARANTEE17_342;
phys_sys___GUARANTEE17_463;
phys_sys___GUARANTEE17_584;
phys_sys___GUARANTEE17_101;
phys_sys___GUARANTEE17_222;
phys_sys___GUARANTEE17_343;
phys_sys___GUARANTEE17_464;
phys_sys___GUARANTEE17_585;
phys_sys___GUARANTEE17_102;
phys_sys___GUARANTEE17_223;
phys_sys___GUARANTEE17_344;
phys_sys___GUARANTEE17_465;
phys_sys___GUARANTEE17_586;
phys_sys___GUARANTEE17_107;
phys_sys___GUARANTEE17_228;
phys_sys___GUARANTEE17_349;
phys_sys___GUARANTEE17_108;
phys_sys___GUARANTEE17_229;
phys_sys___GUARANTEE17_109;
phys_sys___GUARANTEE17_590;
phys_sys___GUARANTEE17_470;
phys_sys___GUARANTEE17_591;
phys_sys___GUARANTEE17_350;
phys_sys___GUARANTEE17_471;
phys_sys___GUARANTEE17_592;
phys_sys___GUARANTEE17_230;
phys_sys___GUARANTEE17_351;
phys_sys___GUARANTEE17_472;
phys_sys___GUARANTEE17_593;
phys_sys___GUARANTEE17_114;
phys_sys___GUARANTEE17_235;
phys_sys___GUARANTEE17_356;
phys_sys___GUARANTEE17_477;
phys_sys___GUARANTEE17_598;
phys_sys___GUARANTEE17_115;
phys_sys___GUARANTEE17_236;
phys_sys___GUARANTEE17_357;
phys_sys___GUARANTEE17_478;
phys_sys___GUARANTEE17_599;
phys_sys___GUARANTEE17_116;
phys_sys___GUARANTEE17_237;
phys_sys___GUARANTEE17_358;
phys_sys___GUARANTEE17_479;
phys_sys___GUARANTEE17_117;
phys_sys___GUARANTEE17_238;
phys_sys___GUARANTEE17_359;
phys_sys___GUARANTEE17_110;
phys_sys___GUARANTEE17_231;
phys_sys___GUARANTEE17_352;
phys_sys___GUARANTEE17_473;
phys_sys___GUARANTEE17_594;
phys_sys___GUARANTEE17_111;
phys_sys___GUARANTEE17_232;
phys_sys___GUARANTEE17_353;
phys_sys___GUARANTEE17_474;
phys_sys___GUARANTEE17_595;
phys_sys___GUARANTEE17_112;
phys_sys___GUARANTEE17_233;
phys_sys___GUARANTEE17_354;
phys_sys___GUARANTEE17_475;
phys_sys___GUARANTEE17_596;
phys_sys___GUARANTEE17_113;
phys_sys___GUARANTEE17_234;
phys_sys___GUARANTEE17_355;
phys_sys___GUARANTEE17_476;
phys_sys___GUARANTEE17_597;
phys_sys___GUARANTEE17_118;
phys_sys___GUARANTEE17_239;
phys_sys___GUARANTEE17_119;
phys_sys___GUARANTEE17_480;
phys_sys___GUARANTEE17_360;
phys_sys___GUARANTEE17_481;
phys_sys___GUARANTEE17_240;
phys_sys___GUARANTEE17_361;
phys_sys___GUARANTEE17_482;
phys_sys___GUARANTEE17_120;
phys_sys___GUARANTEE17_241;
phys_sys___GUARANTEE17_362;
phys_sys___GUARANTEE17_483;
phys_sys___GUARANTEE17_125;
phys_sys___GUARANTEE17_246;
phys_sys___GUARANTEE17_367;
phys_sys___GUARANTEE17_488;
phys_sys___GUARANTEE17_126;
phys_sys___GUARANTEE17_247;
phys_sys___GUARANTEE17_368;
phys_sys___GUARANTEE17_489;
phys_sys___GUARANTEE17_127;
phys_sys___GUARANTEE17_248;
phys_sys___GUARANTEE17_369;
phys_sys___GUARANTEE17_128;
phys_sys___GUARANTEE17_249;
phys_sys___GUARANTEE17_121;
phys_sys___GUARANTEE17_242;
phys_sys___GUARANTEE17_363;
phys_sys___GUARANTEE17_484;
phys_sys___GUARANTEE17_122;
phys_sys___GUARANTEE17_243;
phys_sys___GUARANTEE17_364;
phys_sys___GUARANTEE17_485;
phys_sys___GUARANTEE17_123;
phys_sys___GUARANTEE17_244;
phys_sys___GUARANTEE17_365;
phys_sys___GUARANTEE17_486;
phys_sys___GUARANTEE17_124;
phys_sys___GUARANTEE17_245;
phys_sys___GUARANTEE17_366;
phys_sys___GUARANTEE17_487;
phys_sys___GUARANTEE17_129;
phys_sys___GUARANTEE17_370;
phys_sys___GUARANTEE17_491;
phys_sys___GUARANTEE17_250;
phys_sys___GUARANTEE17_371;
phys_sys___GUARANTEE17_492;
phys_sys___GUARANTEE17_130;
phys_sys___GUARANTEE17_251;
phys_sys___GUARANTEE17_372;
phys_sys___GUARANTEE17_493;
phys_sys___GUARANTEE17_131;
phys_sys___GUARANTEE17_252;
phys_sys___GUARANTEE17_373;
phys_sys___GUARANTEE17_494;
phys_sys___GUARANTEE17_490;
phys_sys___GUARANTEE17_136;
phys_sys___GUARANTEE17_257;
phys_sys___GUARANTEE17_378;
phys_sys___GUARANTEE17_499;
phys_sys___GUARANTEE17_137;
phys_sys___GUARANTEE17_258;
phys_sys___GUARANTEE17_379;
phys_sys___GUARANTEE17_138;
phys_sys___GUARANTEE17_259;
phys_sys___GUARANTEE17_139;
phys_sys___GUARANTEE17_132;
phys_sys___GUARANTEE17_253;
phys_sys___GUARANTEE17_374;
phys_sys___GUARANTEE17_495;
phys_sys___GUARANTEE17_133;
phys_sys___GUARANTEE17_254;
phys_sys___GUARANTEE17_375;
phys_sys___GUARANTEE17_496;
phys_sys___GUARANTEE17_134;
phys_sys___GUARANTEE17_255;
phys_sys___GUARANTEE17_376;
phys_sys___GUARANTEE17_497;
phys_sys___GUARANTEE17_135;
phys_sys___GUARANTEE17_256;
phys_sys___GUARANTEE17_377;
phys_sys___GUARANTEE17_498;
phys_sys___GUARANTEE17_260;
phys_sys___GUARANTEE17_381;
phys_sys___GUARANTEE17_140;
phys_sys___GUARANTEE17_261;
phys_sys___GUARANTEE17_382;
phys_sys___GUARANTEE17_141;
phys_sys___GUARANTEE17_262;
phys_sys___GUARANTEE17_383;
phys_sys___GUARANTEE17_142;
phys_sys___GUARANTEE17_263;
phys_sys___GUARANTEE17_384;
phys_sys___GUARANTEE17_380;
phys_sys___GUARANTEE17_301;
phys_sys___GUARANTEE17_422;
phys_sys___GUARANTEE17_543;
phys_sys___GUARANTEE17_302;
phys_sys___GUARANTEE17_423;
phys_sys___GUARANTEE17_544;
phys_sys___GUARANTEE17_303;
phys_sys___GUARANTEE17_424;
phys_sys___GUARANTEE17_545;
phys_sys___GUARANTEE17_304;
phys_sys___GUARANTEE17_425;
phys_sys___GUARANTEE17_546;
phys_sys___GUARANTEE17_540;
phys_sys___GUARANTEE17_420;
phys_sys___GUARANTEE17_541;
phys_sys___GUARANTEE17_300;
phys_sys___GUARANTEE17_421;
phys_sys___GUARANTEE17_542;
phys_sys___GUARANTEE17_309;
phys_sys___GUARANTEE17_305;
phys_sys___GUARANTEE17_426;
phys_sys___GUARANTEE17_547;
phys_sys___GUARANTEE17_306;
phys_sys___GUARANTEE17_427;
phys_sys___GUARANTEE17_548;
phys_sys___GUARANTEE17_307;
phys_sys___GUARANTEE17_428;
phys_sys___GUARANTEE17_549;
phys_sys___GUARANTEE17_308;
phys_sys___GUARANTEE17_429;
phys_sys___GUARANTEE17_312;
phys_sys___GUARANTEE17_433;
phys_sys___GUARANTEE17_554;
phys_sys___GUARANTEE17_313;
phys_sys___GUARANTEE17_434;
phys_sys___GUARANTEE17_555;
phys_sys___GUARANTEE17_314;
phys_sys___GUARANTEE17_435;
phys_sys___GUARANTEE17_556;
phys_sys___GUARANTEE17_315;
phys_sys___GUARANTEE17_436;
phys_sys___GUARANTEE17_557;
phys_sys___GUARANTEE17_550;
phys_sys___GUARANTEE17_430;
phys_sys___GUARANTEE17_551;
phys_sys___GUARANTEE17_310;
phys_sys___GUARANTEE17_431;
phys_sys___GUARANTEE17_552;
phys_sys___GUARANTEE17_311;
phys_sys___GUARANTEE17_432;
phys_sys___GUARANTEE17_553;
phys_sys___GUARANTEE17_316;
phys_sys___GUARANTEE17_437;
phys_sys___GUARANTEE17_558;
phys_sys___GUARANTEE17_317;
phys_sys___GUARANTEE17_438;
phys_sys___GUARANTEE17_559;
phys_sys___GUARANTEE17_318;
phys_sys___GUARANTEE17_439;
phys_sys___GUARANTEE17_319;
phys_sys___GUARANTEE17_560;
phys_sys___GUARANTEE17_202;
phys_sys___GUARANTEE17_323;
phys_sys___GUARANTEE17_444;
phys_sys___GUARANTEE17_565;
phys_sys___GUARANTEE17_203;
phys_sys___GUARANTEE17_324;
phys_sys___GUARANTEE17_445;
phys_sys___GUARANTEE17_566;
phys_sys___GUARANTEE17_204;
phys_sys___GUARANTEE17_325;
phys_sys___GUARANTEE17_446;
phys_sys___GUARANTEE17_567;
phys_sys___GUARANTEE17_205;
phys_sys___GUARANTEE17_326;
phys_sys___GUARANTEE17_447;
phys_sys___GUARANTEE17_568;
phys_sys___GUARANTEE17_440;
phys_sys___GUARANTEE17_561;
phys_sys___GUARANTEE17_320;
phys_sys___GUARANTEE17_441;
phys_sys___GUARANTEE17_562;
phys_sys___GUARANTEE17_200;
phys_sys___GUARANTEE17_321;
phys_sys___GUARANTEE17_442;
phys_sys___GUARANTEE17_563;
phys_sys___GUARANTEE17_201;
phys_sys___GUARANTEE17_322;
phys_sys___GUARANTEE17_443;
phys_sys___GUARANTEE17_564;
phys_sys___GUARANTEE17_206;
phys_sys___GUARANTEE17_327;
phys_sys___GUARANTEE17_448;
phys_sys___GUARANTEE17_569;
phys_sys___GUARANTEE17_207;
phys_sys___GUARANTEE17_328;
phys_sys___GUARANTEE17_449;
phys_sys___GUARANTEE17_208;
phys_sys___GUARANTEE17_329;
phys_sys___GUARANTEE17_209;
phys_sys___GUARANTEE17_570;
phys_sys___GUARANTEE17_450;
phys_sys___GUARANTEE17_571;
phys_sys___GUARANTEE17_213;
phys_sys___GUARANTEE17_334;
phys_sys___GUARANTEE17_455;
phys_sys___GUARANTEE17_576;
phys_sys___GUARANTEE17_214;
phys_sys___GUARANTEE17_335;
phys_sys___GUARANTEE17_456;
phys_sys___GUARANTEE17_577;
phys_sys___GUARANTEE17_215;
phys_sys___GUARANTEE17_336;
phys_sys___GUARANTEE17_457;
phys_sys___GUARANTEE17_578;
phys_sys___GUARANTEE17_216;
phys_sys___GUARANTEE17_337;
phys_sys___GUARANTEE17_458;
phys_sys___GUARANTEE17_579;
phys_sys___GUARANTEE17_330;
phys_sys___GUARANTEE17_451;
phys_sys___GUARANTEE17_572;
phys_sys___GUARANTEE17_210;
phys_sys___GUARANTEE17_331;
phys_sys___GUARANTEE17_452;
phys_sys___GUARANTEE17_573;
phys_sys___GUARANTEE17_211;
phys_sys___GUARANTEE17_332;
phys_sys___GUARANTEE17_453;
phys_sys___GUARANTEE17_574;
phys_sys___GUARANTEE17_212;
phys_sys___GUARANTEE17_333;
phys_sys___GUARANTEE17_454;
phys_sys___GUARANTEE17_575;
phys_sys___GUARANTEE17_217;
phys_sys___GUARANTEE17_338;
phys_sys___GUARANTEE17_459;
phys_sys___GUARANTEE17_218;
phys_sys___GUARANTEE17_339;
phys_sys___GUARANTEE17_219;
phys_sys___GUARANTEE17_580;
phys_sys___GUARANTEE17_460;
phys_sys___GUARANTEE17_581;
phys_sys___GUARANTEE17_340;
phys_sys___GUARANTEE17_461;
phys_sys___GUARANTEE17_582    ];;
let phys_sys___GUARANTEE16 = 
SUM [
phys_sys___GUARANTEE16_0;
phys_sys___GUARANTEE16_3;
phys_sys___GUARANTEE16_4;
phys_sys___GUARANTEE16_1;
phys_sys___GUARANTEE16_2;
phys_sys___GUARANTEE16_5    ];;
let phys_sys___GUARANTEE15_0 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE15_1 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE15_4 = 
PRO [
alt_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE15_5 = 
PRO [
normal_sys___GUARANTEE6    ];;
let phys_sys___GUARANTEE15_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE15_3 = 
PRO [
wheel_brake7___GUARANTEE0    ];;
let phys_sys___GUARANTEE15 = 
SUM [
phys_sys___GUARANTEE15_0;
phys_sys___GUARANTEE15_1;
phys_sys___GUARANTEE15_4;
phys_sys___GUARANTEE15_5;
phys_sys___GUARANTEE15_2;
phys_sys___GUARANTEE15_3    ];;
let phys_sys___GUARANTEE14 = 
SUM [
phys_sys___GUARANTEE14_1;
phys_sys___GUARANTEE14_2;
phys_sys___GUARANTEE14_0;
phys_sys___GUARANTEE14_5;
phys_sys___GUARANTEE14_3;
phys_sys___GUARANTEE14_4    ];;
let wBS_inst___GUARANTEE0 = 
SUM [
wBS_inst___GUARANTEE0_1;
wBS_inst___GUARANTEE0_2;
wBS_inst___GUARANTEE0_0    ];;
let phys_sys___GUARANTEE5 = 
SUM [
phys_sys___GUARANTEE5_1;
phys_sys___GUARANTEE5_2;
phys_sys___GUARANTEE5_0;
phys_sys___GUARANTEE5_5;
phys_sys___GUARANTEE5_3;
phys_sys___GUARANTEE5_4    ];;
let phys_sys___GUARANTEE6_0 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE6_1 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE6_4 = 
PRO [
alt_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE6_5 = 
PRO [
normal_sys___GUARANTEE6    ];;
let phys_sys___GUARANTEE6_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE6_3 = 
PRO [
wheel_brake7___GUARANTEE0    ];;
let phys_sys___GUARANTEE6 = 
SUM [
phys_sys___GUARANTEE6_0;
phys_sys___GUARANTEE6_1;
phys_sys___GUARANTEE6_4;
phys_sys___GUARANTEE6_5;
phys_sys___GUARANTEE6_2;
phys_sys___GUARANTEE6_3    ];;
let phys_sys___GUARANTEE7 = 
SUM [
phys_sys___GUARANTEE7_0;
phys_sys___GUARANTEE7_5;
phys_sys___GUARANTEE7_3;
phys_sys___GUARANTEE7_4;
phys_sys___GUARANTEE7_1;
phys_sys___GUARANTEE7_2    ];;
let phys_sys___GUARANTEE8_0 = 
PRO [
phys_sys_fault__independently__active__green_hyd_pump__green_hyd_pump__fault_1    ];;
let phys_sys___GUARANTEE8_1 = 
PRO [
phys_sys_fault__independently__active__shutoff_valve__shutoff_valve__fault_2    ];;
let phys_sys___GUARANTEE8 = 
SUM [
phys_sys___GUARANTEE8_0;
phys_sys___GUARANTEE8_1    ];;
let phys_sys___GUARANTEE1 = 
SUM [
phys_sys___GUARANTEE1_5;
phys_sys___GUARANTEE1_3;
phys_sys___GUARANTEE1_4;
phys_sys___GUARANTEE1_1;
phys_sys___GUARANTEE1_2;
phys_sys___GUARANTEE1_0    ];;
let phys_sys___GUARANTEE2_4 = 
PRO [
alt_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE2_5 = 
PRO [
normal_sys___GUARANTEE2    ];;
let phys_sys___GUARANTEE2_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE2_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE2_0 = 
PRO [
wheel_brake3___GUARANTEE0    ];;
let phys_sys___GUARANTEE2_1 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE2 = 
SUM [
phys_sys___GUARANTEE2_4;
phys_sys___GUARANTEE2_5;
phys_sys___GUARANTEE2_2;
phys_sys___GUARANTEE2_3;
phys_sys___GUARANTEE2_0;
phys_sys___GUARANTEE2_1    ];;
let phys_sys___GUARANTEE3 = 
SUM [
phys_sys___GUARANTEE3_3;
phys_sys___GUARANTEE3_4;
phys_sys___GUARANTEE3_1;
phys_sys___GUARANTEE3_2;
phys_sys___GUARANTEE3_0;
phys_sys___GUARANTEE3_5    ];;
let phys_sys___GUARANTEE4_2 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE4_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE4_0 = 
PRO [
wheel_brake5___GUARANTEE0    ];;
let phys_sys___GUARANTEE4_1 = 
PRO [
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE4_4 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE4_5 = 
PRO [
normal_sys___GUARANTEE4    ];;
let phys_sys___GUARANTEE4 = 
SUM [
phys_sys___GUARANTEE4_2;
phys_sys___GUARANTEE4_3;
phys_sys___GUARANTEE4_0;
phys_sys___GUARANTEE4_1;
phys_sys___GUARANTEE4_4;
phys_sys___GUARANTEE4_5    ];;
let phys_sys___GUARANTEE0_4 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys___GUARANTEE0_5 = 
PRO [
normal_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE0_2 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys___GUARANTEE0_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys___GUARANTEE0_0 = 
PRO [
alt_sys___GUARANTEE0    ];;
let phys_sys___GUARANTEE0_1 = 
PRO [
wheel_brake1___GUARANTEE0    ];;
let phys_sys___GUARANTEE0 = 
SUM [
phys_sys___GUARANTEE0_4;
phys_sys___GUARANTEE0_5;
phys_sys___GUARANTEE0_2;
phys_sys___GUARANTEE0_3;
phys_sys___GUARANTEE0_0;
phys_sys___GUARANTEE0_1    ];;
let ctrl_sys___GUARANTEE0_0 = 
PRO [
bscu___GUARANTEE0    ];;
let ctrl_sys___GUARANTEE10_0 = 
PRO [
bscu___GUARANTEE8    ];;
let ctrl_sys___GUARANTEE4_10 = 
PRO [
bscu___GUARANTEE2    ];;
let ctrl_sys___GUARANTEE4_11 = 
PRO [
bscu___GUARANTEE3    ];;
let ctrl_sys___GUARANTEE4_0 = 
PRO [
bscu___GUARANTEE8    ];;
let ctrl_sys___GUARANTEE4_4 = 
PRO [
bscu___GUARANTEE7    ];;
let ctrl_sys___GUARANTEE4_3 = 
PRO [
bscu___GUARANTEE6    ];;
let ctrl_sys___GUARANTEE4_2 = 
PRO [
bscu___GUARANTEE11    ];;
let ctrl_sys___GUARANTEE4_1 = 
PRO [
bscu___GUARANTEE9    ];;
let ctrl_sys___GUARANTEE4_8 = 
PRO [
bscu___GUARANTEE4    ];;
let ctrl_sys___GUARANTEE4_7 = 
PRO [
bscu___GUARANTEE1    ];;
let ctrl_sys___GUARANTEE4_6 = 
PRO [
bscu___GUARANTEE0    ];;
let ctrl_sys___GUARANTEE4_5 = 
PRO [
bscu___GUARANTEE10    ];;
let ctrl_sys___GUARANTEE4_9 = 
PRO [
bscu___GUARANTEE5    ];;
let ctrl_sys___GUARANTEE13 = 
PRO [
ctrl_sys___GUARANTEE13_0    ];;
let ctrl_sys___GUARANTEE11 = 
PRO [
ctrl_sys___GUARANTEE11_0    ];;
let ctrl_sys___GUARANTEE12 = 
PRO [
ctrl_sys___GUARANTEE12_0    ];;
let ctrl_sys___GUARANTEE10 = 
PRO [
ctrl_sys___GUARANTEE10_0    ];;
let ctrl_sys___GUARANTEE2_0 = 
PRO [
bscu___GUARANTEE2    ];;
let ctrl_sys___GUARANTEE8_0 = 
PRO [
bscu___GUARANTEE6    ];;
let ctrl_sys___GUARANTEE9 = 
PRO [
ctrl_sys___GUARANTEE9_0    ];;
let ctrl_sys___GUARANTEE8 = 
PRO [
ctrl_sys___GUARANTEE8_0    ];;
let ctrl_sys___GUARANTEE7 = 
PRO [
ctrl_sys___GUARANTEE7_0    ];;
let ctrl_sys___GUARANTEE5 = 
SUM [
ctrl_sys___GUARANTEE5_3;
ctrl_sys___GUARANTEE5_2;
ctrl_sys___GUARANTEE5_1;
ctrl_sys___GUARANTEE5_0;
ctrl_sys___GUARANTEE5_7;
ctrl_sys___GUARANTEE5_11;
ctrl_sys___GUARANTEE5_6;
ctrl_sys___GUARANTEE5_5;
ctrl_sys___GUARANTEE5_4;
ctrl_sys___GUARANTEE5_9;
ctrl_sys___GUARANTEE5_8;
ctrl_sys___GUARANTEE5_10    ];;
let ctrl_sys___GUARANTEE4 = 
SUM [
ctrl_sys___GUARANTEE4_0;
ctrl_sys___GUARANTEE4_4;
ctrl_sys___GUARANTEE4_3;
ctrl_sys___GUARANTEE4_2;
ctrl_sys___GUARANTEE4_1;
ctrl_sys___GUARANTEE4_8;
ctrl_sys___GUARANTEE4_10;
ctrl_sys___GUARANTEE4_7;
ctrl_sys___GUARANTEE4_11;
ctrl_sys___GUARANTEE4_6;
ctrl_sys___GUARANTEE4_5;
ctrl_sys___GUARANTEE4_9    ];;
let ctrl_sys___GUARANTEE3 = 
PRO [
ctrl_sys___GUARANTEE3_0    ];;
let ctrl_sys___GUARANTEE2 = 
PRO [
ctrl_sys___GUARANTEE2_0    ];;
let ctrl_sys___GUARANTEE1 = 
PRO [
ctrl_sys___GUARANTEE1_0    ];;
let ctrl_sys___GUARANTEE0 = 
PRO [
ctrl_sys___GUARANTEE0_0    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE0;;
probErrorCut wBS_inst___GUARANTEE0;;
probErrorCutImp wBS_inst___GUARANTEE0;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE0_direct_ftree.gv" wBS_inst___GUARANTEE0 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE0_optimized_ftree.gv" wBS_inst___GUARANTEE0 ;;

