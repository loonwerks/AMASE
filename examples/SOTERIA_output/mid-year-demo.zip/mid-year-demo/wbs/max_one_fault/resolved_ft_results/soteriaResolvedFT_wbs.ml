#use "top.ml";;
let w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2"),1.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1"),0.01, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let alt_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let wBS_inst___GUARANTEE5 = 
SUM [
w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1;
wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2;
normal_sys_fault__independently__active__mv1__mv1__fault_2;
w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4;
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1;
wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1;
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1;
w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1;
alt_sys_fault__independently__active__mv1__mv1__fault_2    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE5;;
probErrorCut wBS_inst___GUARANTEE5;;
probErrorCutImp wBS_inst___GUARANTEE5;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE5_direct_ftree.gv" wBS_inst___GUARANTEE5 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE5_optimized_ftree.gv" wBS_inst___GUARANTEE5 ;;

let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let wBS_inst___GUARANTEE4_134_1 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let wBS_inst___GUARANTEE4_134_2 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let wBS_inst___GUARANTEE4_134_3 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wBS_inst___GUARANTEE4_213_1 = 
PRO [
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1    ];;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wBS_inst___GUARANTEE4_213_0 = 
PRO [
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1    ];;
let wBS_inst___GUARANTEE4 = 
SUM [
wBS_inst___GUARANTEE4_134_1;
wBS_inst___GUARANTEE4_134_2;
wBS_inst___GUARANTEE4_134_3;
wBS_inst___GUARANTEE4_213_1;
wBS_inst___GUARANTEE4_213_0    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE4;;
probErrorCut wBS_inst___GUARANTEE4;;
probErrorCutImp wBS_inst___GUARANTEE4;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE4_direct_ftree.gv" wBS_inst___GUARANTEE4 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE4_optimized_ftree.gv" wBS_inst___GUARANTEE4 ;;

let wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2"),1.3E-5, 1.0);;
let wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let normal_sys_fault__independently__active__mv4__mv4__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv4__mv4__fault_2"),3.25E-6, 1.0);;
let wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let normal_sys_fault__independently__active__mv5__mv5__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv5__mv5__fault_2"),3.25E-6, 1.0);;
let wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let alt_sys_fault__independently__active__mv4__mv4__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv4__mv4__fault_2"),3.25E-6, 1.0);;
let normal_sys_fault__independently__active__mv8__mv8__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv8__mv8__fault_2"),3.25E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2"),1.3E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1"),0.01, 1.0);;
let alt_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2"),1.3E-5, 1.0);;
let wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2"),1.3E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv2__mv2__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv2__mv2__fault_2"),3.25E-6, 1.0);;
let wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let alt_sys_fault__independently__active__mv2__mv2__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv2__mv2__fault_2"),3.25E-6, 1.0);;
let wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let alt_sys_fault__independently__active__mv3__mv3__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv3__mv3__fault_2"),3.25E-6, 1.0);;
let normal_sys_fault__independently__active__mv6__mv6__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv6__mv6__fault_2"),3.25E-6, 1.0);;
let wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv7__mv7__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv7__mv7__fault_2"),3.25E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2"),1.3E-5, 1.0);;
let wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2"),1.3E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2"),1.3E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let normal_sys_fault__independently__active__mv3__mv3__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv3__mv3__fault_2"),3.25E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1"),0.01, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2"),1.3E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wBS_inst___GUARANTEE3 = 
SUM [
wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4;
w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2;
wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4;
normal_sys_fault__independently__active__mv4__mv4__fault_2;
wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
normal_sys_fault__independently__active__mv5__mv5__fault_2;
wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
alt_sys_fault__independently__active__mv4__mv4__fault_2;
normal_sys_fault__independently__active__mv8__mv8__fault_2;
w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1;
wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2;
w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1;
wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1;
alt_sys_fault__independently__active__mv1__mv1__fault_2;
wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4;
w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2;
wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1;
w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2;
w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
normal_sys_fault__independently__active__mv2__mv2__fault_2;
wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1;
w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1;
alt_sys_fault__independently__active__mv2__mv2__fault_2;
wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
alt_sys_fault__independently__active__mv3__mv3__fault_2;
normal_sys_fault__independently__active__mv6__mv6__fault_2;
wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
normal_sys_fault__independently__active__mv7__mv7__fault_2;
bscu_fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2;
wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1;
wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
normal_sys_fault__independently__active__mv1__mv1__fault_2;
bscu_fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2;
bscu_fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2;
w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
normal_sys_fault__independently__active__mv3__mv3__fault_2;
w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1;
wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1;
w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_1__switch_gate_brake_as_cmd_1__fault_2;
w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE3;;
probErrorCut wBS_inst___GUARANTEE3;;
probErrorCutImp wBS_inst___GUARANTEE3;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE3_direct_ftree.gv" wBS_inst___GUARANTEE3 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE3_optimized_ftree.gv" wBS_inst___GUARANTEE3 ;;

let wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv3__mv3__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv3__mv3__fault_2"),3.25E-6, 1.0);;
let wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let normal_sys_fault__independently__active__mv4__mv4__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv4__mv4__fault_2"),3.25E-6, 1.0);;
let wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let alt_sys_fault__independently__active__mv3__mv3__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv3__mv3__fault_2"),3.25E-6, 1.0);;
let wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv7__mv7__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv7__mv7__fault_2"),3.25E-6, 1.0);;
let wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let alt_sys_fault__independently__active__mv4__mv4__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv4__mv4__fault_2"),3.25E-6, 1.0);;
let normal_sys_fault__independently__active__mv8__mv8__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv8__mv8__fault_2"),3.25E-6, 1.0);;
let wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wBS_inst___GUARANTEE2 = 
SUM [
wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
normal_sys_fault__independently__active__mv3__mv3__fault_2;
wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
normal_sys_fault__independently__active__mv4__mv4__fault_2;
wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1;
wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
alt_sys_fault__independently__active__mv3__mv3__fault_2;
wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
normal_sys_fault__independently__active__mv7__mv7__fault_2;
wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4;
alt_sys_fault__independently__active__mv4__mv4__fault_2;
normal_sys_fault__independently__active__mv8__mv8__fault_2;
wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE2;;
probErrorCut wBS_inst___GUARANTEE2;;
probErrorCutImp wBS_inst___GUARANTEE2;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE2_direct_ftree.gv" wBS_inst___GUARANTEE2 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE2_optimized_ftree.gv" wBS_inst___GUARANTEE2 ;;

let wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let normal_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let normal_sys_fault__independently__active__mv2__mv2__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv2__mv2__fault_2"),3.25E-6, 1.0);;
let wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let alt_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let alt_sys_fault__independently__active__mv2__mv2__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv2__mv2__fault_2"),3.25E-6, 1.0);;
let normal_sys_fault__independently__active__mv5__mv5__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv5__mv5__fault_2"),3.25E-6, 1.0);;
let wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake1","wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let normal_sys_fault__independently__active__mv6__mv6__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv6__mv6__fault_2"),3.25E-6, 1.0);;
let wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let wBS_inst___GUARANTEE1 = 
SUM [
wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
normal_sys_fault__independently__active__mv1__mv1__fault_2;
wheel_brake1_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wheel_brake1_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
normal_sys_fault__independently__active__mv2__mv2__fault_2;
wheel_brake1_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake1_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1;
alt_sys_fault__independently__active__mv1__mv1__fault_2;
alt_sys_fault__independently__active__mv2__mv2__fault_2;
normal_sys_fault__independently__active__mv5__mv5__fault_2;
wheel_brake1_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
normal_sys_fault__independently__active__mv6__mv6__fault_2;
wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE1;;
probErrorCut wBS_inst___GUARANTEE1;;
probErrorCutImp wBS_inst___GUARANTEE1;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE1_direct_ftree.gv" wBS_inst___GUARANTEE1 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE1_optimized_ftree.gv" wBS_inst___GUARANTEE1 ;;

let wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1"),0.01, 1.0);;
let wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let alt_sys_fault__independently__active__mv4__mv4__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv4__mv4__fault_2"),3.25E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let normal_sys_fault__independently__active__mv8__mv8__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv8__mv8__fault_2"),3.25E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2"),1.3E-5, 1.0);;
let wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake8","wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let wBS_inst___GUARANTEE12 = 
SUM [
wheel_brake8_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1;
wheel_brake8_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
alt_sys_fault__independently__active__mv4__mv4__fault_2;
w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
normal_sys_fault__independently__active__mv8__mv8__fault_2;
w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1;
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1;
w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
wheel_brake8_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_8__switch_gate_brake_as_cmd_8__fault_2;
wheel_brake8_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
wheel_brake8_fault__independently__active__brake_actuator__brake_actuator__fault_4;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE12;;
probErrorCut wBS_inst___GUARANTEE12;;
probErrorCutImp wBS_inst___GUARANTEE12;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE12_direct_ftree.gv" wBS_inst___GUARANTEE12 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE12_optimized_ftree.gv" wBS_inst___GUARANTEE12 ;;

let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let wBS_inst___GUARANTEE0_0_5 = 
PRO [
phys_sys_fault__independently__active__accumulator__accumulator__fault_2    ];;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let wBS_inst___GUARANTEE0_0_4 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2    ];;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let wBS_inst___GUARANTEE0_0_3 = 
PRO [
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
let wBS_inst___GUARANTEE0 = 
SUM [
wBS_inst___GUARANTEE0_0_5;
wBS_inst___GUARANTEE0_0_4;
wBS_inst___GUARANTEE0_0_3    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE0;;
probErrorCut wBS_inst___GUARANTEE0;;
probErrorCutImp wBS_inst___GUARANTEE0;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE0_direct_ftree.gv" wBS_inst___GUARANTEE0 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE0_optimized_ftree.gv" wBS_inst___GUARANTEE0 ;;

let wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1"),0.01, 1.0);;
let alt_sys_fault__independently__active__mv3__mv3__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv3__mv3__fault_2"),3.25E-6, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let normal_sys_fault__independently__active__mv7__mv7__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv7__mv7__fault_2"),3.25E-6, 1.0);;
let wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2"),1.3E-5, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake7","wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let wBS_inst___GUARANTEE11 = 
SUM [
wheel_brake7_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1;
alt_sys_fault__independently__active__mv3__mv3__fault_2;
w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
normal_sys_fault__independently__active__mv7__mv7__fault_2;
wheel_brake7_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wheel_brake7_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
bscu_fault__independently__active__switch_gate_brake_as_cmd_7__switch_gate_brake_as_cmd_7__fault_2;
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1;
w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1;
wheel_brake7_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
wheel_brake7_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE11;;
probErrorCut wBS_inst___GUARANTEE11;;
probErrorCutImp wBS_inst___GUARANTEE11;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE11_direct_ftree.gv" wBS_inst___GUARANTEE11 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE11_optimized_ftree.gv" wBS_inst___GUARANTEE11 ;;

let alt_sys_fault__independently__active__mv2__mv2__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv2__mv2__fault_2"),3.25E-6, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let normal_sys_fault__independently__active__mv6__mv6__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv6__mv6__fault_2"),3.25E-6, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2"),1.3E-5, 1.0);;
let wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1"),0.01, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake6","wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let wBS_inst___GUARANTEE10 = 
SUM [
alt_sys_fault__independently__active__mv2__mv2__fault_2;
w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
wheel_brake6_fault__independently__active__brake_actuator__brake_actuator__fault_4;
normal_sys_fault__independently__active__mv6__mv6__fault_2;
w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
wheel_brake6_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_6__switch_gate_brake_as_cmd_6__fault_2;
wheel_brake6_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
wheel_brake6_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1;
wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1;
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1;
wheel_brake6_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE10;;
probErrorCut wBS_inst___GUARANTEE10;;
probErrorCutImp wBS_inst___GUARANTEE10;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE10_direct_ftree.gv" wBS_inst___GUARANTEE10 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE10_optimized_ftree.gv" wBS_inst___GUARANTEE10 ;;

let normal_sys_fault__independently__active__mv5__mv5__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv5__mv5__fault_2"),3.25E-6, 1.0);;
let wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1"),9.0E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2"),1.3E-5, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1 = 
Leaf
    (("w1_w5_cmd_sys","w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1"),9.0E-6, 1.0);;
let wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1"),0.01, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake5","wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let alt_sys_fault__independently__active__mv1__mv1__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv1__mv1__fault_2"),3.25E-6, 1.0);;
let wBS_inst___GUARANTEE9 = 
SUM [
normal_sys_fault__independently__active__mv5__mv5__fault_2;
wheel_brake5_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake5_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
w1_w5_cmd_sys_fault__independently__active__normal_command_calculator_2__normal_command_calculator_2__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_5__switch_gate_brake_as_cmd_5__fault_2;
w1_w5_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
w1_w5_cmd_sys_fault__independently__active__antiskid_command_facility_2__antiskid_command_facility_2__fault_1;
wheel_brake5_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1;
wheel_brake5_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1;
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1;
wheel_brake5_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1;
alt_sys_fault__independently__active__mv1__mv1__fault_2    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE9;;
probErrorCut wBS_inst___GUARANTEE9;;
probErrorCutImp wBS_inst___GUARANTEE9;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE9_direct_ftree.gv" wBS_inst___GUARANTEE9 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE9_optimized_ftree.gv" wBS_inst___GUARANTEE9 ;;

let wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1"),0.01, 1.0);;
let wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let alt_sys_fault__independently__active__mv4__mv4__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv4__mv4__fault_2"),3.25E-6, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w4_w8_cmd_sys","w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2"),1.3E-5, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake4","wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let normal_sys_fault__independently__active__mv4__mv4__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv4__mv4__fault_2"),3.25E-6, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let wBS_inst___GUARANTEE8 = 
SUM [
wheel_brake4_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1;
wheel_brake4_fault__independently__active__brake_actuator__brake_actuator__fault_4;
w4_w8_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
alt_sys_fault__independently__active__mv4__mv4__fault_2;
w4_w8_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
wheel_brake4_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake4_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
w4_w8_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_4__switch_gate_brake_as_cmd_4__fault_2;
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1;
wheel_brake4_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1;
normal_sys_fault__independently__active__mv4__mv4__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE8;;
probErrorCut wBS_inst___GUARANTEE8;;
probErrorCutImp wBS_inst___GUARANTEE8;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE8_direct_ftree.gv" wBS_inst___GUARANTEE8 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE8_optimized_ftree.gv" wBS_inst___GUARANTEE8 ;;

let wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1"),0.01, 1.0);;
let alt_sys_fault__independently__active__mv3__mv3__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv3__mv3__fault_2"),3.25E-6, 1.0);;
let wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let normal_sys_fault__independently__active__mv3__mv3__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv3__mv3__fault_2"),3.25E-6, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2"),1.3E-5, 1.0);;
let wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake3","wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w3_w7_cmd_sys","w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let wBS_inst___GUARANTEE7 = 
SUM [
wBS_inst_fault__independently__active__pedal_sensor_R__pedal_sensor_R__fault_1;
alt_sys_fault__independently__active__mv3__mv3__fault_2;
wheel_brake3_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
wheel_brake3_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
wheel_brake3_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
w3_w7_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
normal_sys_fault__independently__active__mv3__mv3__fault_2;
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1;
w3_w7_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_3__switch_gate_brake_as_cmd_3__fault_2;
wheel_brake3_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
wheel_brake3_fault__independently__active__brake_actuator__brake_actuator__fault_4;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1;
w3_w7_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE7;;
probErrorCut wBS_inst___GUARANTEE7;;
probErrorCutImp wBS_inst___GUARANTEE7;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE7_direct_ftree.gv" wBS_inst___GUARANTEE7 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE7_optimized_ftree.gv" wBS_inst___GUARANTEE7 ;;

let alt_sys_fault__independently__active__mv2__mv2__fault_2 = 
Leaf
    (("alt_sys","alt_sys_fault__independently__active__mv2__mv2__fault_2"),3.25E-6, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1"),9.0E-6, 1.0);;
let wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4"),3.3E-6, 1.0);;
let wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1"),1.0E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1"),9.0E-6, 1.0);;
let normal_sys_fault__independently__active__mv2__mv2__fault_2 = 
Leaf
    (("normal_sys","normal_sys_fault__independently__active__mv2__mv2__fault_2"),3.25E-6, 1.0);;
let channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel2","channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let bscu_fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2 = 
Leaf
    (("bscu","bscu_fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2"),1.3E-5, 1.0);;
let w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1 = 
Leaf
    (("w2_w6_cmd_sys","w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1"),9.0E-6, 1.0);;
let wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1 = 
Leaf
    (("WBS_inst","wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1"),0.01, 1.0);;
let channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1 = 
Leaf
    (("channel1","channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1"),8.0E-7, 1.0);;
let wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4"),3.3E-5, 1.0);;
let phys_sys_fault__independently__active__accumulator__accumulator__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__accumulator__accumulator__fault_2"),5.0E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2"),1.0E-5, 1.0);;
let wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4 = 
Leaf
    (("wheel_brake2","wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4"),3.3E-5, 1.0);;
let phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1 = 
Leaf
    (("phys_sys","phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1"),1.0E-5, 1.0);;
let wBS_inst___GUARANTEE6 = 
SUM [
alt_sys_fault__independently__active__mv2__mv2__fault_2;
w2_w6_cmd_sys_fault__independently__active__brake_command_facility__brake_command_facility__fault_1;
wheel_brake2_fault__independently__active__brake_actuator__brake_actuator__fault_4;
wheel_brake2_fault__independently__active__normal_hyd_fuse__normal_hyd_fuse__fault_1;
wheel_brake2_fault__independently__active__alt_hyd_fuse__alt_hyd_fuse__fault_1;
w2_w6_cmd_sys_fault__independently__active__normal_command_calculator_1__normal_command_calculator_1__fault_1;
normal_sys_fault__independently__active__mv2__mv2__fault_2;
channel2_fault__independently__active__monitor_sys__monitor_sys__fault_1;
bscu_fault__independently__active__switch_gate_brake_as_cmd_2__switch_gate_brake_as_cmd_2__fault_2;
w2_w6_cmd_sys_fault__independently__active__antiskid_command_facility_1__antiskid_command_facility_1__fault_1;
wBS_inst_fault__independently__active__pedal_sensor_L__pedal_sensor_L__fault_1;
channel1_fault__independently__active__monitor_sys__monitor_sys__fault_1;
wheel_brake2_fault__independently__active__alt_hyd_piston__alt_hyd_piston__fault_4;
phys_sys_fault__independently__active__accumulator__accumulator__fault_2;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_2;
wheel_brake2_fault__independently__active__normal_hyd_piston__normal_hyd_piston__fault_4;
phys_sys_fault__independently__active__selector_valve__selector_valve__fault_1    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets wBS_inst___GUARANTEE6;;
probErrorCut wBS_inst___GUARANTEE6;;
probErrorCutImp wBS_inst___GUARANTEE6;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE6_direct_ftree.gv" wBS_inst___GUARANTEE6 ;;
dot_gen_show_tree_file ~rend:"pdf" "wBS_inst___GUARANTEE6_optimized_ftree.gv" wBS_inst___GUARANTEE6 ;;

