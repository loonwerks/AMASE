#use "top.ml";;
let c123_fault__independently__active__C1__C1__fault_1 = 
Leaf
    (("C123","c123_fault__independently__active__C1__C1__fault_1"),1.0E-6, 1.0);;
let c0123_impl___GUARANTEE0 = 
PRO [
c123_fault__independently__active__C1__C1__fault_1    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets c0123_impl___GUARANTEE0;;
probErrorCut c0123_impl___GUARANTEE0;;
probErrorCutImp c0123_impl___GUARANTEE0;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "c0123_impl___GUARANTEE0_direct_ftree.gv" c0123_impl___GUARANTEE0 ;;
dot_gen_show_tree_file ~rend:"pdf" "c0123_impl___GUARANTEE0_optimized_ftree.gv" c0123_impl___GUARANTEE0 ;;

let c123_fault__independently__active__C1__C1__fault_1 = 
Leaf
    (("C123","c123_fault__independently__active__C1__C1__fault_1"),1.0E-6, 1.0);;
let c123_fault__independently__active__C2__C2__fault_1 = 
Leaf
    (("C123","c123_fault__independently__active__C2__C2__fault_1"),1.0E-5, 1.0);;
let c0123_impl_fault__independently__active__C0__C0__fault_1 = 
Leaf
    (("C0123_impl","c0123_impl_fault__independently__active__C0__C0__fault_1"),1.0E-7, 1.0);;
let c0123_impl___GUARANTEE1 = 
SUM [
c123_fault__independently__active__C1__C1__fault_1;
c123_fault__independently__active__C2__C2__fault_1;
c0123_impl_fault__independently__active__C0__C0__fault_1    ];;
(* ----- CUTSET WITH PROBABILITIES ----- *)
cutsets c0123_impl___GUARANTEE1;;
probErrorCut c0123_impl___GUARANTEE1;;
probErrorCutImp c0123_impl___GUARANTEE1;;
(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "c0123_impl___GUARANTEE1_direct_ftree.gv" c0123_impl___GUARANTEE1 ;;
dot_gen_show_tree_file ~rend:"pdf" "c0123_impl___GUARANTEE1_optimized_ftree.gv" c0123_impl___GUARANTEE1 ;;

