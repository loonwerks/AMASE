#use "top.ml";;
(* ----- COMPONENT LIBRARY ----- *)

let comp_library = 
  [
{name = "C123";
faults = ["contract violation"];
input_flows = [];
basic_events = ["C2_out2_fail_to_zero_fault_C2_fault_1_"; "C1_out1_negation_fault_C1_fault_1_"];
event_info = [(1.0E-5, 1.0); (1.0E-6, 1.0)];
output_flows = ["C123_out3_value"; "C123_out3_range"];
formulas = [
(["C123_out3_value"; "contract violation"],
Or[F["C1_out1_negation_fault_C1_fault_1_"]; 
F["C2_out2_fail_to_zero_fault_C2_fault_1_"]]); 
(["C123_out3_range"; "contract violation"],
F["C1_out1_negation_fault_C1_fault_1_"])]
}; 

{name = "C0123";
faults = ["contract violation"];
input_flows = ["C123_out3_value"; "C123_out3_range"];
basic_events = ["C0_out0_fail_to_one_fault_C0_fault_1_"];
event_info = [(1.0E-7, 1.0)];
output_flows = ["C0123_out0_value"; "C0123_out0_range"];
formulas = [
(["C0123_out0_value"; "contract violation"],
Or[F["C123_out3_value"; "contract violation"]; 
F["C0_out0_fail_to_one_fault_C0_fault_1_"]]); 
(["C0123_out0_range"; "contract violation"],
And[F["C123_out3_range"; "contract violation"]; 
F["C123_out3_value"; "contract violation"]])]
}];;

(* ----- CHECK LIBRARY ----- *)
checkLibrary_componentUnique comp_library;;
checkLibrary_nonEmptyFaults comp_library;;
checkLibrary_disjointInputFlowsandBasicEvents comp_library;;
checkLibrary_listsAreConsistentLengths comp_library;;
checkLibrary_allOutputFaultsHaveFormulas comp_library;;
checkLibrary_formulasMakeSense comp_library;;


(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_C0123_out0_range = 
{instances = 
[makeInstance "C123" "C123"();
makeInstance "C0123" "C0123"();
];
connections = 
[(("C0123", "C123_out3_value"),("C123", "C123_out3_value")); (("C0123", "C123_out3_range"),("C123", "C123_out3_range")); ];
top_fault = ("C0123", F["C0123_out0_range"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_C0123_out0_range;;
checkModel_cnameInstanceIsDefinedInLibrary model_C0123_out0_range comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_C0123_out0_range comp_library;;
checkModel_validConnections model_C0123_out0_range comp_library;;
checkModel_inputFlowUnique model_C0123_out0_range;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_C0123_out0_range "model_C0123_out0_range_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_C0123_out0_range "model_C0123_out0_range_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_C0123_out0_range "model_C0123_out0_range_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_C0123_out0_range_ftree = model_to_ftree comp_library model_C0123_out0_range;;
probErrorCutImp model_C0123_out0_range_ftree;;
probErrorCut model_C0123_out0_range_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_C0123_out0_range_direct_ftree.gv" model_C0123_out0_range_ftree ;;
dot_gen_show_tree_file "model_C0123_out0_range_optimized_ftree.gv" model_C0123_out0_range_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_C0123_out0_value = 
{instances = model_C0123_out0_range.instances;
connections=model_C0123_out0_range.connections;
top_fault = ("C0123", F["C0123_out0_value"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_C0123_out0_value;;
checkModel_cnameInstanceIsDefinedInLibrary model_C0123_out0_value comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_C0123_out0_value comp_library;;
checkModel_validConnections model_C0123_out0_value comp_library;;
checkModel_inputFlowUnique model_C0123_out0_value;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_C0123_out0_value "model_C0123_out0_value_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_C0123_out0_value "model_C0123_out0_value_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_C0123_out0_value "model_C0123_out0_value_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_C0123_out0_value_ftree = model_to_ftree comp_library model_C0123_out0_value;;
probErrorCutImp model_C0123_out0_value_ftree;;
probErrorCut model_C0123_out0_value_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file "model_C0123_out0_value_direct_ftree.gv" model_C0123_out0_value_ftree ;;
dot_gen_show_tree_file "model_C0123_out0_value_optimized_ftree.gv" model_C0123_out0_value_ftree ;;

