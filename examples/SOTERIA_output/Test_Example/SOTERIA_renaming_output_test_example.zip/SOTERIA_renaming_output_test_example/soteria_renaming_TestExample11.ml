#use "top.ml";;
(* ----- COMPONENT LIBRARY ----- *)

let comp_library = 
  [
{name = "C123";
faults = ["contract violation"];
input_flows = [];
basic_events = ["fault__independently__active__C2__C2__fault_1";
"fault__independently__active__C1__C1__fault_1"];
event_info = [(1.0E-5, 1.0);
(1.0E-6, 1.0)];
output_flows = ["C123___GUARANTEE0";
"C123___GUARANTEE1"];
formulas = [
(["C123___GUARANTEE0"; "contract violation"],
F["fault__independently__active__C1__C1__fault_1"]);
(["C123___GUARANTEE1"; "contract violation"],
Or[F["fault__independently__active__C1__C1__fault_1"]; 
F["fault__independently__active__C2__C2__fault_1"]])]
};

{name = "C0123_impl";
faults = ["contract violation"];
input_flows = ["C123___GUARANTEE0";
"C123___GUARANTEE1"];
basic_events = ["fault__independently__active__C0__C0__fault_1"];
event_info = [(1.0E-7, 1.0)];
output_flows = ["C0123_impl___GUARANTEE1";
"C0123_impl___GUARANTEE0"];
formulas = [
(["C0123_impl___GUARANTEE1"; "contract violation"],
Or[F["C123___GUARANTEE1"; "contract violation"]; 
F["fault__independently__active__C0__C0__fault_1"]]);
(["C0123_impl___GUARANTEE0"; "contract violation"],
And[F["C123___GUARANTEE0"; "contract violation"];
F["C123___GUARANTEE1"; "contract violation"]])]
}];;

(* ----- CHECK LIBRARY ----- *)
checkLibrary_componentUnique comp_library;;
checkLibrary_nonEmptyFaults comp_library;;
checkLibrary_disjointInputFlowsandBasicEvents comp_library;;
checkLibrary_listsAreConsistentLengths comp_library;;
checkLibrary_allOutputFaultsHaveFormulas comp_library;;
checkLibrary_formulasMakeSense comp_library;;


(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_C0123_impl___GUARANTEE0 = 
{instances = 
[makeInstance "C123" "C123"();
makeInstance "C0123_impl" "C0123_impl"();
];
connections = 
[(("C0123_impl", "C123___GUARANTEE0"),("C123", "C123___GUARANTEE0"));
(("C0123_impl", "C123___GUARANTEE1"),("C123", "C123___GUARANTEE1"));
];
top_fault = ("C0123_impl", F["C0123_impl___GUARANTEE0"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_C0123_impl___GUARANTEE0;;
checkModel_cnameInstanceIsDefinedInLibrary model_C0123_impl___GUARANTEE0 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_C0123_impl___GUARANTEE0 comp_library;;
checkModel_validConnections model_C0123_impl___GUARANTEE0 comp_library;;
checkModel_inputFlowUnique model_C0123_impl___GUARANTEE0;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_C0123_impl___GUARANTEE0 "model_C0123_impl___GUARANTEE0_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_C0123_impl___GUARANTEE0 "model_C0123_impl___GUARANTEE0_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_C0123_impl___GUARANTEE0 "model_C0123_impl___GUARANTEE0_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_C0123_impl___GUARANTEE0_ftree = model_to_ftree comp_library model_C0123_impl___GUARANTEE0;;
probErrorCutImp model_C0123_impl___GUARANTEE0_ftree;;
probErrorCut model_C0123_impl___GUARANTEE0_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_C0123_impl___GUARANTEE0_direct_ftree.gv" model_C0123_impl___GUARANTEE0_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_C0123_impl___GUARANTEE0_optimized_ftree.gv" model_C0123_impl___GUARANTEE0_ftree ;;

(* ----- COMPONENT INSTANCES, CONNECTIONS, OUT RANGE TOP LEVEL FAULT ----- *)
let model_C0123_impl___GUARANTEE1 = 
{instances = model_C0123_impl___GUARANTEE0.instances;
connections=model_C0123_impl___GUARANTEE0.connections;
top_fault = ("C0123_impl", F["C0123_impl___GUARANTEE1"; "contract violation"])} ;;

(* ----- CHECK MODEL ----- *)
checkModel_instanceNameUnique model_C0123_impl___GUARANTEE1;;
checkModel_cnameInstanceIsDefinedInLibrary model_C0123_impl___GUARANTEE1 comp_library;;
checkModel_exposureOfBasicIsDefinedInLibrary model_C0123_impl___GUARANTEE1 comp_library;;
checkModel_validConnections model_C0123_impl___GUARANTEE1 comp_library;;
checkModel_inputFlowUnique model_C0123_impl___GUARANTEE1;;

(* ----- PRE ANALYSES MODEL VISUALIZATIONS ----- *)
dot_gen_show_ph_file ~rend:"pdf" model_C0123_impl___GUARANTEE1 "model_C0123_impl___GUARANTEE1_physical.gv";;
dot_gen_show_funct_file ~rend:"pdf" comp_library model_C0123_impl___GUARANTEE1 "model_C0123_impl___GUARANTEE1_functional.gv";;
dot_gen_show_fault_file ~rend:"pdf" comp_library model_C0123_impl___GUARANTEE1 "model_C0123_impl___GUARANTEE1_fault_propagation.gv";;

(* ----- CUTSET WITH PROBABILITIES ----- *)
let model_C0123_impl___GUARANTEE1_ftree = model_to_ftree comp_library model_C0123_impl___GUARANTEE1;;
probErrorCutImp model_C0123_impl___GUARANTEE1_ftree;;
probErrorCut model_C0123_impl___GUARANTEE1_ftree;;

(* ----- FAULT TREE VISUALIZATIONS ----- *)
dot_gen_show_direct_tree_file ~rend:"pdf" "model_C0123_impl___GUARANTEE1_direct_ftree.gv" model_C0123_impl___GUARANTEE1_ftree ;;
dot_gen_show_tree_file ~rend:"pdf" "model_C0123_impl___GUARANTEE1_optimized_ftree.gv" model_C0123_impl___GUARANTEE1_ftree ;;

